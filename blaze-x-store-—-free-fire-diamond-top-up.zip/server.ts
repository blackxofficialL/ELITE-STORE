import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { validateFreeFireUid, validateRegion } from './src/shared/validation.ts';
import { calculateOrderPricing, generateOrderId } from './src/shared/pricing.ts';
import { maskPlayerUid, canTransition } from './src/shared/orderStateMachine.ts';
import { store } from './src/server/store.ts';
import { getActiveLookupAdapter } from './src/server/uidAdapter.ts';
import { paymentAdapter } from './src/server/paymentAdapter.ts';
import { fulfillmentService } from './src/server/fulfillmentService.ts';
import { Order, OrderStatus, RegionCode, PlayerProfile } from './src/types/index.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const ADMIN_SECRET = process.env.ADMIN_SECRET_KEY || 'blaze_admin_2026';
// In AI Studio dev environment, dev server must always listen on port 3000
const PORT = 3000;
const isProduction = process.env.NODE_ENV === 'production';

const app = express();

app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Ensure /public/banners folder exists and mount static route
const bannersDir = path.resolve(__dirname, 'public', 'banners');
if (!fs.existsSync(bannersDir)) {
  fs.mkdirSync(bannersDir, { recursive: true });
}
app.use('/banners', express.static(bannersDir));

// Ensure /public/call_img and /public/call_voice folders exist and mount static routes
const callImgDir = path.resolve(__dirname, 'public', 'call_img');
if (!fs.existsSync(callImgDir)) {
  fs.mkdirSync(callImgDir, { recursive: true });
}
app.use('/call_img', express.static(callImgDir));

const callVoiceDir = path.resolve(__dirname, 'public', 'call_voice');
if (!fs.existsSync(callVoiceDir)) {
  fs.mkdirSync(callVoiceDir, { recursive: true });
}
app.use('/call_voice', express.static(callVoiceDir));

const endCallVoiceDir = path.resolve(__dirname, 'public', 'end_call_voice');
if (!fs.existsSync(endCallVoiceDir)) {
  fs.mkdirSync(endCallVoiceDir, { recursive: true });
}
app.use('/end_call_voice', express.static(endCallVoiceDir));

app.use(express.static(path.resolve(__dirname, 'public')));

// Request logging
app.use((req, res, next) => {
  if (req.path.startsWith('/api')) {
    console.log(`[API] ${req.method} ${req.path}`);
  }
  next();
});

// Admin authentication middleware
function requireAdminAuth(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const token = authHeader?.startsWith('Bearer ')
    ? authHeader.slice(7)
    : req.headers['x-admin-token'];

  if (!token || token !== ADMIN_SECRET) {
    return res.status(401).json({
      error: 'Unauthorized. Invalid or missing administrator credentials.',
    });
  }
  next();
}

// ----------------- Public API Routes -----------------

// Get all banners in /public/banners folder
app.get('/api/banners', (req: Request, res: Response) => {
  try {
    if (!fs.existsSync(bannersDir)) {
      return res.json({ success: true, banners: [] });
    }
    const files = fs.readdirSync(bannersDir);
    const validExtensions = ['.png', '.jpg', '.jpeg', '.webp', '.svg', '.gif'];
    const banners = files
      .filter((file) => validExtensions.includes(path.extname(file).toLowerCase()))
      .sort((a, b) => a.localeCompare(b))
      .map((file) => ({
        id: file,
        name: file,
        url: `/banners/${file}`,
      }));
    res.json({ success: true, banners });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to read banners folder', message: err.message });
  }
});

// Upload a new banner into /public/banners
app.post('/api/banners/upload', (req: Request, res: Response) => {
  try {
    const { fileName, dataUrl } = req.body;
    if (!fileName || !dataUrl) {
      return res.status(400).json({ error: 'Missing fileName or dataUrl.' });
    }
    const cleanName = path.basename(fileName).replace(/[^a-zA-Z0-9._-]/g, '_');
    const matches = dataUrl.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    let buffer: Buffer;
    if (matches && matches.length === 3) {
      buffer = Buffer.from(matches[2], 'base64');
    } else {
      buffer = Buffer.from(dataUrl, 'base64');
    }
    const filePath = path.join(bannersDir, cleanName);
    fs.writeFileSync(filePath, buffer);
    res.json({
      success: true,
      banner: {
        id: cleanName,
        name: cleanName,
        url: `/banners/${cleanName}`,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to save banner', message: err.message });
  }
});

// Rename a banner in /public/banners
app.post('/api/banners/rename', (req: Request, res: Response) => {
  try {
    const { oldName, newName } = req.body;
    if (!oldName || !newName) {
      return res.status(400).json({ error: 'Missing oldName or newName.' });
    }
    const cleanOld = path.basename(oldName);
    let cleanNew = path.basename(newName).replace(/[^a-zA-Z0-9._-]/g, '_');
    // Preserve extension if omitted
    if (!path.extname(cleanNew) && path.extname(cleanOld)) {
      cleanNew = `${cleanNew}${path.extname(cleanOld)}`;
    }
    const oldPath = path.join(bannersDir, cleanOld);
    const newPath = path.join(bannersDir, cleanNew);
    if (!fs.existsSync(oldPath)) {
      return res.status(404).json({ error: `File ${cleanOld} does not exist.` });
    }
    fs.renameSync(oldPath, newPath);
    res.json({
      success: true,
      banner: {
        id: cleanNew,
        name: cleanNew,
        url: `/banners/${cleanNew}`,
      },
    });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to rename banner', message: err.message });
  }
});

// Delete a banner from /public/banners
app.delete('/api/banners/:fileName', (req: Request, res: Response) => {
  try {
    const cleanName = path.basename(req.params.fileName);
    const filePath = path.join(bannersDir, cleanName);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
    res.json({ success: true, message: `Banner ${cleanName} deleted.` });
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to delete banner', message: err.message });
  }
});

// System configuration and provider health status
app.get('/api/config/status', (req: Request, res: Response) => {
  const lookupAdapter = getActiveLookupAdapter();
  const paymentConfig = paymentAdapter.getConfig();
  const fulfillmentStatus = fulfillmentService.getStatus();

  res.json({
    lookupProvider: {
      name: lookupAdapter.name,
      configured: lookupAdapter.isConfigured(),
      demoModeActive: lookupAdapter.id === 'demo_verified',
      status: lookupAdapter.isConfigured() ? 'operational' : 'unconfigured',
      message: lookupAdapter.isConfigured()
        ? `Active provider: ${lookupAdapter.name}`
        : 'Player verification is not configured. (Missing FF_LOOKUP_API_URL)',
    },
    paymentGateway: {
      provider: paymentConfig.provider,
      configured: paymentConfig.isConfigured,
      sandboxActive: !paymentConfig.isConfigured,
      keyIdPreview: paymentConfig.keyId.slice(0, 10) + '...',
    },
    fulfillment: fulfillmentStatus,
  });
});

// Verify Player UID (POST)
app.post('/api/uid/verify', async (req: Request, res: Response) => {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const rateLimit = store.checkRateLimit(ip, 30, 60000);
  if (!rateLimit.allowed) {
    store.addLog('security', `Rate limit exceeded for UID lookup from IP ${ip}`);
    return res.status(429).json({
      error: 'Too many verification attempts. Please wait 1 minute before trying again.',
    });
  }

  const { uid, region } = req.body;

  const uidValidation = validateFreeFireUid(uid);
  if (!uidValidation.isValid || !uidValidation.cleanUid) {
    return res.status(400).json({ error: uidValidation.error });
  }

  const regionCode = (region || 'IND').toUpperCase() as RegionCode;
  if (!validateRegion(regionCode)) {
    return res.status(400).json({ error: 'Unsupported or invalid server region selected.' });
  }

  const adapter = getActiveLookupAdapter();
  const result = await adapter.lookup(uidValidation.cleanUid, regionCode);

  if (!result.success) {
    store.addLog('uid_lookup', `Lookup not found for UID ${uidValidation.cleanUid}: ${result.error}`);
    return res.status(result.statusCode || 404).json({
      success: false,
      error: result.error || 'Player verification failed',
      notFound: result.notFound ?? true,
      uid: result.uid || uidValidation.cleanUid,
      region: result.region || regionCode,
    });
  }

  store.addLog(
    'uid_lookup',
    `Verified player UID ${uidValidation.cleanUid} (${result.profile?.nickname}) via ${adapter.name}`
  );

  return res.json({
    success: true,
    verified: true,
    profile: result.profile,
    player: {
      uid: result.profile?.uid,
      nickname: result.profile?.nickname,
      region: result.profile?.region,
      level: result.profile?.level,
      avatarUrl: result.profile?.avatarUrl,
    },
  });
});

// GET /api/accinfo proxy endpoint (exact match for client GET requests)
app.get('/api/accinfo', async (req: Request, res: Response) => {
  const rawUid = req.query.uid as string;
  const regionCode = ((req.query.region as string) || 'IND').toUpperCase() as RegionCode;

  const uidValidation = validateFreeFireUid(rawUid);
  if (!uidValidation.isValid || !uidValidation.cleanUid) {
    return res.status(400).json({ error: uidValidation.error || 'Invalid UID format' });
  }

  const adapter = getActiveLookupAdapter();
  const result = await adapter.lookup(uidValidation.cleanUid, regionCode);

  if (!result.success || !result.profile) {
    return res.status(result.statusCode || 404).json({
      error: result.error || 'UID not found or no guest available for any region',
      notFound: true,
    });
  }

  return res.json({
    basicInfo: {
      accountId: result.profile.uid,
      nickname: result.profile.nickname,
      region: result.profile.region,
      level: result.profile.level,
      headPic: result.profile.headPic,
      bannerId: result.profile.bannerId,
      liked: result.profile.likes,
      rankingPoints: result.profile.rankScore,
      rank: result.profile.rank,
    },
    profile: result.profile,
  });
});

// GET /api/uid/verify proxy endpoint
app.get('/api/uid/verify', async (req: Request, res: Response) => {
  const rawUid = req.query.uid as string;
  const regionCode = ((req.query.region as string) || 'IND').toUpperCase() as RegionCode;

  const uidValidation = validateFreeFireUid(rawUid);
  if (!uidValidation.isValid || !uidValidation.cleanUid) {
    return res.status(400).json({ error: uidValidation.error || 'Invalid UID format' });
  }

  const adapter = getActiveLookupAdapter();
  const result = await adapter.lookup(uidValidation.cleanUid, regionCode);

  if (!result.success || !result.profile) {
    return res.status(result.statusCode || 404).json({
      success: false,
      verified: false,
      error: result.error || 'Player verification failed',
      notFound: true,
    });
  }

  return res.json({
    success: true,
    verified: true,
    profile: result.profile,
    player: {
      uid: result.profile.uid,
      nickname: result.profile.nickname,
      region: result.profile.region,
      level: result.profile.level,
      avatarUrl: result.profile.avatarUrl,
    },
  });
});

// Update/Correct Player In-Game Profile
app.post('/api/uid/update-profile', (req: Request, res: Response) => {
  const { uid, nickname, level, guildName, rank, likes, signature } = req.body;

  const uidValidation = validateFreeFireUid(uid);
  if (!uidValidation.isValid || !uidValidation.cleanUid) {
    return res.status(400).json({ error: 'Valid player UID is required.' });
  }

  if (!nickname || typeof nickname !== 'string' || nickname.trim().length === 0) {
    return res.status(400).json({ error: 'Valid in-game nickname is required.' });
  }

  const existing = store.getCustomProfile(uidValidation.cleanUid);
  const cleanLevel = typeof level === 'number' && level > 0 ? level : existing?.level || 65;
  const cleanLikes = typeof likes === 'number' && likes >= 0 ? likes : existing?.likes || 12500;

  const updatedProfile: PlayerProfile = {
    uid: uidValidation.cleanUid,
    region: 'IND',
    nickname: nickname.trim(),
    level: cleanLevel,
    likes: cleanLikes,
    rank: rank || existing?.rank || 'Heroic V (4,250 Pts)',
    badge: (rank || existing?.rank || 'Heroic').split(' ')[0],
    guild: guildName
      ? { name: guildName.trim(), level: 4 }
      : existing?.guild || { name: 'INDIA_WARRIORS', level: 4 },
    signature: signature || existing?.signature || 'Free Fire India Verified Player',
    hasVBadge: cleanLevel >= 70 || Boolean(existing?.hasVBadge),
    verifiedAt: new Date().toISOString(),
    provider: 'india_server_api',
  };

  store.setCustomProfile(updatedProfile);

  return res.json({
    success: true,
    message: 'Profile updated successfully!',
    profile: updatedProfile,
  });
});

// Direct standalone Free Fire India Profile API
app.get('/api/ff/profile/:uid', async (req: Request, res: Response) => {
  const { uid } = req.params;
  const region = ((req.query.region as string) || 'IND').toUpperCase() as RegionCode;

  const uidValidation = validateFreeFireUid(uid);
  if (!uidValidation.isValid || !uidValidation.cleanUid) {
    return res.status(400).json({ error: uidValidation.error });
  }

  const adapter = getActiveLookupAdapter();
  const result = await adapter.lookup(uidValidation.cleanUid, region);

  if (!result.success) {
    return res.status(result.statusCode || 404).json({ error: result.error });
  }

  return res.json({
    success: true,
    server: 'India (IND)',
    profile: result.profile,
  });
});

// Get Diamond Packages
app.get('/api/packages', (req: Request, res: Response) => {
  const packages = store.getPackages().filter((p) => p.active);
  res.json({ packages });
});

// Create Order (Authoritative server-side price calculation)
app.post('/api/orders/create', async (req: Request, res: Response) => {
  const { uid, region, nickname, packageId } = req.body;

  const uidValidation = validateFreeFireUid(uid);
  if (!uidValidation.isValid || !uidValidation.cleanUid) {
    return res.status(400).json({ error: 'Valid player UID is required to create order.' });
  }

  if (!nickname || typeof nickname !== 'string' || nickname.trim().length === 0) {
    return res.status(400).json({ error: 'Verified player nickname is required.' });
  }

  const regionCode = (region || 'IND').toUpperCase() as RegionCode;
  const packages = store.getPackages();
  const pricing = calculateOrderPricing(packageId, packages);

  if (!pricing.valid || !pricing.package) {
    return res.status(400).json({ error: pricing.error || 'Invalid diamond package selected.' });
  }

  const orderId = generateOrderId('ES');
  const now = new Date().toISOString();

  // Generate payment gateway checkout order
  const gatewayOrder = await paymentAdapter.createGatewayOrder(orderId, pricing.totalPayableINR);

  const order: Order = {
    id: orderId,
    uid: uidValidation.cleanUid,
    nickname: nickname.trim(),
    region: regionCode,
    packageId: pricing.package.id,
    diamonds: pricing.package.diamonds,
    bonusDiamonds: pricing.package.bonus,
    amountINR: pricing.totalPayableINR,
    status: 'pending_payment',
    statusMessage: 'Awaiting payment confirmation',
    createdAt: now,
    updatedAt: now,
  };

  store.createOrder(order);

  // Return sandbox signature helper if in sandbox mode for test checkout
  const sandboxSignature =
    gatewayOrder.keyId === 'rzp_test_blazex_demo'
      ? paymentAdapter.generateSandboxSignature(gatewayOrder.gatewayOrderId, `pay_sim_${Date.now()}`)
      : undefined;

  res.json({
    success: true,
    order,
    pricing,
    gatewayOrder: {
      ...gatewayOrder,
      sandboxSignature,
      simulatedPaymentId: sandboxSignature ? `pay_sim_${Date.now()}` : undefined,
    },
  });
});

// Verify Payment and Initiate Diamond Delivery
app.post('/api/orders/verify-payment', async (req: Request, res: Response) => {
  const { orderId, gatewayOrderId, paymentId, signature, paymentMethod, utrNumber, screenshotUrl } = req.body;

  if (!orderId) {
    return res.status(400).json({ error: 'orderId is required.' });
  }

  const order = store.getOrder(orderId);
  if (!order) {
    return res.status(404).json({ error: 'Order not found.' });
  }

  // Idempotency: prevent double fulfillment
  if (order.status === 'delivered' || order.status === 'processing') {
    return res.json({
      success: true,
      message: 'Payment already processed and order is in progress or completed.',
      order,
    });
  }

  const isUpiManual = Boolean(utrNumber);

  if (!isUpiManual) {
    // Cryptographic signature check for gateway
    const verification = paymentAdapter.verifyPaymentSignature({
      gatewayOrderId: gatewayOrderId || orderId,
      paymentId: paymentId || 'manual',
      signature: signature || 'sig_demo',
    });

    if (!verification.verified) {
      store.updateOrderStatus(orderId, 'failed', {
        statusMessage: verification.error || 'Payment verification signature failed.',
      });
      return res.status(400).json({
        error: verification.error || 'Payment signature mismatch. Transaction could not be verified.',
      });
    }
  }

  // Mark payment successful with UTR & screenshot details
  store.updateOrderStatus(orderId, 'payment_successful', {
    paymentId: paymentId || `UTR_${utrNumber || Date.now()}`,
    paymentMethod: paymentMethod || 'UPI QR (freelance.h@pthdfc)',
    paymentSignature: signature || `UTR:${utrNumber || 'MANUAL'}`,
    utrNumber: utrNumber || undefined,
    screenshotUrl: screenshotUrl || undefined,
    statusMessage: isUpiManual
      ? `Payment verified via UTR ${utrNumber}. Dispatching diamonds to in-game mailbox...`
      : 'Payment verified. Initiating diamond top-up...',
  });

  // Initiate fulfillment immediately
  const fulfillmentResult = await fulfillmentService.processOrderFulfillment(orderId);
  const updatedOrder = store.getOrder(orderId);

  res.json({
    success: true,
    order: updatedOrder,
    fulfillment: fulfillmentResult,
  });
});

// Call Admin Media resolution & upload routes
app.get('/api/call-media', (req: Request, res: Response) => {
  let imgUrl: string | null = null;
  let voiceUrl: string | null = null;
  let endCallVoiceUrl: string | null = null;

  try {
    if (fs.existsSync(callImgDir)) {
      const files = fs.readdirSync(callImgDir).filter(f => !f.endsWith('.txt') && !f.startsWith('.'));
      if (files.length > 0) {
        const img = files.find(f => /\.(png|jpe?g|webp|svg|gif)$/i.test(f)) || files[0];
        imgUrl = `/call_img/${img}`;
      }
    }
  } catch (e) {
    console.error('Error reading call_img:', e);
  }

  try {
    if (fs.existsSync(callVoiceDir)) {
      const files = fs.readdirSync(callVoiceDir).filter(f => !f.endsWith('.txt') && !f.startsWith('.'));
      if (files.length > 0) {
        const audio = files.find(f => /\.(mp3|wav|ogg|m4a|aac|webm)$/i.test(f)) || files[0];
        voiceUrl = `/call_voice/${audio}`;
      }
    }
  } catch (e) {
    console.error('Error reading call_voice:', e);
  }

  try {
    if (fs.existsSync(endCallVoiceDir)) {
      const files = fs.readdirSync(endCallVoiceDir).filter(f => !f.endsWith('.txt') && !f.startsWith('.'));
      if (files.length > 0) {
        const audio = files.find(f => /\.(mp3|wav|ogg|m4a|aac|webm)$/i.test(f)) || files[0];
        endCallVoiceUrl = `/end_call_voice/${audio}`;
      }
    }
  } catch (e) {
    console.error('Error reading end_call_voice:', e);
  }

  res.json({ imageUrl: imgUrl, voiceUrl: voiceUrl, endCallVoiceUrl: endCallVoiceUrl });
});

app.post('/api/call-media/upload-img', (req: Request, res: Response) => {
  const { fileName, dataUrl } = req.body;
  if (!fileName || !dataUrl) {
    return res.status(400).json({ error: 'fileName and dataUrl required' });
  }
  const cleanName = path.basename(fileName).replace(/[^a-zA-Z0-9._-]/g, '_');
  const base64Data = dataUrl.replace(/^data:image\/\w+;base64,/, '');
  fs.writeFileSync(path.join(callImgDir, cleanName), Buffer.from(base64Data, 'base64'));
  res.json({ success: true, url: `/call_img/${cleanName}` });
});

app.post('/api/call-media/upload-voice', (req: Request, res: Response) => {
  const { fileName, dataUrl } = req.body;
  if (!fileName || !dataUrl) {
    return res.status(400).json({ error: 'fileName and dataUrl required' });
  }
  const cleanName = path.basename(fileName).replace(/[^a-zA-Z0-9._-]/g, '_');
  const base64Data = dataUrl.replace(/^data:audio\/\w+;base64,/, '').replace(/^data:video\/\w+;base64,/, '');
  fs.writeFileSync(path.join(callVoiceDir, cleanName), Buffer.from(base64Data, 'base64'));
  res.json({ success: true, url: `/call_voice/${cleanName}` });
});

app.post('/api/call-media/upload-end-call-voice', (req: Request, res: Response) => {
  const { fileName, dataUrl } = req.body;
  if (!fileName || !dataUrl) {
    return res.status(400).json({ error: 'fileName and dataUrl required' });
  }
  const cleanName = path.basename(fileName).replace(/[^a-zA-Z0-9._-]/g, '_');
  const base64Data = dataUrl.replace(/^data:audio\/\w+;base64,/, '').replace(/^data:video\/\w+;base64,/, '');
  fs.writeFileSync(path.join(endCallVoiceDir, cleanName), Buffer.from(base64Data, 'base64'));
  res.json({ success: true, url: `/end_call_voice/${cleanName}` });
});

// Recent public orders ticker (millions of unique realistic Indian Free Fire UIDs, never repeating)
app.get('/api/orders/recent', (req: Request, res: Response) => {
  const realOrders = store.getRecentCompletedOrders(10);
  const prefixes = [
    '1106', '1202', '1492', '1829', '2067', '2481', '2849', '3104', '3914', '4205',
    '4510', '4829', '5129', '5482', '5928', '6048', '6739', '7039', '7581', '7930',
    '8192', '8642', '9028', '9481', '9720', '9912', '1038', '2194', '3482', '5201',
    '6394', '7125', '8302', '9154'
  ];
  const diamondTiers = [8000, 12000, 18000, 25000, 35000, 50000];

  const generatedOrders = Array.from({ length: 30 }, (_, i) => {
    const p = prefixes[Math.floor(Math.random() * prefixes.length)];
    const middle = Math.floor(1000 + Math.random() * 9000);
    const suffix = Math.floor(1000 + Math.random() * 9000);
    const uid = `${p}${middle}${suffix}`;
    const diamonds = diamondTiers[Math.floor(Math.random() * diamondTiers.length)];
    return {
      id: `ES-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).slice(2, 6).toUpperCase()}`,
      maskedUid: `${uid.slice(0, 4)}****${uid.slice(-4)}`,
      diamonds,
      createdAt: new Date(Date.now() - (i * 35000 + Math.floor(Math.random() * 10000))).toISOString(),
      status: 'delivered',
    };
  });

  const combined = [
    ...realOrders.map((o) => ({
      id: o.id,
      maskedUid: maskPlayerUid(o.uid),
      nickname: o.nickname.slice(0, 3) + '***',
      diamonds: o.diamonds + (o.bonusDiamonds || 0),
      createdAt: o.createdAt,
      status: o.status,
    })),
    ...generatedOrders,
  ];

  res.json({ orders: combined });
});

// Search Orders by Order ID or Player UID
app.get('/api/orders/search/lookup', (req: Request, res: Response) => {
  const query = (req.query.q as string)?.trim();
  if (!query) {
    return res.status(400).json({ error: 'Search query is required' });
  }

  const allOrders = store.getAllOrders();
  const matched = allOrders.filter(
    (o) => o.id.toLowerCase() === query.toLowerCase() || o.uid === query
  );

  res.json({ orders: matched.slice(0, 10) });
});

// Track Order Status
app.get('/api/orders/:orderId', (req: Request, res: Response) => {
  const order = store.getOrder(req.params.orderId);
  if (!order) {
    return res.status(404).json({ error: 'Order not found. Please verify your Order ID.' });
  }
  res.json({ order });
});

// ----------------- Admin Protected API Routes -----------------

// Admin Login
app.post('/api/admin/login', (req: Request, res: Response) => {
  const { password } = req.body;
  if (!password || password !== ADMIN_SECRET) {
    store.addLog('security', 'Failed administrator login attempt.');
    return res.status(401).json({ error: 'Invalid administrator password.' });
  }

  store.addLog('security', 'Admin login successful.');
  res.json({
    success: true,
    token: ADMIN_SECRET,
    user: { role: 'super_admin', email: 'admin@elitestore.com' },
  });
});

// Admin Stats
app.get('/api/admin/stats', requireAdminAuth, (req: Request, res: Response) => {
  const orders = store.getAllOrders();
  const totalRevenue = orders
    .filter((o) => o.status === 'delivered' || o.status === 'processing')
    .reduce((sum, o) => sum + o.amountINR, 0);

  const deliveredCount = orders.filter((o) => o.status === 'delivered').length;
  const pendingCount = orders.filter((o) => o.status === 'pending_payment' || o.status === 'processing').length;
  const failedCount = orders.filter((o) => o.status === 'failed' || o.status === 'refunded').length;

  res.json({
    stats: {
      totalRevenueINR: totalRevenue,
      totalOrders: orders.length,
      deliveredOrders: deliveredCount,
      pendingOrders: pendingCount,
      failedOrders: failedCount,
      fulfillmentSuccessRate: orders.length > 0 ? Math.round((deliveredCount / orders.length) * 100) : 100,
      activePackages: store.getPackages().filter((p) => p.active).length,
    },
  });
});

// Admin Orders list
app.get('/api/admin/orders', requireAdminAuth, (req: Request, res: Response) => {
  const orders = store.getAllOrders();
  res.json({ orders });
});

// Admin Order status update / manual retry / refund
app.post('/api/admin/orders/:orderId/status', requireAdminAuth, async (req: Request, res: Response) => {
  const { orderId } = req.params;
  const { status, statusMessage, triggerFulfillment } = req.body;

  const order = store.getOrder(orderId);
  if (!order) {
    return res.status(404).json({ error: 'Order not found' });
  }

  if (triggerFulfillment) {
    store.updateOrderStatus(orderId, 'payment_successful');
    await fulfillmentService.processOrderFulfillment(orderId);
    return res.json({ success: true, order: store.getOrder(orderId) });
  }

  if (status) {
    if (!canTransition(order.status, status as OrderStatus)) {
      return res.status(400).json({
        error: `Cannot transition from '${order.status}' to '${status}' directly.`,
      });
    }
    const updated = store.updateOrderStatus(orderId, status as OrderStatus, {
      statusMessage: statusMessage || `Status manually changed to ${status} by administrator.`,
    });
    return res.json({ success: true, order: updated });
  }

  res.status(400).json({ error: 'No status or action specified' });
});

// Admin Package management
app.put('/api/admin/packages', requireAdminAuth, (req: Request, res: Response) => {
  const { packages } = req.body;
  if (!Array.isArray(packages)) {
    return res.status(400).json({ error: 'Packages must be an array' });
  }
  store.setPackages(packages);
  res.json({ success: true, packages: store.getPackages() });
});

// Admin System Logs
app.get('/api/admin/logs', requireAdminAuth, (req: Request, res: Response) => {
  res.json({ logs: store.getLogs(60) });
});

// Admin External API Configuration
app.get('/api/admin/api-config', requireAdminAuth, (req: Request, res: Response) => {
  res.json({ config: store.getApiConfig() });
});

app.post('/api/admin/api-config', requireAdminAuth, (req: Request, res: Response) => {
  const { url, apiKey, enabled } = req.body;
  store.setApiConfig({ url: url || '', apiKey, enabled });
  res.json({ success: true, config: store.getApiConfig() });
});

// Admin Live Test API Endpoint
app.post('/api/admin/test-api', requireAdminAuth, async (req: Request, res: Response) => {
  const { url, apiKey, uid, region } = req.body;
  if (!url) {
    return res.status(400).json({ error: 'API URL is required' });
  }

  const testUid = uid || '451012596';
  const testRegion = region || 'IND';

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);

    const targetUrl = new URL(url);
    targetUrl.searchParams.set('uid', testUid);
    targetUrl.searchParams.set('region', testRegion);

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      'User-Agent': 'EliteStore/2.0 (Admin Live Tester)',
    };
    if (apiKey) {
      headers['Authorization'] = `Bearer ${apiKey}`;
      headers['x-api-key'] = apiKey;
    }

    const testRes = await fetch(targetUrl.toString(), {
      method: 'GET',
      headers,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    const text = await testRes.text();
    let json: any = null;
    try {
      json = JSON.parse(text);
    } catch {
      // ignore
    }

    res.json({
      success: testRes.ok,
      status: testRes.status,
      response: json || text,
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      error: `API test request failed: ${err.message}`,
    });
  }
});

// Admin Manage Verified Custom Profiles
app.get('/api/admin/profiles', requireAdminAuth, (req: Request, res: Response) => {
  res.json({ profiles: store.getAllCustomProfiles() });
});

app.post('/api/admin/profiles', requireAdminAuth, (req: Request, res: Response) => {
  const { uid, nickname, region, level, guildName, rank, likes, signature, hasVBadge } = req.body;
  if (!uid || !nickname) {
    return res.status(400).json({ error: 'UID and Nickname are required' });
  }

  const profile: PlayerProfile = {
    uid: String(uid).trim(),
    region: (region || 'IND').toUpperCase() as RegionCode,
    nickname: String(nickname).trim(),
    level: Number(level) || 65,
    likes: Number(likes) || 1200,
    rank: rank || 'Heroic V (4,200 Pts)',
    rankScore: 3500 + (Number(level) || 65) * 25,
    csRank: (Number(level) || 65) >= 70 ? 'Master 25★' : 'Master 10★',
    guild: {
      name: guildName || 'INDIA_WARRIORS',
      level: 4,
    },
    signature: signature || 'Verified Free Fire Player • Elite Store',
    hasVBadge: Boolean(hasVBadge || (Number(level) || 65) >= 75),
    badge: (rank || 'Heroic').split(' ')[0],
    verifiedAt: new Date().toISOString(),
    provider: 'admin_registered',
  };

  store.setCustomProfile(profile);
  res.json({ success: true, profile });
});

app.delete('/api/admin/profiles/:uid', requireAdminAuth, (req: Request, res: Response) => {
  const deleted = store.deleteCustomProfile(req.params.uid);
  res.json({ success: deleted });
});

// Mount Vite in development or serve static in production
async function startServer() {
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[ELITE STORE] Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[ELITE STORE] Server startup failed:', err);
  process.exit(1);
});
