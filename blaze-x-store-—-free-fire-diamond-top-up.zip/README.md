# BLAZE X STORE — Premium Free Fire Diamond Top-Up Platform

A production-quality gaming e-commerce and Free Fire diamond top-up platform built with React, TypeScript, Express, and Tailwind CSS. Features official Player UID verification, authoritative server-side price computation, Razorpay & cryptographic signature validation, modular automated fulfillment, order tracking, and a secure administration portal.

---

## ⚡ Key Capabilities

1. **Free Fire UID Verification**:
   - Validates numeric 8–12 digit player UID and server region (India default + SG, BD, BR, ID, ME, EU, NA).
   - Pluggable provider adapter (`ExternalHttpLookupAdapter`, `DemoVerifiedLookupAdapter`, `UnconfiguredLookupAdapter`).
   - Profile confirmation card with in-game nickname, UID, and tier badge before checkout.
   - Enforces backend rate limiting (max 30 requests/minute/IP) and input sanitization.

2. **Diamond Packages & Authoritative Pricing**:
   - 100, 310, 520, 1060 (Best Value), 2180, 5600 Diamond bundles with bonus gems.
   - Weekly (450 Diamonds) and Monthly VIP Passes (2600 Diamonds).
   - Authoritative backend pricing calculation prevents client price tampering.

3. **Secure Checkout & Cryptographic Payment Verification**:
   - Server generates unique Order IDs (`BX-YYYYMMDD-XXXXXX`).
   - Supports live Razorpay integration or test sandbox mode.
   - Verifies transactions using HMAC SHA-256 signatures (`gatewayOrderId|paymentId`).
   - Prevents duplicate order processing and repeated fulfillment.

4. **Modular Order Fulfillment & Live Order Tracking**:
   - Automated queue and supplier webhook integration.
   - Public order tracker by Order ID or Player UID.
   - State machine: `pending_payment` ➔ `payment_successful` ➔ `processing` ➔ `delivered` (or `failed` / `refunded`).

5. **Live Anonymized Purchase Alerts**:
   - Displays real verified orders with masked UIDs (e.g., `UID 284****41`).
   - Can be toggled on/off in header settings.

6. **Protected Administration Portal**:
   - Server-side authentication via `ADMIN_SECRET_KEY`.
   - Live revenue, order count, and fulfillment success rate KPIs.
   - Order management with manual retry, delivery marking, and refund initiation.
   - Diamond catalog & pricing editor.
   - System diagnostics and audit trail logs.

---

## 🚀 Getting Started

### 1. Environment Configuration

Copy `.env.example` to `.env`:

```bash
cp .env.example .env
```

Key environment variables:

| Variable | Description | Default (Dev) |
|---|---|---|
| `PORT` | Server listening port | `3000` |
| `ADMIN_SECRET_KEY` | Master admin password | `blaze_admin_2026` |
| `FF_LOOKUP_PROVIDER` | `demo_verified`, `coda_shop`, `smile_one`, or `custom_api` | `demo_verified` |
| `FF_LOOKUP_API_URL` | Live Free Fire lookup provider URL | `""` |
| `FF_LOOKUP_API_KEY` | Provider API authorization key | `""` |
| `ENABLE_DEMO_PROVIDER` | Allow fallback to verified demo adapter in sandbox | `true` |
| `RAZORPAY_KEY_ID` | Razorpay Key ID | `""` (Uses sandbox HMAC) |
| `RAZORPAY_KEY_SECRET` | Razorpay Key Secret | `""` |
| `TOPUP_FULFILLMENT_PROVIDER` | `auto_queue` or `supplier_api` | `auto_queue` |
| `TOPUP_FULFILLMENT_API_URL` | Distributor API endpoint | `""` |

### 2. Development

Run the full-stack server (Express + Vite middlewares):

```bash
npm run dev
```

The app will be available at `http://localhost:3000`.

### 3. Running Unit Tests

Run the decoupled core logic test suite (validation, pricing, state machine):

```bash
npm test
# or
node --test src/shared/logic.test.ts
```

### 4. Production Build & Deployment

```bash
# Build frontend assets
npm run build

# Start production server
npm start
```

---

## 🔒 Security Architecture

- **No Passwords or OTPs**: Top-ups operate exclusively via public numeric UID.
- **Server Authority**: All diamond calculations, discounts, and payments are calculated on the backend.
- **Constant-Time Comparison**: Cryptographic signatures are verified using `crypto.timingSafeEqual`.
- **Admin Endpoints**: Protected with server-side bearer token validation (`requireAdminAuth`).
