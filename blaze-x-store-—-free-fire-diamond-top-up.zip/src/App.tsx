import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar.tsx';
import { HeroCarousel } from './components/HeroCarousel.tsx';
import { GameBanner } from './components/GameBanner.tsx';
import { UidVerification } from './components/UidVerification.tsx';
import { DiamondPackages } from './components/DiamondPackages.tsx';
import { ToppingUpBanner } from './components/ToppingUpBanner.tsx';
import { VerifiedAccountModal } from './components/VerifiedAccountModal.tsx';
import { CheckoutModal } from './components/CheckoutModal.tsx';
import { OrderTrackerModal } from './components/OrderTrackerModal.tsx';
import { HowItWorks } from './components/HowItWorks.tsx';
import { FaqSection } from './components/FaqSection.tsx';
import { RecentPurchasesToast } from './components/RecentPurchasesToast.tsx';
import { AdminDashboardModal } from './components/AdminDashboardModal.tsx';
import { PolicyModal, PolicyType } from './components/PolicyModals.tsx';
import { MyOrdersModal } from './components/MyOrdersModal.tsx';
import { CallAdminModal } from './components/CallAdminModal.tsx';
import { Footer } from './components/Footer.tsx';
import { DiamondPackage, PlayerProfile, Order } from './types/index.ts';
import { INITIAL_PACKAGES } from './shared/pricing.ts';

export default function App() {
  // Always default to clean white theme
  const [isDark] = useState<boolean>(false);

  const [notificationsEnabled, setNotificationsEnabled] = useState<boolean>(() => {
    const saved = localStorage.getItem('blaze_notifications');
    return saved !== 'false';
  });

  const [packages, setPackages] = useState<DiamondPackage[]>(INITIAL_PACKAGES);
  const [verifiedProfile, setVerifiedProfile] = useState<PlayerProfile | null>(null);
  const [selectedPackage, setSelectedPackage] = useState<DiamondPackage | null>(null);

  // Flow states for popup & store
  const [verifiedModalOpen, setVerifiedModalOpen] = useState(false);
  const [proceededToStore, setProceededToStore] = useState(false);
  const [completedOrdersCount, setCompletedOrdersCount] = useState(1);
  const [sessionOrders, setSessionOrders] = useState<Order[]>([]);

  // Modals
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [trackerOpen, setTrackerOpen] = useState(false);
  const [myOrdersModalOpen, setMyOrdersModalOpen] = useState(false);
  const [adminOpen, setAdminOpen] = useState(false);
  const [callAdminOpen, setCallAdminOpen] = useState(false);
  const [activePolicy, setActivePolicy] = useState<PolicyType>(null);

  // Enforce white theme
  useEffect(() => {
    document.documentElement.classList.remove('dark');
    document.body.classList.remove('dark');
    localStorage.setItem('blaze_theme', 'light');
  }, []);

  // Fetch live packages from backend
  const fetchPackages = async () => {
    try {
      const res = await fetch('/api/packages');
      if (res.ok) {
        const data = await res.json();
        if (data.packages && Array.isArray(data.packages)) {
          setPackages(data.packages);
        }
      }
    } catch (err) {
      console.warn('Using cached initial packages:', err);
    }
  };

  useEffect(() => {
    fetchPackages();
  }, []);

  const handleToggleNotifications = () => {
    setNotificationsEnabled((prev) => {
      const next = !prev;
      localStorage.setItem('blaze_notifications', String(next));
      return next;
    });
  };

  const handlePackageSelected = (pkg: DiamondPackage) => {
    setSelectedPackage(pkg);
    if (verifiedProfile) {
      setCheckoutOpen(true);
    } else {
      const el = document.getElementById('uid-verification-section');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handlePromptVerifyUid = () => {
    const el = document.getElementById('uid-verification-section');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  const handleResetAccount = () => {
    setProceededToStore(false);
    setVerifiedModalOpen(false);
    setVerifiedProfile(null);
    setSelectedPackage(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-b from-[#fff6f8]/60 via-white to-[#f5f8fd]/70 text-slate-900 selection:bg-rose-500 selection:text-white">
      {/* Sticky White Navigation Bar */}
      <Navbar
        onOpenTracker={() => setTrackerOpen(true)}
        onOpenAdmin={() => setAdminOpen(true)}
      />

      <main className="flex-1 space-y-8 sm:space-y-12">
        {proceededToStore && verifiedProfile ? (
          /* ================= STORE VIEW (IMAGE 2) ================= */
          <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6 animate-fade-in">
            {/* Top Verified Player Banner & My Orders (Image 2) */}
            <ToppingUpBanner
              profile={verifiedProfile}
              onChangeAccount={handleResetAccount}
              onOpenOrders={() => setMyOrdersModalOpen(true)}
              onCallAdmin={() => setCallAdminOpen(true)}
              orderCount={sessionOrders.length > 0 ? sessionOrders.length : completedOrdersCount}
            />

            {/* Diamond Packages 3-Column Grid (Image 2) */}
            <DiamondPackages
              packages={packages}
              verifiedProfile={verifiedProfile}
              selectedPackage={selectedPackage}
              onSelectPackage={handlePackageSelected}
              onPromptVerifyUid={handlePromptVerifyUid}
            />

            {/* How It Works & FAQ below store */}
            <div className="pt-8 border-t border-slate-100 space-y-10">
              <HowItWorks />
              <FaqSection />
            </div>
          </div>
        ) : (
          /* ================= INITIAL VERIFICATION VIEW ================= */
          <>
            {/* Promotional Hero Carousel */}
            <HeroCarousel
              onCtaClick={() => {
                const el = document.getElementById('uid-verification-section');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
            />

            {/* Free Fire Game Banner & Trust Guarantee Badges */}
            <GameBanner />

            {/* Top-Up Flow Container */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
              {/* Step 1: UID Verification */}
              <div id="uid-verification-section">
                <UidVerification
                  verifiedProfile={verifiedProfile}
                  onProfileVerified={(profile) => {
                    setVerifiedProfile(profile);
                    // Pop open the exact modal from Image 1!
                    setVerifiedModalOpen(true);
                  }}
                  onClearProfile={() => {
                    setVerifiedProfile(null);
                    setSelectedPackage(null);
                    setProceededToStore(false);
                  }}
                  onOpenModal={() => setVerifiedModalOpen(true)}
                />
              </div>

              {/* Step 2: How it Works */}
              <HowItWorks />

              {/* Step 3: FAQ Accordion */}
              <FaqSection />
            </div>
          </>
        )}
      </main>

      {/* Footer */}
      <Footer
        onOpenPolicy={(policy) => setActivePolicy(policy)}
        onOpenTracker={() => setTrackerOpen(true)}
      />

      {/* ================= VERIFIED ACCOUNT MODAL (IMAGE 1) ================= */}
      {verifiedProfile && (
        <VerifiedAccountModal
          isOpen={verifiedModalOpen}
          profile={verifiedProfile}
          onProceed={() => {
            setVerifiedModalOpen(false);
            setProceededToStore(true);
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          onClose={() => setVerifiedModalOpen(false)}
          onReEnterUid={handleResetAccount}
          onCallAdmin={() => setCallAdminOpen(true)}
        />
      )}

      {/* Live Admin Call Modal */}
      <CallAdminModal
        isOpen={callAdminOpen}
        onClose={() => setCallAdminOpen(false)}
        playerNickname={verifiedProfile?.nickname}
        playerUid={verifiedProfile?.uid}
      />

      {/* Checkout Modal */}
      {checkoutOpen && verifiedProfile && selectedPackage && (
        <CheckoutModal
          isOpen={checkoutOpen}
          onClose={() => setCheckoutOpen(false)}
          verifiedProfile={verifiedProfile}
          selectedPackage={selectedPackage}
          onOrderCompleted={(newOrder) => {
            if (newOrder) {
              setSessionOrders((prev) => [newOrder, ...prev]);
            }
            setCompletedOrdersCount((prev) => prev + 1);
          }}
        />
      )}

      {/* Direct My Orders Modal (shows user's actual purchases without search) */}
      {myOrdersModalOpen && verifiedProfile && (
        <MyOrdersModal
          isOpen={myOrdersModalOpen}
          onClose={() => setMyOrdersModalOpen(false)}
          profile={verifiedProfile}
          sessionOrders={sessionOrders}
          onSelectPackage={() => {
            const el = document.getElementById('top-up-section');
            if (el) el.scrollIntoView({ behavior: 'smooth' });
          }}
        />
      )}

      {/* Order Tracker Modal */}
      {trackerOpen && (
        <OrderTrackerModal
          isOpen={trackerOpen}
          onClose={() => setTrackerOpen(false)}
        />
      )}

      {/* Admin Dashboard Modal */}
      {adminOpen && (
        <AdminDashboardModal
          isOpen={adminOpen}
          onClose={() => setAdminOpen(false)}
          onPackagesUpdated={fetchPackages}
        />
      )}

      {/* Policy Modals */}
      {activePolicy && (
        <PolicyModal policy={activePolicy} onClose={() => setActivePolicy(null)} />
      )}

      {/* Floating Recent Purchases Toast */}
      <RecentPurchasesToast
        enabled={notificationsEnabled}
        onDisable={handleToggleNotifications}
      />
    </div>
  );
}
