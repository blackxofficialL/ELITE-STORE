import type { PlayerProfile, RegionCode } from '../types/index.ts';
import { getVerifiedLocalProfile } from './freeFireIndiaApi.ts';
import { store } from './store.ts';

export interface LookupResult {
  success: boolean;
  profile?: PlayerProfile;
  error?: string;
  statusCode?: number;
  notFound?: boolean;
  canRegisterName?: boolean;
  uid?: string;
  region?: RegionCode;
}

export interface PlayerLookupAdapter {
  id: string;
  name: string;
  isConfigured: () => boolean;
  lookup: (uid: string, region: RegionCode) => Promise<LookupResult>;
}

export const PRIMARY_API_URL = 'https://infoooooo-v6v5.vercel.app/accinfo';

/**
 * Public Free Fire Mirror Endpoints for redundancy
 */
const PUBLIC_LOOKUP_MIRRORS = [
  'https://free-ff-api-src-5plp.onrender.com/api/v1/account',
  'https://r-gengpt-api.vercel.app/api/freefire/info',
];

/**
 * Normalizes the response from https://infoooooo-v6v5.vercel.app/accinfo?uid=...
 */
export function normalizeInfoVercelResponse(data: any, fallbackUid: string, defaultRegion: RegionCode): PlayerProfile | null {
  if (!data || typeof data !== 'object') return null;

  const basic = data.basicInfo;
  if (!basic || !basic.accountId) return null;

  const uid = String(basic.accountId);
  const nickname = String(basic.nickname || '').trim();
  if (!nickname) return null;

  const region = (basic.region || defaultRegion || 'IND').toUpperCase() as RegionCode;
  const level = Number(basic.level) || 1;
  const exp = Number(basic.exp) || 0;
  const likes = typeof basic.liked === 'number' ? basic.liked : 0;
  const headPic = basic.headPic ? Number(basic.headPic) : undefined;
  const bannerId = basic.bannerId ? Number(basic.bannerId) : undefined;

  const avatarUrl = headPic ? `https://freefireinfo.in/images/avatars/${headPic}.png` : undefined;
  const bannerUrl = bannerId ? `https://freefireinfo.in/images/banners/${bannerId}.png` : undefined;

  const rankingPoints = typeof basic.rankingPoints === 'number' ? basic.rankingPoints : undefined;
  const rank = rankingPoints
    ? `Heroic (${rankingPoints} Pts)`
    : level >= 70
    ? 'Grandmaster'
    : level >= 50
    ? 'Heroic'
    : 'Diamond';

  const signature =
    data.socialInfo?.signature ||
    'Free Fire MAX Verified Player';

  const hasVBadge = Boolean(
    basic.title === 904590059 ||
    level >= 75 ||
    (data.primeInfo && data.primeInfo.primeLevel && data.primeInfo.primeLevel >= 3)
  );

  return {
    uid,
    region,
    nickname,
    level,
    exp,
    likes,
    headPic,
    bannerId,
    avatarUrl,
    bannerUrl,
    rank,
    rankScore: rankingPoints || 3500 + level * 25,
    csRank: level >= 70 ? 'Master 25★' : 'Master 10★',
    signature,
    hasVBadge,
    badge: basic.badgeCnt ? `${basic.badgeCnt} Badges` : 'Heroic',
    verifiedAt: new Date().toISOString(),
    provider: 'info_vercel_api',
  };
}

/**
 * Extract nickname and profile details from other diverse API JSON formats
 */
function extractProfileFromApiResponse(data: any, uid: string, region: RegionCode): PlayerProfile | null {
  if (!data || typeof data !== 'object') return null;

  // Check if it's the infoooooo format
  const infoVercel = normalizeInfoVercelResponse(data, uid, region);
  if (infoVercel) return infoVercel;

  const nickname =
    data.AccountName ||
    data.account_name ||
    data.nickname ||
    data.name ||
    data.username ||
    data.player_name ||
    data.basicInfo?.nickname ||
    data.data?.AccountName ||
    data.data?.nickname ||
    data.profile?.nickname;

  if (!nickname || typeof nickname !== 'string' || nickname.trim().length === 0) {
    return null;
  }

  const cleanName = nickname.trim();
  const level =
    data.AccountLevel ||
    data.account_level ||
    data.level ||
    data.basicInfo?.level ||
    data.data?.level ||
    50;

  const likes =
    data.AccountLikes ||
    data.likes ||
    data.basicInfo?.liked ||
    1000;

  return {
    uid,
    region,
    nickname: cleanName,
    level: Number(level) || 50,
    likes: Number(likes) || 1000,
    rank: 'Heroic',
    rankScore: 3500 + Number(level) * 25,
    csRank: Number(level) >= 70 ? 'Master 25★' : 'Master 10★',
    signature: 'Verified Free Fire Player • Elite Store',
    hasVBadge: Boolean(data.hasVBadge || Number(level) >= 75),
    badge: 'Heroic',
    verifiedAt: new Date().toISOString(),
    provider: 'external_api',
  };
}

/**
 * Free Fire Player UID Lookup Engine using infoooooo-v6v5.vercel.app
 */
export class FreeFireLookupEngine implements PlayerLookupAdapter {
  id = 'freefire_info_engine';
  name = 'Free Fire MAX India Live API';

  isConfigured(): boolean {
    return true;
  }

  async lookup(uid: string, region: RegionCode = 'IND'): Promise<LookupResult> {
    // 1. Primary Verified API Endpoint: https://infoooooo-v6v5.vercel.app/accinfo?uid=USER_UID
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000);

      const targetUrl = `${PRIMARY_API_URL}?uid=${encodeURIComponent(uid)}`;
      const res = await fetch(targetUrl, {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko)',
        },
        signal: controller.signal,
      });

      clearTimeout(timeoutId);

      const responseText = await res.text();
      let data: any = null;
      try {
        data = JSON.parse(responseText);
      } catch {
        console.warn('[Lookup] Primary API returned non-JSON:', responseText.slice(0, 200));
      }

      if (res.ok && data) {
        const profile = normalizeInfoVercelResponse(data, uid, region);
        if (profile) {
          store.setCustomProfile(profile);
          store.addLog('uid_lookup', `Verified real player UID ${uid} (${profile.nickname}) via Primary API`);
          return {
            success: true,
            profile,
            uid: profile.uid,
            region: profile.region,
          };
        }
      }

      // If API returned 404 or explicit error message
      if (res.status === 404 || (data && data.error)) {
        const errMsg = data?.error || `Free Fire player UID ${uid} was not found on the game server.`;
        store.addLog('uid_lookup', `Lookup not found for UID ${uid}: ${errMsg}`);
        return {
          success: false,
          statusCode: 404,
          notFound: true,
          error: errMsg,
          uid,
          region,
        };
      }
    } catch (err: any) {
      console.warn(`[Lookup] Primary API error for UID ${uid}:`, err.message);
    }

    // 2. Check local verified database (for known pro accounts or admin registered accounts)
    const localProfile = getVerifiedLocalProfile(uid, region);
    if (localProfile) {
      store.addLog('uid_lookup', `UID ${uid} found in verified database: ${localProfile.nickname}`);
      return {
        success: true,
        profile: localProfile,
        uid: localProfile.uid,
        region: localProfile.region,
      };
    }

    // 3. Fallback to secondary mirrors if primary had a network issue
    for (const mirrorUrl of PUBLIC_LOOKUP_MIRRORS) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 4000);

        const url = `${mirrorUrl}?uid=${encodeURIComponent(uid)}&region=${encodeURIComponent(region)}`;
        const res = await fetch(url, {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          },
          signal: controller.signal,
        });

        clearTimeout(timeoutId);

        if (res.ok) {
          const data = await res.json();
          const profile = extractProfileFromApiResponse(data, uid, region);
          if (profile) {
            store.setCustomProfile(profile);
            store.addLog('uid_lookup', `UID ${uid} verified via mirror ${mirrorUrl}: ${profile.nickname}`);
            return {
              success: true,
              profile,
              uid: profile.uid,
              region: profile.region,
            };
          }
        }
      } catch {
        // Silently continue
      }
    }

    // 4. If all fail, return clean error message without any fake details
    store.addLog('uid_lookup', `UID ${uid} could not be verified on remote game servers.`);
    return {
      success: false,
      statusCode: 404,
      notFound: true,
      uid,
      region,
      error: `Player UID ${uid} was not found or could not be verified. Please check your numeric in-game ID and try again.`,
    };
  }
}

/**
 * Returns active lookup adapter instance
 */
export function getActiveLookupAdapter(): PlayerLookupAdapter {
  return new FreeFireLookupEngine();
}
