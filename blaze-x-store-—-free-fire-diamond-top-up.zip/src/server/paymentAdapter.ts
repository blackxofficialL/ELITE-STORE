import crypto from 'node:crypto';

export interface PaymentGatewayConfig {
  isConfigured: boolean;
  provider: 'razorpay' | 'sandbox';
  keyId: string;
}

export interface PaymentVerificationResult {
  verified: boolean;
  error?: string;
  paymentId?: string;
  paymentMethod?: string;
}

export class PaymentAdapter {
  private keyId: string;
  private keySecret: string;
  private isSandbox: boolean;

  constructor() {
    this.keyId = process.env.RAZORPAY_KEY_ID || '';
    this.keySecret = process.env.RAZORPAY_KEY_SECRET || '';
    this.isSandbox = !Boolean(this.keyId && this.keySecret);
  }

  public getConfig(): PaymentGatewayConfig {
    return {
      isConfigured: !this.isSandbox,
      provider: this.isSandbox ? 'sandbox' : 'razorpay',
      keyId: this.isSandbox ? 'rzp_test_blazex_demo' : this.keyId,
    };
  }

  /**
   * Generates a payment order token for checkout
   */
  public async createGatewayOrder(orderId: string, amountINR: number): Promise<{
    gatewayOrderId: string;
    amount: number;
    currency: string;
    keyId: string;
  }> {
    const amountInPaise = Math.round(amountINR * 100);

    if (!this.isSandbox) {
      // Real Razorpay API call
      try {
        const auth = Buffer.from(`${this.keyId}:${this.keySecret}`).toString('base64');
        const res = await fetch('https://api.razorpay.com/v1/orders', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Basic ${auth}`,
          },
          body: JSON.stringify({
            amount: amountInPaise,
            currency: 'INR',
            receipt: orderId,
            notes: {
              store: 'ELITE STORE',
              orderId,
            },
          }),
        });

        if (res.ok) {
          const data = await res.json();
          return {
            gatewayOrderId: data.id,
            amount: data.amount,
            currency: data.currency,
            keyId: this.keyId,
          };
        }
      } catch (err) {
        console.error('Razorpay live order creation failed, falling back to secure sandbox:', err);
      }
    }

    // Secure Sandbox Order
    const gatewayOrderId = `order_${Math.random().toString(36).substring(2, 14)}`;
    return {
      gatewayOrderId,
      amount: amountInPaise,
      currency: 'INR',
      keyId: 'rzp_test_blazex_demo',
    };
  }

  /**
   * Cryptographically verifies the payment signature
   */
  public verifyPaymentSignature(params: {
    gatewayOrderId: string;
    paymentId: string;
    signature: string;
  }): PaymentVerificationResult {
    const { gatewayOrderId, paymentId, signature } = params;

    if (!gatewayOrderId || !paymentId || !signature) {
      return {
        verified: false,
        error: 'Missing required payment verification parameters (orderId, paymentId, signature)',
      };
    }

    const payload = `${gatewayOrderId}|${paymentId}`;
    const secret = this.isSandbox ? 'blaze_sandbox_secret_salt_2026' : this.keySecret;

    const expectedSignature = crypto
      .createHmac('sha256', secret)
      .update(payload)
      .digest('hex');

    // Constant-time comparison to prevent timing attacks
    const expectedBuf = Buffer.from(expectedSignature, 'utf8');
    const actualBuf = Buffer.from(signature, 'utf8');

    if (expectedBuf.length !== actualBuf.length || !crypto.timingSafeEqual(expectedBuf, actualBuf)) {
      return {
        verified: false,
        error: 'Payment signature validation failed. Potential transaction tampering detected.',
      };
    }

    return {
      verified: true,
      paymentId,
      paymentMethod: 'UPI / Razorpay Verified',
    };
  }

  /**
   * Generates a client-signed test signature for sandbox verification
   */
  public generateSandboxSignature(gatewayOrderId: string, paymentId: string): string {
    const payload = `${gatewayOrderId}|${paymentId}`;
    return crypto
      .createHmac('sha256', 'blaze_sandbox_secret_salt_2026')
      .update(payload)
      .digest('hex');
  }
}

export const paymentAdapter = new PaymentAdapter();
