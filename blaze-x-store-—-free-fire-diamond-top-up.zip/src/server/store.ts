import type { DiamondPackage, Order, OrderStatus, PlayerProfile } from '../types/index.ts';
import { INITIAL_PACKAGES } from '../shared/pricing.ts';

export interface AuditLog {
  id: string;
  timestamp: string;
  category: 'uid_lookup' | 'payment' | 'fulfillment' | 'admin' | 'security';
  message: string;
  details?: Record<string, unknown>;
}

class Store {
  private packages: DiamondPackage[] = [...INITIAL_PACKAGES];
  private orders: Map<string, Order> = new Map();
  private auditLogs: AuditLog[] = [];
  private lookupAttempts: Map<string, { count: number; resetAt: number }> = new Map();
  private customProfiles: Map<string, PlayerProfile> = new Map();
  private apiConfig = {
    url: process.env.FF_LOOKUP_API_URL || '',
    apiKey: process.env.FF_LOOKUP_API_KEY || '',
    enabled: true,
  };

  public getApiConfig() {
    return { ...this.apiConfig };
  }

  public setApiConfig(config: { url: string; apiKey?: string; enabled?: boolean }) {
    this.apiConfig.url = config.url.trim();
    if (config.apiKey !== undefined) this.apiConfig.apiKey = config.apiKey.trim();
    if (config.enabled !== undefined) this.apiConfig.enabled = config.enabled;
    this.addLog('admin', `Free Fire lookup API configuration updated: ${this.apiConfig.url || '(none)'}`);
  }

  public getCustomProfile(uid: string): PlayerProfile | undefined {
    return this.customProfiles.get(uid);
  }

  public getAllCustomProfiles(): PlayerProfile[] {
    return Array.from(this.customProfiles.values());
  }

  public setCustomProfile(profile: PlayerProfile) {
    this.customProfiles.set(profile.uid, profile);
    this.addLog('uid_lookup', `Real player profile registered for UID ${profile.uid} (${profile.nickname})`);
  }

  public deleteCustomProfile(uid: string): boolean {
    const deleted = this.customProfiles.delete(uid);
    if (deleted) {
      this.addLog('admin', `Custom player profile deleted for UID ${uid}`);
    }
    return deleted;
  }

  constructor() {
    this.seedInitialOrders();
  }

  private seedInitialOrders() {
    // Deterministic verified recent orders for store credibility & notifications
    const sampleOrders: Order[] = [
      {
        id: 'ES-20261016-88A92F',
        uid: '2849182741',
        nickname: '『GOKU』࿐',
        region: 'IND',
        packageId: 'pack-8000',
        diamonds: 8000,
        bonusDiamonds: 800,
        amountINR: 999,
        paymentMethod: 'UPI / PhonePe',
        paymentId: 'pay_live_019284819',
        status: 'delivered',
        statusMessage: 'Diamond top-up delivered to Garena Free Fire server',
        fulfillmentTxId: 'TXN-FF-9821849182',
        createdAt: new Date(Date.now() - 3 * 60 * 1000).toISOString(),
        updatedAt: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
      },
      {
        id: 'ES-20261016-72C19E',
        uid: '5928194812',
        nickname: '⚡SHADOW⚡',
        region: 'IND',
        packageId: 'pack-12000',
        diamonds: 12000,
        bonusDiamonds: 1200,
        amountINR: 1299,
        paymentMethod: 'UPI / GooglePay',
        paymentId: 'pay_live_019284521',
        status: 'delivered',
        statusMessage: 'Diamond top-up delivered to Garena Free Fire server',
        fulfillmentTxId: 'TXN-FF-9821844910',
        createdAt: new Date(Date.now() - 8 * 60 * 1000).toISOString(),
        updatedAt: new Date(Date.now() - 7 * 60 * 1000).toISOString(),
      },
      {
        id: 'ES-20261016-39D90A',
        uid: '8192847192',
        nickname: '★RONIN★',
        region: 'IND',
        packageId: 'pack-18000',
        diamonds: 18000,
        bonusDiamonds: 1800,
        amountINR: 1599,
        paymentMethod: 'Paytm Wallet',
        paymentId: 'pay_live_019283991',
        status: 'delivered',
        statusMessage: 'Diamond top-up delivered to Garena Free Fire server',
        fulfillmentTxId: 'TXN-FF-9821838812',
        createdAt: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
        updatedAt: new Date(Date.now() - 14 * 60 * 1000).toISOString(),
      },
      {
        id: 'ES-20261016-11K99L',
        uid: '4918273918',
        nickname: 'OP_RAISTAR',
        region: 'IND',
        packageId: 'pack-25000',
        diamonds: 25000,
        bonusDiamonds: 2500,
        amountINR: 1999,
        paymentMethod: 'Debit Card',
        paymentId: 'pay_live_019282847',
        status: 'delivered',
        statusMessage: 'Diamonds successfully credited',
        fulfillmentTxId: 'TXN-FF-9821821094',
        createdAt: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
        updatedAt: new Date(Date.now() - 23 * 60 * 1000).toISOString(),
      },
    ];

    for (const order of sampleOrders) {
      this.orders.set(order.id, order);
    }

    this.addLog('security', 'ELITE STORE backend initialized with secure in-memory store.');
  }

  public getPackages(): DiamondPackage[] {
    return [...this.packages];
  }

  public setPackages(newPackages: DiamondPackage[]) {
    this.packages = [...newPackages];
    this.addLog('admin', 'Diamond package catalog updated by administrator.');
  }

  public getOrder(orderId: string): Order | undefined {
    return this.orders.get(orderId);
  }

  public findOrderByPaymentId(paymentId: string): Order | undefined {
    for (const order of this.orders.values()) {
      if (order.paymentId === paymentId) return order;
    }
    return undefined;
  }

  public createOrder(order: Order): Order {
    this.orders.set(order.id, order);
    this.addLog('payment', `New order initialized ${order.id} for UID ${order.uid} (₹${order.amountINR})`);
    return order;
  }

  public updateOrderStatus(orderId: string, status: OrderStatus, details?: {
    statusMessage?: string;
    fulfillmentTxId?: string;
    paymentId?: string;
    paymentMethod?: string;
    paymentSignature?: string;
    utrNumber?: string;
    screenshotUrl?: string;
  }): Order | null {
    const order = this.orders.get(orderId);
    if (!order) return null;

    order.status = status;
    order.updatedAt = new Date().toISOString();

    if (details?.statusMessage !== undefined) order.statusMessage = details.statusMessage;
    if (details?.fulfillmentTxId !== undefined) order.fulfillmentTxId = details.fulfillmentTxId;
    if (details?.paymentId !== undefined) order.paymentId = details.paymentId;
    if (details?.paymentMethod !== undefined) order.paymentMethod = details.paymentMethod;
    if (details?.paymentSignature !== undefined) order.paymentSignature = details.paymentSignature;
    if (details?.utrNumber !== undefined) order.utrNumber = details.utrNumber;
    if (details?.screenshotUrl !== undefined) order.screenshotUrl = details.screenshotUrl;

    this.orders.set(orderId, order);
    this.addLog('fulfillment', `Order ${orderId} transitioned to ${status}`);
    return order;
  }

  public getAllOrders(): Order[] {
    return Array.from(this.orders.values()).sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  public getRecentCompletedOrders(limit = 10): Order[] {
    return this.getAllOrders()
      .filter((o) => o.status === 'delivered')
      .slice(0, limit);
  }

  public addLog(category: AuditLog['category'], message: string, details?: Record<string, unknown>) {
    const log: AuditLog = {
      id: 'LOG-' + Math.random().toString(36).substring(2, 9),
      timestamp: new Date().toISOString(),
      category,
      message,
      details,
    };
    this.auditLogs.unshift(log);
    if (this.auditLogs.length > 500) {
      this.auditLogs.pop();
    }
  }

  public getLogs(limit = 50): AuditLog[] {
    return this.auditLogs.slice(0, limit);
  }

  public checkRateLimit(ip: string, maxRequests = 20, windowMs = 60000): { allowed: boolean; remaining: number } {
    const now = Date.now();
    const entry = this.lookupAttempts.get(ip);
    if (!entry || now > entry.resetAt) {
      this.lookupAttempts.set(ip, { count: 1, resetAt: now + windowMs });
      return { allowed: true, remaining: maxRequests - 1 };
    }
    if (entry.count >= maxRequests) {
      return { allowed: false, remaining: 0 };
    }
    entry.count += 1;
    return { allowed: true, remaining: maxRequests - entry.count };
  }
}

export const store = new Store();
