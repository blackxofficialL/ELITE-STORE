import React, { useState } from 'react';
import { ChevronDown, HelpCircle, ShieldCheck } from 'lucide-react';

interface FaqItem {
  question: string;
  answer: string;
}

const FAQS: FaqItem[] = [
  {
    question: 'Is this store safe and genuine?',
    answer:
      'Yes, 100%. ELITE STORE uses direct Free Fire server handshake protocols via Player UID. We never ask for your game password, OTP, Facebook/Google credentials, or personal information. All transactions are protected with 256-bit bank-grade encryption.',
  },
  {
    question: 'How fast is delivery?',
    answer:
      'Diamond delivery is instant! Once your payment is verified by our payment gateway (typically 5 to 15 seconds), our automated queue immediately dispatches the top-up instruction to the game servers. Diamonds will arrive directly in your Free Fire in-game mailbox right away.',
  },
  {
    question: 'Which payment methods are supported?',
    answer:
      'We support all major Indian & international payment methods including UPI (Google Pay, PhonePe, Paytm, BHIM, QR code), Debit/Credit Cards (Visa, Mastercard, RuPay), NetBanking from 50+ banks, and popular digital wallets with ₹0 convenience fee.',
  },
  {
    question: 'How do refunds work?',
    answer:
      'If an order cannot be fulfilled due to prolonged game server downtime or unresolvable account restrictions, a full 100% refund is initiated back to your original payment method within 24 hours. Contact our 24/7 support with your Order ID for immediate escalation.',
  },
];

export const FaqSection: React.FC = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleIndex = (idx: number) => {
    setOpenIndex(openIndex === idx ? null : idx);
  };

  return (
    <div id="faq-section" className="w-full py-8">
      <div className="text-center max-w-2xl mx-auto mb-8 space-y-2">
        <span className="text-xs font-extrabold uppercase tracking-widest text-rose-500 bg-rose-50 dark:bg-rose-950/60 px-3 py-1 rounded-full border border-rose-200 dark:border-rose-900/40">
          CLEAR ANSWERS
        </span>
        <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-['Rajdhani']">
          FREQUENTLY ASKED QUESTIONS
        </h3>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
          Everything you need to know about Free Fire diamond top-ups at ELITE STORE.
        </p>
      </div>

      <div className="max-w-3xl mx-auto space-y-3">
        {FAQS.map((faq, idx) => {
          const isOpen = openIndex === idx;
          return (
            <div
              key={idx}
              className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden transition-all shadow-sm"
            >
              <button
                type="button"
                onClick={() => toggleIndex(idx)}
                className="w-full p-4 sm:p-5 text-left flex items-center justify-between gap-4 font-extrabold text-sm sm:text-base text-slate-900 dark:text-white hover:text-rose-600 dark:hover:text-rose-400 transition-colors"
                aria-expanded={isOpen}
              >
                <span className="font-['Rajdhani'] tracking-wide">{faq.question}</span>
                <ChevronDown
                  className={`w-4 h-4 text-slate-400 transition-transform duration-200 flex-shrink-0 ${
                    isOpen ? 'rotate-180 text-rose-500' : ''
                  }`}
                />
              </button>

              {isOpen && (
                <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed border-t border-slate-100 dark:border-slate-800/60">
                  {faq.answer}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
