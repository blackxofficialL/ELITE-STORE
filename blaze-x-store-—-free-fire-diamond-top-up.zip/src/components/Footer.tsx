import React from 'react';
import { Flame, ShieldCheck, Heart, Sparkles } from 'lucide-react';
import { PolicyType } from './PolicyModals.tsx';

interface FooterProps {
  onOpenPolicy: (policy: PolicyType) => void;
  onOpenTracker: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenPolicy, onOpenTracker }) => {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id) || document.getElementById('uid-verification-section');
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-white dark:bg-slate-950 border-t border-slate-200 dark:border-slate-800 transition-colors pt-12 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {/* Brand Info */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-rose-600 via-orange-500 to-amber-400 p-0.5 shadow-md flex-shrink-0 overflow-hidden relative flex items-center justify-center">
                <div className="w-full h-full bg-slate-950 rounded-[14px] flex items-center justify-center">
                  <Flame className="w-5 h-5 text-rose-500 fill-rose-500" />
                </div>
                <img
                  src="/logo.png"
                  alt="ELITE STORE Logo"
                  className="w-full h-full object-cover absolute inset-0 z-10 rounded-[14px]"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).style.display = 'none';
                  }}
                />
              </div>
              <span className="font-extrabold text-2xl tracking-wider text-slate-900 dark:text-white font-['Rajdhani']">
                ELITE<span className="text-rose-500"> </span>STORE
              </span>
            </div>

            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed max-w-sm">
              India&apos;s premier, ban-safe Free Fire diamond top-up platform. Experience instant server-to-server delivery, bank-grade encryption, and guaranteed player satisfaction.
            </p>

            <div className="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-slate-300">
              <ShieldCheck className="w-4 h-4 text-emerald-500" />
              <span>100% Ban-Safe & Official UID Top-Up Protocol</span>
            </div>
          </div>

          {/* Store Section */}
          <div className="space-y-3">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-900 dark:text-white font-['Rajdhani']">
              Diamond Store
            </h4>
            <ul className="space-y-2 text-xs text-slate-500 dark:text-slate-400">
              <li>
                <button
                  onClick={() => scrollTo('top-up-section')}
                  className="hover:text-rose-500 transition-colors"
                >
                  100 to 5600 Diamond Packs
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('top-up-section')}
                  className="hover:text-rose-500 transition-colors"
                >
                  Weekly Membership Pass
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('top-up-section')}
                  className="hover:text-rose-500 transition-colors"
                >
                  Monthly VIP Elite Pass
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('top-up-section')}
                  className="hover:text-rose-500 transition-colors"
                >
                  Bonus Diamond Offers
                </button>
              </li>
            </ul>
          </div>

          {/* Help Section */}
          <div className="space-y-3">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-900 dark:text-white font-['Rajdhani']">
              Help & Support
            </h4>
            <ul className="space-y-2 text-xs text-slate-500 dark:text-slate-400">
              <li>
                <button
                  onClick={() => scrollTo('top-up-section')}
                  className="hover:text-rose-500 transition-colors"
                >
                  Verify Player UID
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('how-it-works')}
                  className="hover:text-rose-500 transition-colors"
                >
                  How Top-Up Works
                </button>
              </li>
              <li>
                <button
                  onClick={() => scrollTo('faq-section')}
                  className="hover:text-rose-500 transition-colors"
                >
                  Frequently Asked Questions
                </button>
              </li>
            </ul>
          </div>

          {/* Legal Section */}
          <div className="space-y-3">
            <h4 className="text-xs font-extrabold uppercase tracking-wider text-slate-900 dark:text-white font-['Rajdhani']">
              Legal & Safety
            </h4>
            <ul className="space-y-2 text-xs text-slate-500 dark:text-slate-400">
              <li>
                <button
                  onClick={() => onOpenPolicy('terms')}
                  className="hover:text-rose-500 transition-colors"
                >
                  Terms of Service
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenPolicy('privacy')}
                  className="hover:text-rose-500 transition-colors"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenPolicy('refund')}
                  className="hover:text-rose-500 transition-colors"
                >
                  Refund & Cancellation
                </button>
              </li>
              <li>
                <button
                  onClick={() => onOpenPolicy('contact')}
                  className="hover:text-rose-500 transition-colors"
                >
                  Contact Squad
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Payment Methods Bar & Disclaimer */}
        <div className="pt-6 border-t border-slate-100 dark:border-slate-800/80 space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-xs text-slate-400">
              <span>Accepted Payments:</span>
              <span className="font-bold text-slate-600 dark:text-slate-300">
                UPI • Google Pay • PhonePe • Paytm • Visa • Mastercard • RuPay • NetBanking
              </span>
            </div>

            <p className="text-[11px] text-slate-400">
              © {new Date().getFullYear()} ELITE STORE. All rights reserved.
            </p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 text-[10px] text-slate-400 leading-normal text-center">
            <strong>Disclaimer:</strong> ELITE STORE is an independent e-commerce platform providing Free Fire diamond top-up services via official Player UID handshakes. Garena, Free Fire, and Free Fire MAX are registered trademarks of Garena International Ltd. This site is not officially affiliated with or endorsed by Garena.
          </div>
        </div>
      </div>
    </footer>
  );
};
