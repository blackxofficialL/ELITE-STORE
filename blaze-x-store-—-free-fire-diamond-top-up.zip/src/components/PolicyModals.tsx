import React from 'react';
import { ShieldCheck, FileText, CheckCircle2, RotateCcw } from 'lucide-react';

export type PolicyType = 'terms' | 'privacy' | 'refund' | 'contact' | null;

interface PolicyModalProps {
  policy: PolicyType;
  onClose: () => void;
}

export const PolicyModal: React.FC<PolicyModalProps> = ({ policy, onClose }) => {
  if (!policy) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-2xl w-full max-h-[85vh] overflow-y-auto shadow-2xl border border-slate-200 dark:border-slate-800 transition-colors">
        <div className="sticky top-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-rose-500/10 text-rose-500 flex items-center justify-center">
              <FileText className="w-4 h-4" />
            </div>
            <h3 className="text-lg font-extrabold text-slate-900 dark:text-white font-['Rajdhani'] uppercase">
              {policy === 'terms' && 'Terms of Service'}
              {policy === 'privacy' && 'Privacy Policy'}
              {policy === 'refund' && 'Refund & Cancellation Policy'}
              {policy === 'contact' && 'Contact Support'}
            </h3>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white flex items-center justify-center text-sm font-bold"
          >
            ✕
          </button>
        </div>

        <div className="p-6 text-xs sm:text-sm text-slate-600 dark:text-slate-300 space-y-4 leading-relaxed">
          {policy === 'terms' && (
            <>
              <p>
                <strong>1. Acceptance of Terms:</strong> By accessing and using ELITE STORE, you agree to comply with and be bound by these Terms of Service.
              </p>
              <p>
                <strong>2. Player UID Accuracy:</strong> Top-up credits are dispatched directly to the numeric Player UID provided and verified during checkout. ELITE STORE is not responsible for diamonds credited to wrong accounts if the user approves an incorrect verified UID.
              </p>
              <p>
                <strong>3. Garena & Trademark Notice:</strong> ELITE STORE is an independent e-commerce gaming storefront. Free Fire, Free Fire MAX, and Garena are registered trademarks of Garena International.
              </p>
              <p>
                <strong>4. Account Safety:</strong> We will never ask for your in-game passwords, social media logins, or one-time verification passcodes (OTPs).
              </p>
            </>
          )}

          {policy === 'privacy' && (
            <>
              <p>
                <strong>1. Information Collection:</strong> We collect only necessary operational information: Player UID, selected server region, and payment transaction identifiers required to complete your top-up.
              </p>
              <p>
                <strong>2. No Sensitive Banking Storage:</strong> Card numbers, CVVs, and banking passwords are never processed or stored on our servers. All payments are securely tokenized through authorized payment gateways.
              </p>
              <p>
                <strong>3. Public Notification Anonymization:</strong> Real purchase alerts strictly mask player UIDs (e.g. 284****41) to safeguard user privacy and prevent harassment.
              </p>
            </>
          )}

          {policy === 'refund' && (
            <>
              <p>
                <strong>1. Eligible Circumstances:</strong> Refunds are processed if your payment was successfully deducted but game servers fail to credit diamonds within 2 hours, and our automatic retry queue cannot fulfill the order.
              </p>
              <p>
                <strong>2. Non-Refundable Items:</strong> Once Free Fire server transaction confirmation (Fulfillment TxID) has been issued and diamonds are received in the in-game account, the digital goods are considered consumed and cannot be reversed or refunded.
              </p>
              <p>
                <strong>3. Refund Timeline:</strong> Approved refunds are credited directly back to the original source account (UPI, Bank Account, or Card) within 24 to 48 hours.
              </p>
            </>
          )}

          {policy === 'contact' && (
            <div className="space-y-3">
              <p>Need assistance with an existing order or business inquiry? Our support squad is available 24/7:</p>
              <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2 text-xs">
                <p>
                  <strong>Email:</strong> support@elitestore.com
                </p>
                <p>
                  <strong>WhatsApp Helpline:</strong> +91 98200 XXXXX (Available 10 AM - 10 PM IST)
                </p>
                <p>
                  <strong>Average Response Time:</strong> Under 5 minutes during peak gaming hours
                </p>
              </div>
            </div>
          )}

          <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={onClose}
              className="w-full py-2.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-bold text-xs"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
