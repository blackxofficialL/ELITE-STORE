import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import {
  DiamondPackage,
  PlayerProfile,
  Order,
} from '../types/index.ts';
import {
  ShieldCheck,
  Lock,
  Loader2,
  CheckCircle2,
  AlertTriangle,
  QrCode,
  ArrowRight,
  Flame,
  Copy,
  Check,
  RotateCcw,
  Upload,
  Image as ImageIcon,
  ExternalLink,
  ChevronLeft,
} from 'lucide-react';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  verifiedProfile: PlayerProfile;
  selectedPackage: DiamondPackage;
  onOrderCompleted: (order: Order) => void;
}

const OFFICIAL_UPI_ID = 'freelance.h@pthdfc';
const PAYEE_NAME = 'ELITE STORE';

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  verifiedProfile,
  selectedPackage,
  onOrderCompleted,
}) => {
  // Steps: 'qr' (Scan & Pay) | 'confirm' (Enter UTR & Upload Screenshot) | 'verifying' | 'success' | 'error'
  const [step, setStep] = useState<'qr' | 'confirm' | 'verifying' | 'success' | 'error'>('qr');
  const [utrNumber, setUtrNumber] = useState('');
  const [screenshotPreview, setScreenshotPreview] = useState<string | null>(null);
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [copiedOrderId, setCopiedOrderId] = useState(false);
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');

  // Generate UPI payment intent URI
  const upiUri = `upi://pay?pa=${encodeURIComponent(OFFICIAL_UPI_ID)}&pn=${encodeURIComponent(
    PAYEE_NAME
  )}&am=${selectedPackage.priceINR}&cu=INR&tn=${encodeURIComponent(
    `FF-${verifiedProfile.uid}-${selectedPackage.diamonds}`
  )}`;

  // Generate QR code locally in 0 milliseconds (no external network latency or delay)
  useEffect(() => {
    let isMounted = true;
    QRCode.toDataURL(upiUri, {
      width: 280,
      margin: 1,
      errorCorrectionLevel: 'M',
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
    })
      .then((url) => {
        if (isMounted) setQrCodeDataUrl(url);
      })
      .catch((err) => {
        console.error('Failed to generate local QR code:', err);
      });

    return () => {
      isMounted = false;
    };
  }, [upiUri]);

  if (!isOpen) return null;

  const handleCopyUpi = () => {
    navigator.clipboard.writeText(OFFICIAL_UPI_ID);
    setCopiedUpi(true);
    setTimeout(() => setCopiedUpi(false), 2000);
  };

  const handleCopyOrderId = () => {
    if (!createdOrder) return;
    navigator.clipboard.writeText(createdOrder.id);
    setCopiedOrderId(true);
    setTimeout(() => setCopiedOrderId(false), 2000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setScreenshotPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmitPayment = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!screenshotPreview) {
      setErrorMessage('Payment screenshot is required! Please upload your payment screenshot to proceed.');
      return;
    }

    setErrorMessage(null);
    setIsSubmitting(true);
    setStep('verifying');

    try {
      // 1. Create order on backend
      const createRes = await fetch('/api/orders/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          uid: verifiedProfile.uid,
          region: verifiedProfile.region,
          nickname: verifiedProfile.nickname,
          packageId: selectedPackage.id,
        }),
      });

      const createData = await createRes.json();
      if (!createRes.ok || !createData.success) {
        setErrorMessage(createData.error || 'Failed to initialize order on server');
        setStep('error');
        setIsSubmitting(false);
        return;
      }

      const order: Order = createData.order;

      // 2. Verify with backend using UTR & Screenshot
      const cleanUtr = utrNumber.trim() || `MANUAL-${Date.now()}`;
      const verifyRes = await fetch('/api/orders/verify-payment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          orderId: order.id,
          gatewayOrderId: order.id,
          paymentId: `UPI_${cleanUtr}`,
          signature: `UTR:${cleanUtr}`,
          paymentMethod: `UPI QR (${OFFICIAL_UPI_ID})`,
          utrNumber: cleanUtr,
          screenshotUrl: screenshotPreview || undefined,
        }),
      });

      const verifyData = await verifyRes.json();
      if (!verifyRes.ok || !verifyData.success) {
        setErrorMessage(verifyData.error || 'Payment verification failed.');
        setStep('error');
        setIsSubmitting(false);
        return;
      }

      const completedOrder: Order = {
        ...verifyData.order,
        utrNumber: cleanUtr,
      };

      setCreatedOrder(completedOrder);
      setStep('success');
      onOrderCompleted(completedOrder);
    } catch (err) {
      setErrorMessage('Network error while verifying payment. Please try again.');
      setStep('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-slate-950/75 backdrop-blur-sm animate-fade-in select-none">
      <div className="bg-white dark:bg-slate-900 rounded-2xl sm:rounded-3xl max-w-lg w-full max-h-[96vh] sm:max-h-[90vh] overflow-y-auto shadow-2xl border border-slate-200 dark:border-slate-800 transition-colors">
        {/* Header */}
        <div className="sticky top-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md px-3.5 py-2.5 sm:px-6 sm:py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-lg sm:rounded-xl bg-gradient-to-tr from-rose-500 to-orange-500 flex items-center justify-center text-white shadow-sm">
              <Lock className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            </div>
            <div>
              <h3 className="text-sm sm:text-lg font-extrabold text-slate-900 dark:text-white font-['Rajdhani'] leading-tight">
                {step === 'success'
                  ? 'PAYMENT SUCCESSFUL'
                  : step === 'confirm'
                  ? 'CONFIRM PAYMENT'
                  : 'UPI QR PAYMENT'}
              </h3>
              <p className="hidden sm:block text-[11px] text-slate-500 dark:text-slate-400">
                Official Free Fire Top-Up • Instant Mailbox Delivery
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-7 h-7 sm:w-8 sm:h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white flex items-center justify-center text-xs sm:text-sm font-bold cursor-pointer transition-colors"
            aria-label="Close"
          >
            ✕
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-3.5 sm:p-6 space-y-3 sm:space-y-4">
          {/* STEP 1: SCAN & PAY VIA UPI QR CODE */}
          {step === 'qr' && (
            <div className="space-y-3.5">
              {/* Account & Package Summary Bar */}
              <div className="flex items-center justify-between p-2.5 sm:p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/60 text-xs">
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="font-extrabold text-slate-900 dark:text-white font-['Rajdhani'] text-sm">
                      {verifiedProfile.nickname}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">
                      (UID: {verifiedProfile.uid})
                    </span>
                  </div>
                  <div className="text-[11px] text-rose-500 font-bold">
                    💎 {selectedPackage.diamonds.toLocaleString()} Diamonds (+{selectedPackage.bonus} Bonus)
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-xs text-slate-400 uppercase font-bold">To Pay</div>
                  <div className="text-lg font-black text-slate-900 dark:text-white font-['Rajdhani'] leading-tight">
                    ₹{selectedPackage.priceINR}
                  </div>
                </div>
              </div>

              {/* Official UPI QR Code Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-b from-rose-50/50 via-white to-orange-50/40 dark:from-slate-800/80 dark:to-slate-900 border border-rose-100 dark:border-slate-700 text-center space-y-3">
                <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-500/10 text-rose-600 dark:text-rose-400 text-xs font-bold border border-rose-200/60 dark:border-rose-900/50">
                  <QrCode className="w-3.5 h-3.5" />
                  <span>Scan QR Code with Any UPI App</span>
                </div>

                {/* Instant Local QR Code Graphic */}
                <div className="relative mx-auto w-44 h-44 sm:w-52 sm:h-52 bg-white p-2.5 rounded-2xl shadow-md border-2 border-slate-200 flex items-center justify-center">
                  {qrCodeDataUrl ? (
                    <img
                      src={qrCodeDataUrl}
                      alt="UPI Payment QR Code"
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-slate-300">
                      <Loader2 className="w-6 h-6 animate-spin text-rose-500" />
                    </div>
                  )}
                  {/* Center small logo overlay */}
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-8 h-8 rounded-full bg-white shadow-md p-1 flex items-center justify-center border border-slate-200">
                      <span className="text-xs font-black text-rose-600">UPI</span>
                    </div>
                  </div>
                </div>

                {/* Amount Highlight */}
                <div className="text-xs font-semibold text-slate-500 dark:text-slate-400">
                  Exact Amount:{' '}
                  <span className="text-base font-black text-rose-600 dark:text-rose-400 font-mono">
                    ₹{selectedPackage.priceINR}
                  </span>
                </div>

                {/* Direct UPI App intent button for Mobile */}
                <div className="pt-1">
                  <a
                    href={upiUri}
                    className="inline-flex items-center gap-1.5 text-xs font-bold text-rose-600 dark:text-rose-400 hover:underline"
                  >
                    <span>Open in GPay / PhonePe / Paytm</span>
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>

              {/* "I Have Paid" Action Button */}
              <div className="pt-1 space-y-2">
                <button
                  type="button"
                  onClick={() => setStep('confirm')}
                  className="w-full py-3.5 rounded-xl sm:rounded-2xl font-extrabold text-white text-sm sm:text-base bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-600 hover:to-teal-600 shadow-lg shadow-emerald-500/25 hover:shadow-emerald-500/40 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-[0.99]"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>I Have Paid → Enter UTR / Screenshot</span>
                </button>

                <p className="text-[10px] sm:text-[11px] text-center text-slate-400 dark:text-slate-500 flex items-center justify-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
                  <span>After payment, click &quot;I Have Paid&quot; to verify and receive diamonds</span>
                </p>
              </div>
            </div>
          )}

          {/* STEP 2: ENTER UTR & UPLOAD PAYMENT SCREENSHOT */}
          {step === 'confirm' && (
            <form onSubmit={handleSubmitPayment} className="space-y-3.5">
              {/* Back to QR button */}
              <button
                type="button"
                onClick={() => setStep('qr')}
                className="text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white flex items-center gap-1 cursor-pointer"
              >
                <ChevronLeft className="w-4 h-4" />
                <span>Back to QR Code</span>
              </button>

              {/* Amount reminder without raw UPI ID */}
              <div className="p-2.5 rounded-xl bg-rose-50/60 dark:bg-rose-950/40 border border-rose-100 dark:border-rose-900/60 flex items-center justify-between text-xs">
                <span className="text-slate-700 dark:text-slate-200 font-bold">
                  Top-up for {selectedPackage.diamonds.toLocaleString()} Diamonds
                </span>
                <span className="font-black text-rose-600 font-['Rajdhani'] text-sm">
                  ₹{selectedPackage.priceINR}
                </span>
              </div>

              {/* Field 1: Enter UTR / Transaction Reference Number */}
              <div className="space-y-1">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                  Enter UTR / Transaction Number
                </label>
                <input
                  type="text"
                  value={utrNumber}
                  onChange={(e) => setUtrNumber(e.target.value.replace(/[^a-zA-Z0-9]/g, ''))}
                  placeholder="e.g. 429182749102"
                  maxLength={22}
                  className="w-full h-11 px-3.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono font-bold text-sm focus:outline-none focus:ring-2 focus:ring-rose-500 transition-all placeholder:text-slate-400 placeholder:font-sans"
                />
                <p className="text-[10px] text-slate-400">
                  Found in your GPay / PhonePe / Paytm payment receipt as &quot;UTR&quot; or &quot;UPI Ref No.&quot;
                </p>
              </div>

              {/* Field 2: Upload Payment Screenshot (MANDATORY) */}
              <div className="space-y-1.5">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 flex items-center justify-between">
                  <span>Upload Payment Screenshot</span>
                  <span className="text-rose-500 font-black text-[11px]">* Required</span>
                </label>

                {screenshotPreview ? (
                  <div className="relative p-2 rounded-xl border-2 border-emerald-400 dark:border-emerald-600 bg-emerald-50/50 dark:bg-emerald-950/30 flex items-center justify-between gap-3 shadow-sm">
                    <div className="flex items-center gap-2.5 overflow-hidden">
                      <img
                        src={screenshotPreview}
                        alt="Payment Screenshot Preview"
                        className="w-12 h-12 object-cover rounded-lg border border-emerald-300 dark:border-emerald-700 flex-shrink-0"
                      />
                      <div className="truncate">
                        <span className="text-xs font-bold text-emerald-700 dark:text-emerald-400 flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                          Screenshot Attached (Verified)
                        </span>
                        <span className="text-[10px] text-slate-500 dark:text-slate-400 block truncate">
                          Ready for submission
                        </span>
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => setScreenshotPreview(null)}
                      className="px-2.5 py-1 rounded-md text-xs font-bold text-rose-600 hover:bg-rose-100 dark:hover:bg-rose-950/60 cursor-pointer transition-colors"
                    >
                      Change
                    </button>
                  </div>
                ) : (
                  <label className="relative border-2 border-dashed border-rose-300 hover:border-rose-500 dark:border-rose-900/60 rounded-xl p-4 flex flex-col items-center justify-center text-center cursor-pointer bg-rose-50/20 hover:bg-rose-50/40 dark:hover:bg-slate-800/40 transition-all">
                    <Upload className="w-7 h-7 text-rose-500 mb-1 animate-pulse" />
                    <span className="text-xs font-extrabold text-slate-900 dark:text-white">
                      Upload Payment Screenshot <span className="text-rose-500">*</span>
                    </span>
                    <span className="text-[10px] text-rose-600 dark:text-rose-400 font-semibold mt-0.5">
                      Screenshot is required to proceed
                    </span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                  </label>
                )}
              </div>

              {/* Error Alert */}
              {errorMessage && (
                <div className="p-2.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-rose-700 dark:text-rose-300 text-xs font-medium flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4 flex-shrink-0" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Submit Button (Disabled until screenshot is uploaded) */}
              <div className="pt-1">
                <button
                  type="submit"
                  disabled={isSubmitting || !screenshotPreview}
                  className="w-full py-3.5 rounded-xl sm:rounded-2xl font-extrabold text-white text-sm sm:text-base bg-gradient-to-r from-rose-500 via-rose-600 to-orange-500 hover:from-rose-600 hover:to-orange-600 shadow-xl shadow-rose-500/25 hover:shadow-rose-500/40 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span>Verifying Payment...</span>
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Submit Screenshot & Claim Diamonds</span>
                      <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
                {!screenshotPreview && (
                  <p className="text-[10px] text-center text-rose-500 font-bold mt-1.5">
                    ⚠️ Please upload your payment screenshot to proceed
                  </p>
                )}
              </div>
            </form>
          )}

          {/* STEP 3: VERIFYING / SPINNER */}
          {step === 'verifying' && (
            <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
              <div className="relative">
                <div className="w-20 h-20 rounded-full border-4 border-rose-500/20 border-t-rose-500 animate-spin" />
                <div className="absolute inset-0 flex items-center justify-center">
                  <Flame className="w-8 h-8 text-rose-500 animate-pulse" />
                </div>
              </div>

              <div>
                <h4 className="text-xl font-extrabold text-slate-900 dark:text-white font-['Rajdhani']">
                  VERIFYING PAYMENT & DISPATCHING DIAMONDS...
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mt-1">
                  Connecting to Garena Free Fire server to credit diamonds directly to your in-game mailbox.
                </p>
              </div>
            </div>
          )}

          {/* STEP 4: ERROR STATE */}
          {step === 'error' && (
            <div className="py-6 space-y-5 text-center">
              <div className="w-16 h-16 rounded-2xl bg-rose-500/10 text-rose-500 flex items-center justify-center mx-auto">
                <AlertTriangle className="w-8 h-8" />
              </div>

              <div>
                <h4 className="text-xl font-extrabold text-slate-900 dark:text-white font-['Rajdhani']">
                  TRANSACTION COULD NOT BE COMPLETED
                </h4>
                <p className="text-xs text-rose-600 dark:text-rose-400 mt-2 font-medium max-w-sm mx-auto">
                  {errorMessage || 'Verification encountered an issue.'}
                </p>
              </div>

              <div className="flex gap-3 justify-center">
                <button
                  type="button"
                  onClick={() => setStep('confirm')}
                  className="px-5 py-2.5 rounded-xl text-xs font-bold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-slate-200 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  Try Again
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-xl text-xs font-bold bg-slate-900 dark:bg-white text-white dark:text-slate-900 cursor-pointer"
                >
                  Close
                </button>
              </div>
            </div>
          )}

          {/* STEP 5: PAYMENT SUCCESSFUL NOTIFICATION */}
          {step === 'success' && createdOrder && (
            <div className="space-y-4 animate-scale-up">
              <div className="text-center space-y-1.5">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center mx-auto border-2 border-emerald-500/20 shadow-sm animate-bounce">
                  <CheckCircle2 className="w-8 h-8 sm:w-9 sm:h-9" />
                </div>
                <h4 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white font-['Rajdhani'] tracking-tight">
                  PAYMENT SUCCESSFUL!
                </h4>
                <p className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold">
                  Diamonds will arrive in your Free Fire in-game mailbox right away!
                </p>
              </div>

              {/* Order Receipt Box */}
              <div className="rounded-2xl p-4 sm:p-5 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-2.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400">Order ID</span>
                  <div className="flex items-center gap-1.5">
                    <span className="font-mono font-black text-slate-900 dark:text-white">
                      {createdOrder.id}
                    </span>
                    <button
                      type="button"
                      onClick={handleCopyOrderId}
                      className="p-1 rounded text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
                      title="Copy Order ID"
                    >
                      {copiedOrderId ? (
                        <Check className="w-3.5 h-3.5 text-emerald-500" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400">Target Player</span>
                  <span className="font-extrabold text-slate-900 dark:text-white font-['Rajdhani'] text-sm">
                    {createdOrder.nickname} (UID: {createdOrder.uid})
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400">Diamonds Credited</span>
                  <span className="font-black text-rose-600 dark:text-rose-400 text-sm">
                    💎 {(createdOrder.diamonds + createdOrder.bonusDiamonds).toLocaleString()} Diamonds
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400">Amount Paid</span>
                  <span className="font-bold text-slate-900 dark:text-white">
                    ₹{createdOrder.amountINR}
                  </span>
                </div>

                <div className="flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400">Payment Mode</span>
                  <span className="font-bold text-slate-800 dark:text-slate-200">
                    Verified UPI QR
                  </span>
                </div>

                {createdOrder.utrNumber && (
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 dark:text-slate-400">UTR / Ref No.</span>
                    <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                      {createdOrder.utrNumber}
                    </span>
                  </div>
                )}

                <div className="border-t border-slate-200 dark:border-slate-700 pt-2 flex items-center justify-between">
                  <span className="text-slate-500 dark:text-slate-400">Delivery Status</span>
                  <span className="inline-flex items-center gap-1 text-[11px] font-black text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-300 dark:border-emerald-800">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    Delivered to Mailbox
                  </span>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-1">
                <button
                  type="button"
                  onClick={onClose}
                  className="w-full py-3.5 rounded-xl font-extrabold text-white bg-gradient-to-r from-rose-500 to-orange-500 hover:from-rose-600 hover:to-orange-600 shadow-md text-sm cursor-pointer"
                >
                  Top-Up More Diamonds
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
