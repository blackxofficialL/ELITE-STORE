import React from 'react';

interface DiamondChestGraphicProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

export const DiamondChestGraphic: React.FC<DiamondChestGraphicProps> = ({
  className = 'w-36 h-28',
}) => {
  return (
    <div className={`relative flex items-center justify-center select-none ${className}`}>
      {/* Soft Blue Underglow */}
      <div className="absolute inset-x-4 bottom-2 h-10 bg-gradient-to-t from-sky-400/30 via-blue-500/20 to-transparent blur-xl rounded-full pointer-events-none" />

      <svg
        viewBox="0 0 240 180"
        className="w-full h-full drop-shadow-md overflow-visible"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Metallic Case Gradients */}
          <linearGradient id="caseDark" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#1e2430" />
            <stop offset="50%" stopColor="#131720" />
            <stop offset="100%" stopColor="#0b0e14" />
          </linearGradient>

          <linearGradient id="caseGoldRim" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#e2ad3b" />
            <stop offset="50%" stopColor="#fff3b0" />
            <stop offset="100%" stopColor="#c28b21" />
          </linearGradient>

          <linearGradient id="lidBack" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#2c3342" />
            <stop offset="100%" stopColor="#141822" />
          </linearGradient>

          {/* Radiant Gem Gradients */}
          <linearGradient id="gemCyan1" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#cffafe" />
            <stop offset="40%" stopColor="#38bdf8" />
            <stop offset="100%" stopColor="#0284c7" />
          </linearGradient>

          <linearGradient id="gemDeepBlue" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#7dd3fc" />
            <stop offset="50%" stopColor="#0ea5e9" />
            <stop offset="100%" stopColor="#0369a1" />
          </linearGradient>

          <linearGradient id="gemGlow" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="60%" stopColor="#67e8f9" />
            <stop offset="100%" stopColor="#0284c7" />
          </linearGradient>

          <filter id="softGlow" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* Open Suitcase Lid (Tilted Backward) */}
        <path
          d="M 52 58 L 76 28 L 168 28 L 192 58 Z"
          fill="url(#lidBack)"
          stroke="url(#caseGoldRim)"
          strokeWidth="2.5"
        />
        {/* Lid Inner Padding */}
        <polygon points="78,32 166,32 186,56 58,56" fill="#1b212d" />
        <line x1="84" y1="32" x2="68" y2="56" stroke="#2a3243" strokeWidth="1.5" />
        <line x1="160" y1="32" x2="176" y2="56" stroke="#2a3243" strokeWidth="1.5" />

        {/* Lower Case Body */}
        <path
          d="M 44 80 L 196 80 L 180 144 L 60 144 Z"
          fill="url(#caseDark)"
          stroke="#333c4d"
          strokeWidth="2"
        />

        {/* Golden Metallic Edges & Latches */}
        <path
          d="M 42 78 L 198 78 L 195 86 L 45 86 Z"
          fill="url(#caseGoldRim)"
        />
        <rect x="52" y="80" width="8" height="64" rx="2" fill="url(#caseGoldRim)" opacity="0.8" />
        <rect x="180" y="80" width="8" height="64" rx="2" fill="url(#caseGoldRim)" opacity="0.8" />
        <rect x="110" y="82" width="20" height="12" rx="2" fill="url(#caseGoldRim)" />
        <circle cx="120" cy="88" r="2.5" fill="#111827" />

        {/* Center Case Front Handle Mount */}
        <path
          d="M 98 120 C 98 135 142 135 142 120"
          stroke="url(#caseGoldRim)"
          strokeWidth="4"
          strokeLinecap="round"
          fill="none"
        />

        {/* Overflowing Diamond Crystals & Gems Pile */}
        {/* Diamond Gem 1 (Center Large) */}
        <polygon points="120,54 138,68 120,92 102,68" fill="url(#gemCyan1)" filter="url(#softGlow)" />
        <polygon points="120,54 138,68 120,74" fill="#ffffff" opacity="0.7" />
        <polygon points="120,54 102,68 120,74" fill="#67e8f9" opacity="0.6" />
        <polygon points="102,68 120,74 120,92" fill="#0284c7" opacity="0.9" />
        <polygon points="138,68 120,74 120,92" fill="#0369a1" />

        {/* Diamond Gem 2 (Left) */}
        <polygon points="86,60 102,72 88,94 72,74" fill="url(#gemDeepBlue)" />
        <polygon points="86,60 102,72 88,78" fill="#ffffff" opacity="0.65" />
        <polygon points="72,74 88,78 88,94" fill="#0284c7" />

        {/* Diamond Gem 3 (Right) */}
        <polygon points="154,58 170,72 156,94 140,74" fill="url(#gemGlow)" />
        <polygon points="154,58 170,72 156,76" fill="#ffffff" opacity="0.8" />
        <polygon points="140,74 156,76 156,94" fill="#0369a1" />

        {/* Extra Smaller Crystals spilling out */}
        <polygon points="68,76 80,82 72,96 60,86" fill="url(#gemCyan1)" />
        <polygon points="168,74 182,82 174,96 162,86" fill="url(#gemDeepBlue)" />
        <polygon points="106,48 116,56 108,66 98,58" fill="url(#gemGlow)" />
        <polygon points="134,48 144,58 136,66 126,56" fill="url(#gemCyan1)" />

        {/* Spilled Gems on Bottom / Ground */}
        <polygon points="54,142 66,146 60,154 48,150" fill="url(#gemCyan1)" />
        <polygon points="180,144 192,148 186,156 174,152" fill="url(#gemGlow)" />
        <polygon points="112,146 122,150 118,158 108,154" fill="url(#gemDeepBlue)" />

        {/* Radiant Sparkle Highlights */}
        {/* Star Sparkle 1 */}
        <path
          d="M 120 44 Q 120 52 126 52 Q 120 52 120 60 Q 120 52 114 52 Q 120 52 120 44 Z"
          fill="#ffffff"
        />
        <circle cx="120" cy="52" r="1.5" fill="#38bdf8" />

        {/* Star Sparkle 2 */}
        <path
          d="M 160 52 Q 160 58 165 58 Q 160 58 160 64 Q 160 58 155 58 Q 160 58 160 52 Z"
          fill="#ffffff"
        />

        {/* Star Sparkle 3 */}
        <path
          d="M 82 56 Q 82 61 86 61 Q 82 61 82 66 Q 82 61 78 61 Q 82 61 82 56 Z"
          fill="#ffffff"
        />
      </svg>
    </div>
  );
};
