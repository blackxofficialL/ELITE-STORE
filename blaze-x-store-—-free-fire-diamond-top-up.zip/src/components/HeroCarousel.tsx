import React, { useState, useEffect, useRef } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Upload,
  Edit2,
  Trash2,
  FolderOpen,
  Check,
  X,
  Image as ImageIcon,
} from 'lucide-react';

interface BannerItem {
  id: string;
  name: string;
  url: string;
}

export const HeroCarousel: React.FC<{ onCtaClick: () => void }> = ({ onCtaClick }) => {
  const [banners, setBanners] = useState<BannerItem[]>([]);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [isManagerOpen, setIsManagerOpen] = useState(false);
  const [renamingId, setRenamingId] = useState<string | null>(null);
  const [renameInput, setRenameInput] = useState('');
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Load banners from /public/banners folder via /api/banners
  const loadBanners = async () => {
    try {
      const res = await fetch('/api/banners');
      if (res.ok) {
        const data = await res.json();
        if (data.banners && Array.isArray(data.banners) && data.banners.length > 0) {
          setBanners(data.banners);
          return;
        }
      }
    } catch (err) {
      console.warn('Could not fetch server banners:', err);
    }

    // Default fallback if folder empty
    setBanners([
      {
        id: 'banner1.png',
        name: 'banner1.png',
        url: '/banners/banner1.png',
      },
    ]);
  };

  useEffect(() => {
    loadBanners();
  }, []);

  // Auto-advance slides every 2.8 seconds (faster snappy movement)
  useEffect(() => {
    if (isPaused || banners.length <= 1) return;
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % banners.length);
    }, 2800);
    return () => clearInterval(timer);
  }, [isPaused, banners.length]);

  // Upload banner file into /public/banners folder
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Please select a valid image file (PNG, JPG, WEBP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = async (event) => {
      const dataUrl = event.target?.result as string;
      if (!dataUrl) return;

      try {
        const res = await fetch('/api/banners/upload', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fileName: file.name,
            dataUrl,
          }),
        });

        if (res.ok) {
          await loadBanners();
          setCurrentSlide(0);
        } else {
          alert('Failed to upload banner to folder.');
        }
      } catch (err) {
        console.error('Upload failed:', err);
      }
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Rename a banner in /public/banners
  const handleRename = async (oldName: string) => {
    if (!renameInput.trim()) return;

    try {
      const res = await fetch('/api/banners/rename', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          oldName,
          newName: renameInput.trim(),
        }),
      });

      if (res.ok) {
        setRenamingId(null);
        setRenameInput('');
        await loadBanners();
      } else {
        const err = await res.json();
        alert(err.error || 'Failed to rename banner.');
      }
    } catch (err) {
      console.error('Rename failed:', err);
    }
  };

  // Delete banner
  const handleDelete = async (fileName: string) => {
    if (!confirm(`Delete ${fileName} from /public/banners/?`)) return;

    try {
      const res = await fetch(`/api/banners/${encodeURIComponent(fileName)}`, {
        method: 'DELETE',
      });
      if (res.ok) {
        await loadBanners();
        setCurrentSlide(0);
      }
    } catch (err) {
      console.error('Delete failed:', err);
    }
  };

  const activeBanner = banners[currentSlide] || banners[0];

  return (
    <div
      className="relative w-full select-none"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
    >
      <div className="relative max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 pt-2 sm:pt-4 pb-2">
        {/* Banner Display Box: Pure image presentation with no text clutter */}
        <div
          onClick={onCtaClick}
          className="relative rounded-2xl sm:rounded-3xl overflow-hidden shadow-md hover:shadow-xl border border-slate-200/80 bg-slate-900 transition-all duration-500 cursor-pointer group w-full aspect-[1920/725] sm:aspect-auto sm:h-[320px] md:h-[400px] lg:h-[440px] flex items-center justify-center"
        >
          {activeBanner?.url ? (
            <img
              key={activeBanner.url}
              src={activeBanner.url}
              alt={activeBanner.name}
              className="w-full h-full object-fill sm:object-fill transition-all duration-300 animate-fade-in group-hover:scale-[1.01]"
              onError={(e) => {
                // If local path fails, fallback to CDN banner
                (e.currentTarget as HTMLImageElement).src =
                  'https://freefireinfo.in/images/banners/901045005.png';
              }}
            />
          ) : (
            <div className="w-full h-full bg-slate-900 flex flex-col items-center justify-center text-slate-400">
              <ImageIcon className="w-12 h-12 text-slate-500 mb-2" />
              <span className="text-sm font-semibold">Place banners in /public/banners folder</span>
            </div>
          )}



          {/* Slide Indicator Dots (If multiple banners) */}
          {banners.length > 1 && (
            <div
              className="absolute bottom-4 left-6 sm:left-10 flex items-center gap-2 z-20"
              onClick={(e) => e.stopPropagation()}
            >
              {banners.map((_, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => setCurrentSlide(idx)}
                  className={`h-2 rounded-full transition-all duration-300 cursor-pointer ${
                    currentSlide === idx ? 'w-8 bg-rose-500 shadow-md' : 'w-2 bg-white/50 hover:bg-white'
                  }`}
                  aria-label={`Go to slide ${idx + 1}`}
                />
              ))}
            </div>
          )}

          {/* Left / Right Arrow Buttons (If multiple banners) */}
          {banners.length > 1 && (
            <div
              className="absolute bottom-4 right-6 sm:right-10 flex items-center gap-2 z-20"
              onClick={(e) => e.stopPropagation()}
            >
              <button
                type="button"
                onClick={() => setCurrentSlide((prev) => (prev - 1 + banners.length) % banners.length)}
                className="p-2 rounded-xl bg-black/40 hover:bg-black/70 text-white backdrop-blur-md transition-colors cursor-pointer border border-white/10"
                aria-label="Previous slide"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setCurrentSlide((prev) => (prev + 1) % banners.length)}
                className="p-2 rounded-xl bg-black/40 hover:bg-black/70 text-white backdrop-blur-md transition-colors cursor-pointer border border-white/10"
                aria-label="Next slide"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ================= BANNER FOLDER & RENAME MODAL ================= */}
      {isManagerOpen && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in"
          onClick={() => setIsManagerOpen(false)}
        >
          <div
            className="w-full max-w-lg bg-white rounded-3xl p-6 shadow-2xl border border-slate-100 space-y-4 animate-scale-up"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
                  <FolderOpen className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="font-extrabold text-slate-900 font-['Rajdhani'] text-lg leading-tight">
                    /public/banners FOLDER
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Upload images into this folder and rename them anytime.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsManagerOpen(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-700 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* List of Files in Folder */}
            <div className="space-y-2.5 max-h-[300px] overflow-y-auto pr-1">
              {banners.map((item) => {
                const isRenaming = renamingId === item.name;

                return (
                  <div
                    key={item.id}
                    className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between gap-3 hover:border-slate-300 transition-colors"
                  >
                    {/* Thumbnail */}
                    <div className="w-14 h-9 rounded-lg overflow-hidden bg-slate-900 flex-shrink-0 border border-slate-200">
                      <img src={item.url} alt={item.name} className="w-full h-full object-cover" />
                    </div>

                    {/* File Name / Rename Input */}
                    <div className="flex-1 min-w-0">
                      {isRenaming ? (
                        <div className="flex items-center gap-1.5">
                          <input
                            type="text"
                            value={renameInput}
                            onChange={(e) => setRenameInput(e.target.value)}
                            placeholder="New file name (e.g. banner2.png)"
                            className="w-full px-2.5 py-1 text-xs font-mono font-bold rounded-lg border border-rose-400 bg-white focus:outline-none focus:ring-1 focus:ring-rose-500"
                            autoFocus
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') handleRename(item.name);
                              if (e.key === 'Escape') setRenamingId(null);
                            }}
                          />
                          <button
                            type="button"
                            onClick={() => handleRename(item.name)}
                            className="p-1 text-emerald-600 hover:bg-emerald-50 rounded"
                            title="Save"
                          >
                            <Check className="w-4 h-4" />
                          </button>
                          <button
                            type="button"
                            onClick={() => setRenamingId(null)}
                            className="p-1 text-slate-400 hover:bg-slate-200 rounded"
                            title="Cancel"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </div>
                      ) : (
                        <div>
                          <p className="text-xs font-bold font-mono text-slate-800 truncate">
                            {item.name}
                          </p>
                          <p className="text-[10px] text-slate-400">Path: /public/banners/{item.name}</p>
                        </div>
                      )}
                    </div>

                    {/* Actions: Rename / Delete */}
                    {!isRenaming && (
                      <div className="flex items-center gap-1">
                        <button
                          type="button"
                          onClick={() => {
                            setRenamingId(item.name);
                            setRenameInput(item.name);
                          }}
                          className="p-1.5 rounded-lg text-slate-600 hover:text-amber-600 hover:bg-amber-50 transition-colors"
                          title="Rename file"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDelete(item.name)}
                          className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors"
                          title="Delete file"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>

            {/* Bottom Actions */}
            <div className="pt-2 flex items-center justify-between border-t border-slate-100">
              <span className="text-[11px] font-semibold text-slate-400">
                You can also add files directly to <code className="text-slate-700 bg-slate-100 px-1 py-0.5 rounded">/public/banners/</code>
              </span>

              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-rose-500 to-orange-500 text-white font-extrabold text-xs shadow-md shadow-rose-500/20 flex items-center gap-1.5 hover:opacity-95 transition-opacity cursor-pointer"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>Upload New Banner</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
