import React, { useState } from 'react';
import { Order } from '../types/index.ts';
import { getStatusBadgeInfo } from '../shared/orderStateMachine.ts';
import { Search, Loader2, CheckCircle2, Clock, ShieldCheck, AlertCircle, PackageCheck, Copy, Check } from 'lucide-react';

interface OrderTrackerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const OrderTrackerModal: React.FC<OrderTrackerModalProps> = ({ isOpen, onClose }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [orders, setOrders] = useState<Order[] | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const query = searchQuery.trim();
    if (!query) return;

    setIsLoading(true);
    setErrorMessage(null);

    try {
      const res = await fetch(`/api/orders/search/lookup?q=${encodeURIComponent(query)}`);
      const data = await res.json();

      if (!res.ok) {
        setErrorMessage(data.error || 'Failed to search order records.');
        setOrders([]);
        return;
      }

      setOrders(data.orders || []);
      if (!data.orders || data.orders.length === 0) {
        setErrorMessage(`No orders found matching "${query}". Double check your Order ID or numeric UID.`);
      }
    } catch (err) {
      setErrorMessage('Network error while looking up order.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-xl w-full max-h-[85vh] overflow-y-auto shadow-2xl border border-slate-200 dark:border-slate-800 transition-colors">
        {/* Header */}
        <div className="sticky top-0 bg-white/95 dark:bg-slate-900/95 backdrop-blur-md px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-sky-500 to-indigo-600 flex items-center justify-center text-white shadow-sm">
              <PackageCheck className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-lg font-extrabold text-slate-900 dark:text-white font-['Rajdhani'] leading-tight">
                TRACK DIAMOND ORDER STATUS
              </h3>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Live delivery updates for Free Fire accounts
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white flex items-center justify-center text-sm font-bold"
          >
            ✕
          </button>
        </div>

        <div className="p-6 space-y-6">
          {/* Search Bar */}
          <form onSubmit={handleSearch} className="space-y-2">
            <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
              Enter Order ID or Player UID
            </label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="e.g. BX-20261016-... or 2849182741"
                  className="w-full h-11 pl-9 pr-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-900 dark:text-white focus:outline-none focus:ring-2 focus:ring-rose-500"
                />
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3.5 pointer-events-none" />
              </div>
              <button
                type="submit"
                disabled={isLoading || !searchQuery.trim()}
                className="px-5 h-11 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs flex items-center gap-1.5 shadow-md shadow-rose-500/20 disabled:opacity-50"
              >
                {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Search'}
              </button>
            </div>
          </form>

          {/* Error Message */}
          {errorMessage && (
            <div className="p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/60 text-rose-700 dark:text-rose-300 text-xs font-medium flex items-start gap-2">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Results List */}
          {orders && orders.length > 0 && (
            <div className="space-y-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                Found {orders.length} Order{orders.length > 1 ? 's' : ''}
              </h4>

              {orders.map((ord) => {
                const badge = getStatusBadgeInfo(ord.status);
                return (
                  <div
                    key={ord.id}
                    className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700 space-y-3"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-mono text-xs font-bold text-slate-900 dark:text-white">
                            {ord.id}
                          </span>
                          <button
                            type="button"
                            onClick={() => handleCopy(ord.id)}
                            className="p-1 rounded text-slate-400 hover:text-slate-600 dark:hover:text-white"
                            title="Copy ID"
                          >
                            {copiedId === ord.id ? (
                              <Check className="w-3.5 h-3.5 text-emerald-500" />
                            ) : (
                              <Copy className="w-3.5 h-3.5" />
                            )}
                          </button>
                        </div>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          {new Date(ord.createdAt).toLocaleString()}
                        </p>
                      </div>

                      <span
                        className={`inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full border ${badge.colorClass}`}
                      >
                        {badge.label}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs pt-2 border-t border-slate-200 dark:border-slate-700">
                      <div>
                        <span className="text-slate-400 text-[10px] block">Player</span>
                        <span className="font-bold text-slate-800 dark:text-slate-200">
                          {ord.nickname}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 text-[10px] block">UID</span>
                        <span className="font-mono font-bold text-slate-800 dark:text-slate-200">
                          {ord.uid}
                        </span>
                      </div>
                      <div>
                        <span className="text-slate-400 text-[10px] block">Package</span>
                        <span className="font-bold text-rose-500">
                          💎 {ord.diamonds + ord.bonusDiamonds} Gems (₹{ord.amountINR})
                        </span>
                      </div>
                    </div>

                    {ord.statusMessage && (
                      <p className="text-[11px] text-slate-500 dark:text-slate-400 bg-white dark:bg-slate-900 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                        {ord.statusMessage}
                      </p>
                    )}

                    {ord.fulfillmentTxId && (
                      <div className="flex items-center gap-1 text-[10px] text-emerald-600 dark:text-emerald-400 font-mono">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>Fulfillment Ref: {ord.fulfillmentTxId}</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
