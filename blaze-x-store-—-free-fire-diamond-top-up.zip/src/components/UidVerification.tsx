import React, { useState, useRef, useEffect } from 'react';
import {
  UserCheck,
  Globe,
  AlertCircle,
  Loader2,
  CheckCircle2,
  HelpCircle,
  RotateCcw,
  ShieldCheck,
  User,
  Sparkles,
  Info,
  ExternalLink,
} from 'lucide-react';
import { PlayerProfile, RegionCode } from '../types/index.ts';
import { validateFreeFireUid, SUPPORTED_REGIONS } from '../shared/validation.ts';

interface UidVerificationProps {
  verifiedProfile: PlayerProfile | null;
  onProfileVerified: (profile: PlayerProfile) => void;
  onClearProfile: () => void;
  onOpenModal?: () => void;
}

const PRIMARY_API_ENDPOINT = 'https://infoooooo-v6v5.vercel.app/accinfo';

export const UidVerification: React.FC<UidVerificationProps> = ({
  verifiedProfile,
  onProfileVerified,
  onClearProfile,
  onOpenModal,
}) => {
  const [uid, setUid] = useState('');
  const [region, setRegion] = useState<RegionCode>('IND');
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [showHelperModal, setShowHelperModal] = useState(false);
  const [avatarLoadError, setAvatarLoadError] = useState(false);

  const abortControllerRef = useRef<AbortController | null>(null);

  // Clean up any ongoing fetch when unmounting
  useEffect(() => {
    return () => {
      if (abortControllerRef.current) {
        abortControllerRef.current.abort();
      }
    };
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    // Digits only
    const val = e.target.value.replace(/\D/g, '');
    setUid(val);
    if (errorMessage) setErrorMessage(null);

    // Requirement: Clear previous verification result when the UID changes
    if (verifiedProfile) {
      onClearProfile();
    }
  };

  const handleVerify = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();

    // Prevent duplicate requests while verification is in progress
    if (isLoading) return;

    setErrorMessage(null);

    // 1. Validate UID format (must be 8-12 numeric digits)
    const validation = validateFreeFireUid(uid);
    if (!validation.isValid || !validation.cleanUid) {
      setErrorMessage(validation.error || 'Please enter a valid 8-12 digit Free Fire UID.');
      return;
    }

    const cleanUid = validation.cleanUid;
    setIsLoading(true);
    setAvatarLoadError(false);

    // Cancel any previous pending request
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    const controller = new AbortController();
    abortControllerRef.current = controller;

    // Timeout after 10 seconds
    const timeoutId = setTimeout(() => {
      controller.abort();
    }, 10000);

    try {
      let rawData: any = null;
      let fetchSuccess = false;

      // 2. Direct GET request to https://infoooooo-v6v5.vercel.app/accinfo?uid=USER_UID
      const targetApiUrl = `${PRIMARY_API_ENDPOINT}?uid=${encodeURIComponent(cleanUid)}`;

      try {
        const response = await fetch(targetApiUrl, {
          method: 'GET',
          headers: {
            'Accept': 'application/json',
          },
          signal: controller.signal,
        });

        if (response.ok) {
          const text = await response.text();
          try {
            rawData = JSON.parse(text);
            fetchSuccess = true;
          } catch {
            throw new Error('Received malformed response from verification server.');
          }
        } else if (response.status === 404) {
          const text = await response.text();
          try {
            const errJson = JSON.parse(text);
            setErrorMessage(errJson.error || `Player UID ${cleanUid} was not found on the Free Fire game server.`);
          } catch {
            setErrorMessage(`Player UID ${cleanUid} was not found on the Free Fire server. Please check your numeric ID.`);
          }
          setIsLoading(false);
          clearTimeout(timeoutId);
          return;
        } else {
          throw new Error(`API returned HTTP ${response.status}`);
        }
      } catch (directErr: any) {
        if (directErr.name === 'AbortError') {
          setErrorMessage('Verification request timed out. Please check your network and retry.');
          setIsLoading(false);
          clearTimeout(timeoutId);
          return;
        }

        // If direct request failed (e.g. CORS block or network restriction), fallback to server proxy
        console.warn('Direct API query failed or blocked, attempting backend proxy:', directErr.message);

        try {
          const proxyRes = await fetch(`/api/accinfo?uid=${encodeURIComponent(cleanUid)}&region=${encodeURIComponent(region)}`, {
            method: 'GET',
            headers: { 'Accept': 'application/json' },
            signal: controller.signal,
          });

          if (proxyRes.ok) {
            rawData = await proxyRes.json();
            fetchSuccess = true;
          } else {
            const errData = await proxyRes.json().catch(() => ({}));
            setErrorMessage(errData.error || `Player UID ${cleanUid} not found. Please verify your in-game numeric ID.`);
            setIsLoading(false);
            clearTimeout(timeoutId);
            return;
          }
        } catch (proxyErr: any) {
          if (proxyErr.name === 'AbortError') {
            setErrorMessage('Verification request timed out. Please check your network and retry.');
          } else {
            setErrorMessage('Unable to reach Free Fire verification server. Please check your internet connection and try again.');
          }
          setIsLoading(false);
          clearTimeout(timeoutId);
          return;
        }
      }

      clearTimeout(timeoutId);

      // 3. Parse JSON response and validate basicInfo
      if (!fetchSuccess || !rawData) {
        setErrorMessage('Verification failed: No response received from game server.');
        setIsLoading(false);
        return;
      }

      if (rawData.error) {
        setErrorMessage(rawData.error);
        setIsLoading(false);
        return;
      }

      const basicInfo = rawData.basicInfo;
      if (!basicInfo || !basicInfo.accountId) {
        setErrorMessage('Invalid player account data returned by game server. UID not verified.');
        setIsLoading(false);
        return;
      }

      // Check accountId matches
      const accountId = String(basicInfo.accountId);
      const nickname = String(basicInfo.nickname || '').trim();

      if (!nickname) {
        setErrorMessage('Player nickname could not be retrieved. Please check the entered UID.');
        setIsLoading(false);
        return;
      }

      const playerRegion = (basicInfo.region || region || 'IND').toUpperCase() as RegionCode;
      const playerLevel = Number(basicInfo.level) || 1;
      const headPic = basicInfo.headPic ? Number(basicInfo.headPic) : undefined;
      const bannerId = basicInfo.bannerId ? Number(basicInfo.bannerId) : undefined;

      // Construct avatar URL from Free Fire CDN if headPic available
      const avatarUrl = headPic ? `https://freefireinfo.in/images/avatars/${headPic}.png` : undefined;
      const bannerUrl = bannerId ? `https://freefireinfo.in/images/banners/${bannerId}.png` : undefined;

      const rankingPoints = typeof basicInfo.rankingPoints === 'number' ? basicInfo.rankingPoints : undefined;
      const rank = rankingPoints
        ? `Heroic (${rankingPoints} Pts)`
        : playerLevel >= 70
        ? 'Grandmaster'
        : playerLevel >= 50
        ? 'Heroic'
        : 'Diamond';

      const signature =
        rawData.socialInfo?.signature ||
        'Free Fire MAX Verified Player';

      const hasVBadge = Boolean(
        basicInfo.title === 904590059 ||
        playerLevel >= 75 ||
        (rawData.primeInfo && rawData.primeInfo.primeLevel && rawData.primeInfo.primeLevel >= 3)
      );

      const profile: PlayerProfile = {
        uid: accountId,
        nickname,
        region: playerRegion,
        level: playerLevel,
        exp: Number(basicInfo.exp) || 0,
        likes: typeof basicInfo.liked === 'number' ? basicInfo.liked : 0,
        headPic,
        bannerId,
        avatarUrl,
        bannerUrl,
        rank,
        rankScore: rankingPoints || 3500 + playerLevel * 25,
        csRank: playerLevel >= 70 ? 'Master 25★' : 'Master 10★',
        signature,
        hasVBadge,
        badge: basicInfo.badgeCnt ? `${basicInfo.badgeCnt} Badges` : 'Heroic',
        verifiedAt: new Date().toISOString(),
        provider: 'info_vercel_api',
      };

      // 4. Update parent with verified profile and open modal
      onProfileVerified(profile);
      if (onOpenModal) {
        onOpenModal();
      }
      setErrorMessage(null);
    } catch (err: any) {
      setErrorMessage(
        err.message || 'An unexpected error occurred while verifying the player UID. Please retry.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="w-full">
      {/* Step Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-rose-500 to-orange-500 text-white font-extrabold flex items-center justify-center text-sm shadow-md shadow-rose-500/20">
            1
          </div>
          <div>
            <h3 className="text-xl font-extrabold text-slate-900 dark:text-white font-['Rajdhani']">
              VERIFY YOUR FREE FIRE UID
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400">
              Enter your in-game numeric Player ID to verify your real in-game nickname before diamond top-up.
            </p>
          </div>
        </div>
      </div>

      {/* Main Verification Box */}
      <div className="bg-white dark:bg-slate-900 rounded-3xl border border-slate-200 dark:border-slate-800 p-5 sm:p-7 shadow-lg transition-all">
        {verifiedProfile ? (
          /* Verified Profile Confirmation Card - Green verified status */
          <div className="space-y-4 animate-fade-in">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-emerald-500/10 via-emerald-500/5 to-transparent border border-emerald-500/40 shadow-sm">
              <div className="flex items-start sm:items-center gap-4">
                {/* Avatar with HeadPic or Fallback */}
                <div className="relative w-16 h-16 rounded-2xl bg-gradient-to-tr from-slate-950 to-slate-800 border-2 border-emerald-400/60 overflow-hidden flex items-center justify-center text-white shadow-lg flex-shrink-0">
                  {verifiedProfile.avatarUrl && !avatarLoadError ? (
                    <img
                      src={verifiedProfile.avatarUrl}
                      alt={verifiedProfile.nickname}
                      className="w-full h-full object-cover"
                      onError={() => setAvatarLoadError(true)}
                    />
                  ) : (
                    <User className="w-8 h-8 text-emerald-400" />
                  )}

                  {verifiedProfile.hasVBadge && (
                    <div
                      className="absolute -top-1 -left-1 w-6 h-6 rounded-full bg-amber-400 text-slate-950 font-black text-[11px] flex items-center justify-center border-2 border-white dark:border-slate-900 shadow-md z-10"
                      title="Free Fire Verified Influencer V-Badge"
                    >
                      V
                    </div>
                  )}

                  <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full bg-emerald-500 flex items-center justify-center text-white shadow z-10">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    {verifiedProfile.hasVBadge && (
                      <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-400 text-slate-950 shadow-sm">
                        ★ V-BADGE
                      </span>
                    )}
                    {/* Unicode Player Nickname */}
                    <span className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white font-['Rajdhani'] tracking-wide">
                      {verifiedProfile.nickname}
                    </span>
                    {/* Green verified badge */}
                    <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
                      <ShieldCheck className="w-3.5 h-3.5" />
                      Verified Player
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-slate-600 dark:text-slate-300 font-medium">
                    <span>
                      UID: <strong className="text-slate-900 dark:text-white font-mono">{verifiedProfile.uid}</strong>
                    </span>
                    <span>•</span>
                    <span>
                      Server: {SUPPORTED_REGIONS[verifiedProfile.region]?.flag || '🇮🇳'}{' '}
                      {SUPPORTED_REGIONS[verifiedProfile.region]?.name || verifiedProfile.region}
                    </span>
                    {verifiedProfile.level && (
                      <>
                        <span>•</span>
                        <span className="text-amber-500 font-bold bg-amber-500/10 px-2 py-0.5 rounded-md border border-amber-500/20">
                          Level {verifiedProfile.level}
                        </span>
                      </>
                    )}
                    {verifiedProfile.rank && (
                      <>
                        <span>•</span>
                        <span className="text-rose-500 font-bold bg-rose-500/10 px-2 py-0.5 rounded-md border border-rose-500/20">
                          👑 {verifiedProfile.rank}
                        </span>
                      </>
                    )}
                    {typeof verifiedProfile.likes === 'number' && verifiedProfile.likes > 0 && (
                      <>
                        <span>•</span>
                        <span className="text-pink-500 font-bold">
                          ❤️ {verifiedProfile.likes.toLocaleString()} Likes
                        </span>
                      </>
                    )}
                  </div>

                  {verifiedProfile.signature && (
                    <div className="pt-0.5 text-[11px] italic text-slate-400 dark:text-slate-500">
                      &quot;{verifiedProfile.signature}&quot;
                    </div>
                  )}
                </div>
              </div>

              {/* Reset/Change UID Button */}
              <div className="flex items-center gap-2 self-start sm:self-center">
                <button
                  type="button"
                  onClick={() => {
                    onClearProfile();
                    setUid('');
                  }}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors shadow-sm"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Change UID</span>
                </button>
              </div>
            </div>

            {/* Success Banner */}
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/40 px-3.5 py-2.5 rounded-xl border border-emerald-200 dark:border-emerald-800/40">
              <CheckCircle2 className="w-4 h-4 text-emerald-500 flex-shrink-0" />
              <span>
                Player account verified on Free Fire India Server! Click below to proceed to the store.
              </span>
            </div>

            {/* Proceed to Store CTA */}
            <div className="pt-1">
              <button
                type="button"
                onClick={onOpenModal}
                className="w-full sm:w-auto px-7 py-3 rounded-full bg-gradient-to-r from-[#ff1353] via-[#ff2262] to-[#ff2b70] hover:from-[#ff0044] hover:to-[#ff1f66] text-white font-extrabold text-sm shadow-lg shadow-rose-500/30 flex items-center justify-center gap-2 cursor-pointer transition-all hover:scale-[1.01]"
              >
                <span>Proceed to Store</span>
                <span className="text-base">→</span>
              </button>
            </div>
          </div>
        ) : (
          /* Normal Verification Form */
          <form onSubmit={handleVerify} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              {/* Region Selector */}
              <div className="md:col-span-4">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                  Game Server Region
                </label>
                <div className="relative">
                  <select
                    value={region}
                    onChange={(e) => setRegion(e.target.value as RegionCode)}
                    disabled={isLoading}
                    className="w-full h-12 px-3.5 pl-10 rounded-xl bg-slate-50 dark:bg-slate-800/90 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-semibold text-sm focus:outline-none focus:ring-2 focus:ring-rose-500 transition-all cursor-pointer disabled:opacity-60"
                  >
                    <option value="IND">🇮🇳 India (IND)</option>
                  </select>
                  <Globe className="w-4 h-4 text-slate-400 absolute left-3.5 top-4 pointer-events-none" />
                </div>
              </div>

              {/* UID Input */}
              <div className="md:col-span-5">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1.5">
                  Numeric Free Fire UID
                </label>
                <div className="relative">
                  <input
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                    maxLength={12}
                    value={uid}
                    onChange={handleInputChange}
                    placeholder="Enter Free Fire UID"
                    disabled={isLoading}
                    className="w-full h-12 px-3.5 pl-10 rounded-xl bg-slate-50 dark:bg-slate-800/90 border border-slate-300 dark:border-slate-700 text-slate-900 dark:text-white font-mono font-bold text-sm focus:outline-none focus:ring-2 focus:ring-rose-500 transition-all placeholder:text-slate-400 placeholder:font-sans disabled:opacity-60"
                  />
                  <UserCheck className="w-4 h-4 text-slate-400 absolute left-3.5 top-4 pointer-events-none" />
                </div>
              </div>

              {/* Verify Button */}
              <div className="md:col-span-3 flex items-end">
                <button
                  type="submit"
                  disabled={isLoading || uid.length < 8}
                  className={`w-full h-12 rounded-xl font-extrabold text-sm tracking-wide text-white flex items-center justify-center gap-2 transition-all shadow-md ${
                    uid.length >= 8 && !isLoading
                      ? 'bg-gradient-to-r from-rose-500 via-rose-600 to-orange-500 hover:from-rose-600 hover:to-orange-600 shadow-rose-500/25 hover:shadow-rose-500/40 transform hover:-translate-y-0.5'
                      : 'bg-slate-300 dark:bg-slate-800 text-slate-500 dark:text-slate-500 cursor-not-allowed shadow-none'
                  }`}
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin text-white" />
                      <span>Verifying Player ID…</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Verify UID</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Error Message with Retry */}
            {errorMessage && (
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900/50 text-rose-700 dark:text-rose-300 text-xs font-semibold animate-shake">
                <div className="flex items-start gap-2.5">
                  <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5 text-rose-500" />
                  <p>{errorMessage}</p>
                </div>
                <button
                  type="button"
                  onClick={() => handleVerify()}
                  disabled={isLoading}
                  className="self-end sm:self-center px-3 py-1.5 rounded-lg bg-rose-600 text-white font-bold text-xs hover:bg-rose-700 transition-colors flex-shrink-0"
                >
                  Retry Verification
                </button>
              </div>
            )}
          </form>
        )}
      </div>

      {/* Helper Modal */}
      {showHelperModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-md w-full p-6 border border-slate-200 dark:border-slate-800 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <Info className="w-5 h-5 text-rose-500" />
                <h4 className="font-extrabold text-slate-900 dark:text-white font-['Rajdhani'] text-lg">
                  HOW TO FIND YOUR FREE FIRE UID
                </h4>
              </div>
              <button
                onClick={() => setShowHelperModal(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white font-bold text-sm"
              >
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs text-slate-600 dark:text-slate-300">
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400 font-bold flex items-center justify-center flex-shrink-0">
                  1
                </span>
                <p>Open <strong>Free Fire MAX</strong> on your phone or tablet.</p>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400 font-bold flex items-center justify-center flex-shrink-0">
                  2
                </span>
                <p>Tap your <strong>Profile Banner / Avatar</strong> in the top-left corner of the lobby screen.</p>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400 font-bold flex items-center justify-center flex-shrink-0">
                  3
                </span>
                <p>Look directly below your nickname on the <strong>Gallery</strong> tab for your 8-12 digit <strong>UID</strong> (e.g. 11061719793).</p>
              </div>
              <div className="flex items-start gap-2.5">
                <span className="w-5 h-5 rounded-full bg-rose-100 dark:bg-rose-950 text-rose-600 dark:text-rose-400 font-bold flex items-center justify-center flex-shrink-0">
                  4
                </span>
                <p>Tap the <strong>Copy icon</strong> next to your UID and paste it into the box here.</p>
              </div>
            </div>

            <button
              onClick={() => setShowHelperModal(false)}
              className="w-full py-2.5 rounded-xl bg-slate-900 dark:bg-white text-white dark:text-slate-900 font-extrabold text-xs shadow hover:opacity-90 transition-opacity"
            >
              Got it, let&apos;s verify!
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
