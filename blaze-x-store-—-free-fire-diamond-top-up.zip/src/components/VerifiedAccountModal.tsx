import React, { useEffect } from 'react';
import { X, Check, Heart, Phone } from 'lucide-react';
import confetti from 'canvas-confetti';
import { PlayerProfile } from '../types/index.ts';

interface VerifiedAccountModalProps {
  isOpen: boolean;
  profile: PlayerProfile;
  onProceed: () => void;
  onClose: () => void;
  onReEnterUid: () => void;
  onCallAdmin?: () => void;
}

export const VerifiedAccountModal: React.FC<VerifiedAccountModalProps> = ({
  isOpen,
  profile,
  onProceed,
  onClose,
  onReEnterUid,
  onCallAdmin,
}) => {
  // Trigger realistic party popper sprinkle confetti animation when modal opens
  useEffect(() => {
    if (!isOpen) return;

    const colors = ['#ff1353', '#ff4b72', '#ffd166', '#06d6a0', '#118ab2', '#a78bfa', '#ff9f1c'];

    // 1. Initial Left Party Popper Cannon
    confetti({
      particleCount: 55,
      angle: 60,
      spread: 60,
      origin: { x: 0.1, y: 0.75 },
      colors,
      zIndex: 9999,
      scalar: 1.1,
    });

    // 2. Initial Right Party Popper Cannon
    confetti({
      particleCount: 55,
      angle: 120,
      spread: 60,
      origin: { x: 0.9, y: 0.75 },
      colors,
      zIndex: 9999,
      scalar: 1.1,
    });

    // 3. Center Festive Burst
    const centerTimer = setTimeout(() => {
      confetti({
        particleCount: 75,
        spread: 100,
        origin: { y: 0.45 },
        colors,
        zIndex: 9999,
        scalar: 1.2,
      });
    }, 200);

    // 4. Falling sprinkles shower
    const end = Date.now() + 2000;
    const interval: any = setInterval(() => {
      if (Date.now() > end) {
        return clearInterval(interval);
      }
      confetti({
        startVelocity: 25,
        spread: 360,
        ticks: 60,
        origin: {
          x: Math.random() * 0.6 + 0.2,
          y: Math.random() * 0.3 + 0.1,
        },
        colors,
        zIndex: 9999,
      });
    }, 350);

    return () => {
      clearTimeout(centerTimer);
      clearInterval(interval);
    };
  }, [isOpen]);

  if (!isOpen) return null;

  const displayLikes =
    typeof profile.likes === 'number' && profile.likes > 0
      ? profile.likes.toLocaleString()
      : '3,033';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-sm animate-fade-in select-none">
      {/* Modal Container */}
      <div className="relative w-full max-w-[340px] xs:max-w-sm sm:max-w-md bg-white rounded-3xl sm:rounded-[36px] shadow-2xl overflow-hidden border border-slate-100 animate-scale-up">
        {/* Floating Confetti Sprinkle Elements */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden z-10">
          <span className="absolute top-28 left-8 w-2 h-3.5 bg-rose-400/60 rounded-sm rotate-12" />
          <span className="absolute top-36 right-10 w-2.5 h-2 bg-amber-400/70 rounded-sm -rotate-45" />
          <span className="absolute top-44 left-14 w-2 h-2 bg-sky-400/60 rounded-full" />
          <span className="absolute top-52 right-14 w-1.5 h-3 bg-emerald-400/60 rounded-sm rotate-45" />
          <span className="absolute top-64 left-10 w-2 h-2.5 bg-purple-400/60 rounded-sm -rotate-12" />
          <span className="absolute top-72 right-8 w-2 h-3 bg-pink-400/60 rounded-sm rotate-25" />
          <span className="absolute bottom-28 left-12 w-2.5 h-1.5 bg-amber-300/70 rounded-sm rotate-12" />
          <span className="absolute bottom-24 right-16 w-2 h-2.5 bg-rose-400/60 rounded-sm -rotate-25" />
          <span className="absolute bottom-36 left-20 w-1.5 h-2 bg-blue-400/50 rounded-sm rotate-45" />
        </div>

        {/* Top Gradient Banner with Sparkles & Party Popper Animations */}
        <div className="relative h-10 sm:h-32 bg-gradient-to-r from-[#ff4b72] via-[#ff2b70] to-[#ff6b8b] flex items-start justify-between p-2 sm:p-5 overflow-hidden">
          {/* Party Popper Celebration Icons */}
          <div className="absolute top-1 left-2.5 sm:top-3 sm:left-4 text-sm sm:text-2xl animate-bounce">🎉</div>
          <div className="absolute top-1 right-8 sm:top-3 sm:right-14 text-sm sm:text-2xl animate-bounce delay-150">🎉</div>
          <div className="absolute bottom-1 left-10 text-white/70 text-[9px] sm:text-xs animate-ping">✨</div>

          {/* Sparkles */}
          <div className="absolute top-1.5 left-12 text-white/40 text-[9px] sm:text-xs">✦</div>
          <div className="absolute top-2 right-16 text-white/40 text-[9px] sm:text-xs">✦</div>

          <div />

          {/* Close Button */}
          <button
            type="button"
            onClick={onClose}
            className="w-6 h-6 sm:w-8 sm:h-8 rounded-full bg-white/25 hover:bg-white/40 text-white flex items-center justify-center transition-all shadow-sm z-20 cursor-pointer"
            aria-label="Close"
          >
            <X className="w-3 h-3 sm:w-4 sm:h-4" />
          </button>
        </div>

        {/* Overlapping Game Avatar Card */}
        <div className="relative -mt-6 sm:-mt-16 flex justify-center z-20">
          <div className="relative w-13 h-13 sm:w-26 sm:h-26 rounded-xl sm:rounded-[26px] bg-white p-0.5 sm:p-1.5 shadow-lg sm:shadow-2xl border-2 sm:border-4 border-white">
            <div className="w-full h-full rounded-[10px] sm:rounded-[20px] bg-gradient-to-tr from-slate-950 via-slate-900 to-indigo-950 overflow-hidden flex items-center justify-center relative">
              {profile.avatarUrl ? (
                <img
                  src={profile.avatarUrl}
                  alt={profile.nickname}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src =
                      'https://play-lh.googleusercontent.com/M_l-dWl4q9FLX3IgYu8lrSPAs6WrMiL2gPxzYwehWAsfFpOVOSG-APyLkUkJn8Og_uHXw_qv5K351Dyy4pmqoQ=s384';
                  }}
                />
              ) : (
                <img
                  src="https://play-lh.googleusercontent.com/M_l-dWl4q9FLX3IgYu8lrSPAs6WrMiL2gPxzYwehWAsfFpOVOSG-APyLkUkJn8Og_uHXw_qv5K351Dyy4pmqoQ=s384"
                  alt="Free Fire Max"
                  className="w-full h-full object-cover"
                />
              )}

              {/* Red "HOT" Badge on Top-Left */}
              <div className="absolute top-0.5 left-0.5 bg-gradient-to-r from-red-600 to-rose-600 text-white font-black text-[6px] sm:text-[9px] px-1 py-0.2 sm:px-1.5 sm:py-0.5 rounded sm:rounded-md shadow uppercase tracking-wider transform -rotate-6">
                HOT
              </div>

              {/* Free Fire Flame Badge on Bottom-Right */}
              <div className="absolute bottom-0.5 right-0.5 w-3.5 h-3.5 sm:w-5 sm:h-5 rounded-full bg-white flex items-center justify-center shadow p-0.5">
                <div className="w-full h-full rounded-full bg-gradient-to-br from-red-600 to-orange-500 flex items-center justify-center text-[7px] sm:text-[10px] text-white font-black">
                  🔥
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Body */}
        <div className="px-3.5 pt-0.5 pb-3 sm:px-6 sm:pt-3 sm:pb-6 text-center space-y-1.5 sm:space-y-4 relative z-20">
          {/* Verified Account Pill */}
          <div className="flex justify-center">
            <span className="inline-flex items-center gap-1 px-2 py-0.5 sm:px-3.5 sm:py-1 rounded-full text-[9px] sm:text-xs font-black tracking-wide bg-[#e6fbf2] text-[#059669] border border-[#a7f3d0]">
              <Check className="w-2.5 h-2.5 sm:w-3.5 sm:h-3.5 stroke-[3]" />
              VERIFIED ACCOUNT
            </span>
          </div>

          {/* Player Nickname */}
          <div>
            <h3 className="text-lg sm:text-3xl font-black text-slate-900 tracking-tight font-['Rajdhani'] leading-tight">
              {profile.nickname}
            </h3>
            <p className="hidden sm:flex text-xs sm:text-sm text-slate-500 font-medium mt-1 items-center justify-center gap-1.5">
              <span>🎉</span>
              <span>Congratulations — your account is ready!</span>
            </p>
          </div>

          {/* 3 Metric Cards */}
          <div className="grid grid-cols-3 gap-1.5 sm:gap-3 pt-0.5 sm:pt-1">
            {/* Level */}
            <div className="bg-[#f4f7fb] rounded-lg sm:rounded-2xl py-1 sm:py-3 px-1 sm:px-2 border border-slate-100 text-center shadow-sm">
              <div className="text-base sm:text-3xl font-black text-[#ff1353] font-['Rajdhani'] leading-none">
                {profile.level || 55}
              </div>
              <div className="text-[8px] sm:text-[10px] font-bold text-slate-400 uppercase tracking-wider sm:tracking-widest mt-0.5 sm:mt-1">
                LEVEL
              </div>
            </div>

            {/* Region */}
            <div className="bg-[#f4f7fb] rounded-lg sm:rounded-2xl py-1 sm:py-3 px-1 sm:px-2 border border-slate-100 text-center shadow-sm">
              <div className="text-base sm:text-3xl font-black text-[#ff1353] font-['Rajdhani'] leading-none">
                {profile.region || 'IND'}
              </div>
              <div className="text-[8px] sm:text-[10px] font-bold text-slate-400 uppercase tracking-wider sm:tracking-widest mt-0.5 sm:mt-1">
                REGION
              </div>
            </div>

            {/* Likes */}
            <div className="bg-[#f4f7fb] rounded-lg sm:rounded-2xl py-1 sm:py-3 px-1 sm:px-2 border border-slate-100 text-center shadow-sm">
              <div className="text-base sm:text-3xl font-black text-[#ff1353] font-['Rajdhani'] leading-none">
                {displayLikes}
              </div>
              <div className="text-[8px] sm:text-[10px] font-bold text-slate-400 uppercase tracking-wider sm:tracking-widest mt-0.5 sm:mt-1">
                LIKES
              </div>
            </div>
          </div>

          {/* UID & Likes Box */}
          <div className="bg-[#f8fafc] rounded-lg sm:rounded-2xl p-2 sm:p-4 border border-slate-100 text-[10px] sm:text-xs text-slate-600 shadow-sm space-y-1 sm:space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-500">UID</span>
              <span className="font-mono font-black text-slate-900 text-xs sm:text-sm tracking-wide">
                {profile.uid}
              </span>
            </div>
            <div className="border-t border-slate-200/70" />
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-500 flex items-center gap-1">
                <Heart className="w-3 h-3 sm:w-3.5 sm:h-3.5 text-rose-500 fill-rose-500" />
                <span>Likes</span>
              </span>
              <span className="font-mono font-black text-slate-900 text-xs sm:text-sm tracking-wide">
                {displayLikes}
              </span>
            </div>
          </div>

          {/* Action Buttons: Proceed to Store & Call Admin */}
          <div className="pt-0.5 sm:pt-2 space-y-1 sm:space-y-2">
            <button
              type="button"
              onClick={onProceed}
              className="w-full py-2 sm:py-3.5 rounded-full bg-gradient-to-r from-[#ff1353] via-[#ff2262] to-[#ff2b70] hover:from-[#ff0044] hover:to-[#ff1f66] text-white font-extrabold text-xs sm:text-base tracking-wide shadow-md sm:shadow-xl shadow-rose-500/35 hover:shadow-rose-500/50 hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer flex items-center justify-center gap-1.5"
            >
              <span>Proceed to Store</span>
              <span className="text-sm sm:text-lg">→</span>
            </button>

            {onCallAdmin && (
              <button
                type="button"
                onClick={onCallAdmin}
                className="w-full py-1.5 sm:py-2.5 rounded-full bg-gradient-to-r from-emerald-600 via-emerald-500 to-teal-500 hover:from-emerald-700 hover:to-teal-600 text-white font-black text-xs sm:text-sm tracking-wide shadow-md shadow-emerald-500/25 hover:shadow-emerald-500/40 hover:scale-[1.01] active:scale-[0.99] transition-all cursor-pointer flex items-center justify-center gap-1.5"
              >
                <Phone className="w-3.5 h-3.5 text-white animate-bounce" />
                <span>Call Admin</span>
              </button>
            )}

            {/* Re-enter UID option */}
            <div>
              <button
                type="button"
                onClick={onReEnterUid}
                className="text-[9px] sm:text-xs font-semibold text-slate-400 hover:text-rose-500 transition-colors cursor-pointer"
              >
                Not my account? Re-enter UID
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
