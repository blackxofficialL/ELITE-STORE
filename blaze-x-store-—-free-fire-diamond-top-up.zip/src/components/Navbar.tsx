import React, { useState } from 'react';
import {
  Menu,
  X,
  Search,
  ShieldCheck,
} from 'lucide-react';

interface NavbarProps {
  isDark?: boolean;
  onToggleTheme?: () => void;
  notificationsEnabled?: boolean;
  onToggleNotifications?: () => void;
  onOpenTracker: () => void;
  onOpenAdmin: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenTracker,
  onOpenAdmin,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id) || document.getElementById('uid-verification-section');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <nav className="sticky top-0 z-40 w-full backdrop-blur-xl bg-white/75 dark:bg-slate-900/75 border-b border-white/80 dark:border-white/10 shadow-[0_4px_30px_rgba(0,0,0,0.03)] transition-all select-none">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Brand Logo matching Image 2 */}
          <div
            className="flex items-center gap-2.5 sm:gap-3 cursor-pointer"
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          >
            {/* Free Fire Garena Style Flame Icon or Custom Logo */}
            <div className="relative flex items-center justify-center w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-gradient-to-tr from-red-600 to-orange-500 shadow-md shadow-red-500/25 flex-shrink-0 overflow-hidden">
              <span className="text-white font-black text-sm absolute">🔥</span>
              <img
                src="/logo.png"
                alt="ELITE STORE Logo"
                className="w-full h-full object-cover relative z-10"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).style.display = 'none';
                }}
              />
            </div>

            <div className="flex items-baseline gap-2">
              <span className="font-extrabold text-xl sm:text-2xl tracking-tight text-[#ff1353] font-['Rajdhani'] whitespace-nowrap">
                ELITE STORE
              </span>
              <span className="hidden sm:inline-block text-[10px] font-bold tracking-widest text-slate-400 uppercase">
                PREMIUM TOP-UP
              </span>
            </div>
          </div>

          {/* Desktop Navigation Links matching Image 2 */}
          <div className="hidden md:flex items-center space-x-8 text-sm font-bold text-slate-700">
            <button
              type="button"
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className="hover:text-[#ff1353] transition-colors cursor-pointer"
            >
              Home
            </button>
            <button
              type="button"
              onClick={() => scrollToSection('how-it-works')}
              className="hover:text-[#ff1353] transition-colors cursor-pointer"
            >
              How it works
            </button>
            <button
              type="button"
              onClick={() => scrollToSection('faq-section')}
              className="hover:text-[#ff1353] transition-colors cursor-pointer"
            >
              FAQ
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-2">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl text-slate-700 hover:text-rose-600 hover:bg-slate-100 transition-colors"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-slate-200 px-5 py-4 space-y-3 animate-fade-in shadow-xl">
          <button
            type="button"
            onClick={() => {
              setMobileMenuOpen(false);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="block w-full text-left py-2 font-bold text-slate-800 hover:text-rose-500 text-sm"
          >
            Home
          </button>
          <button
            type="button"
            onClick={() => scrollToSection('how-it-works')}
            className="block w-full text-left py-2 font-bold text-slate-800 hover:text-rose-500 text-sm"
          >
            How it works
          </button>
          <button
            type="button"
            onClick={() => scrollToSection('faq-section')}
            className="block w-full text-left py-2 font-bold text-slate-800 hover:text-rose-500 text-sm"
          >
            FAQ
          </button>
        </div>
      )}
    </nav>
  );
};
