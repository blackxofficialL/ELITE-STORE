import React, { useState, useEffect, useRef } from 'react';
import {
  PhoneOff,
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  ShieldCheck,
  User,
  Sparkles,
} from 'lucide-react';

interface CallAdminModalProps {
  isOpen: boolean;
  onClose: () => void;
  playerNickname?: string;
  playerUid?: string;
}

export const CallAdminModal: React.FC<CallAdminModalProps> = ({
  isOpen,
  onClose,
  playerNickname,
  playerUid,
}) => {
  const [callStatus, setCallStatus] = useState<'ringing' | 'connected' | 'ended'>('ringing');
  const [callDuration, setCallDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isSpeakerOn, setIsSpeakerOn] = useState(true);
  const [adminImageUrl, setAdminImageUrl] = useState<string | null>(null);
  const [adminVoiceUrl, setAdminVoiceUrl] = useState<string | null>(null);
  const [endCallVoiceUrl, setEndCallVoiceUrl] = useState<string | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const endAudioRef = useRef<HTMLAudioElement | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Fetch current media from /public/call_img, /public/call_voice, and /public/end_call_voice
  const fetchCallMedia = async () => {
    try {
      const res = await fetch('/api/call-media');
      if (res.ok) {
        const data = await res.json();
        if (data.imageUrl) setAdminImageUrl(data.imageUrl);
        if (data.voiceUrl) setAdminVoiceUrl(data.voiceUrl);
        if (data.endCallVoiceUrl) setEndCallVoiceUrl(data.endCallVoiceUrl);
      }
    } catch (err) {
      console.warn('Could not fetch call media:', err);
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchCallMedia();
      setCallStatus('ringing');
      setCallDuration(0);
      setIsPlayingAudio(false);

      // Transition from "Ringing..." to "Connected" after 1.8 seconds
      const connectTimer = setTimeout(() => {
        setCallStatus('connected');
      }, 1800);

      return () => {
        clearTimeout(connectTimer);
      };
    } else {
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
      if (endAudioRef.current) {
        endAudioRef.current.pause();
        endAudioRef.current = null;
      }
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    }
  }, [isOpen]);

  // Handle Voice Audio Playback when connected
  useEffect(() => {
    if (callStatus === 'connected' && adminVoiceUrl) {
      try {
        if (audioRef.current) {
          audioRef.current.pause();
          audioRef.current = null;
        }

        const audio = new Audio(adminVoiceUrl);
        audioRef.current = audio;
        audio.volume = isSpeakerOn ? 1.0 : 0.4;
        audio.muted = false;

        audio
          .play()
          .then(() => {
            setIsPlayingAudio(true);
          })
          .catch((err) => {
            console.warn('Autoplay prevented or audio error:', err);
          });

        audio.onended = () => {
          setIsPlayingAudio(false);
        };
      } catch (err) {
        console.warn('Audio setup error:', err);
      }
    }

    // Call timer once connected
    if (callStatus === 'connected') {
      timerRef.current = setInterval(() => {
        setCallDuration((prev) => prev + 1);
      }, 1000);
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [callStatus, adminVoiceUrl]);

  // Format call duration MM:SS
  const formatDuration = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainingSecs = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainingSecs.toString().padStart(2, '0')}`;
  };

  // Triggered when End Call button is clicked
  const handleEndCall = () => {
    // 1. Stop regular in-call voice
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current = null;
    }
    if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    setCallStatus('ended');
    setIsPlayingAudio(false);

    // 2. Play End Call Voice from /public/end_call_voice/ if available
    if (endCallVoiceUrl) {
      try {
        if (endAudioRef.current) {
          endAudioRef.current.pause();
          endAudioRef.current = null;
        }

        const endAudio = new Audio(endCallVoiceUrl);
        endAudioRef.current = endAudio;
        endAudio.volume = isSpeakerOn ? 1.0 : 0.5;

        endAudio
          .play()
          .then(() => {
            setIsPlayingAudio(true);
          })
          .catch((err) => {
            console.warn('End call audio play error:', err);
            setTimeout(() => onClose(), 600);
          });

        // Close when end audio completes (or max 8s safety timeout)
        const timeout = setTimeout(() => {
          onClose();
        }, 8000);

        endAudio.onended = () => {
          clearTimeout(timeout);
          setIsPlayingAudio(false);
          onClose();
        };
        return;
      } catch (err) {
        console.warn('End audio playback failed:', err);
      }
    }

    // If no end call voice exists, close modal after short fade
    setTimeout(() => {
      onClose();
    }, 500);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in select-none">
      {/* Call Dialog Container */}
      <div className="relative w-full max-w-sm rounded-[36px] bg-gradient-to-b from-slate-900 via-slate-950 to-black text-white p-6 shadow-2xl border border-slate-800 flex flex-col items-center justify-between min-h-[500px] overflow-hidden">
        {/* Background Ambient Glow */}
        <div className="absolute top-0 inset-x-0 h-40 bg-gradient-to-b from-rose-500/20 to-transparent pointer-events-none" />
        <div className="absolute bottom-0 inset-x-0 h-40 bg-gradient-to-t from-emerald-500/10 to-transparent pointer-events-none" />

        {/* Top Header */}
        <div className="relative z-10 w-full text-center space-y-1">
          <div className="inline-flex items-center gap-1 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-[11px] font-bold text-slate-300 border border-white/10">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span>ELITE STORE OFFICIAL SUPPORT</span>
          </div>

          <h3 className="text-xl sm:text-2xl font-black font-['Rajdhani'] tracking-tight text-white pt-2">
            ADMIN LIVE CALL DESK
          </h3>

          <p className="text-xs font-semibold text-slate-400">
            {callStatus === 'ringing' ? (
              <span className="text-amber-400 animate-pulse flex items-center justify-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
                Connecting & Ringing Admin...
              </span>
            ) : callStatus === 'connected' ? (
              <span className="text-emerald-400 font-mono font-bold flex items-center justify-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                Connected ({formatDuration(callDuration)})
              </span>
            ) : (
              <span className="text-rose-400 font-bold animate-pulse flex items-center justify-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-rose-500" />
                Call Ending...
              </span>
            )}
          </p>

          {playerNickname && (
            <div className="text-[11px] text-slate-400 font-medium">
              Caller: <strong className="text-slate-200">{playerNickname}</strong> (UID: {playerUid})
            </div>
          )}
        </div>

        {/* Center: Admin Avatar with Pulse Rings */}
        <div className="relative z-10 my-6 flex flex-col items-center justify-center">
          {/* Animated Glow Rings when Ringing or Playing Audio */}
          {(callStatus === 'ringing' || isPlayingAudio) && (
            <>
              <div className="absolute w-36 h-36 rounded-full bg-rose-500/20 animate-ping pointer-events-none" />
              <div className="absolute w-44 h-44 rounded-full border border-rose-500/30 animate-pulse pointer-events-none" />
            </>
          )}

          {/* Admin Image Frame */}
          <div className="relative w-32 h-32 rounded-full p-1 bg-gradient-to-tr from-rose-500 via-orange-500 to-amber-400 shadow-2xl">
            <div className="w-full h-full rounded-full bg-slate-900 overflow-hidden flex items-center justify-center border-2 border-slate-950 relative">
              {adminImageUrl ? (
                <img
                  src={adminImageUrl}
                  alt="Admin Photo"
                  className="w-full h-full object-cover"
                  onError={() => setAdminImageUrl(null)}
                />
              ) : (
                <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-tr from-slate-900 to-indigo-950 text-slate-400">
                  <User className="w-12 h-12 text-slate-300 mb-1" />
                  <span className="text-[9px] text-slate-400 font-bold uppercase">ADMIN</span>
                </div>
              )}

              {/* Verified Online Badge */}
              <div className="absolute bottom-1 right-1 w-5 h-5 rounded-full bg-emerald-500 border-2 border-slate-950 flex items-center justify-center shadow-md">
                <Sparkles className="w-2.5 h-2.5 text-white" />
              </div>
            </div>
          </div>

          {/* Admin Title */}
          <div className="mt-3.5 text-center">
            <h4 className="text-base font-extrabold text-white">Elite Store Admin</h4>
            <p className="text-[11px] text-slate-400">Instant Diamond Crediting Officer</p>
          </div>

          {/* Voice Wave Animation */}
          {callStatus === 'connected' && (
            <div className="flex items-center gap-1 mt-3 h-5">
              {[4, 8, 14, 20, 12, 18, 6, 16, 10, 5].map((h, i) => (
                <span
                  key={i}
                  style={{ height: isPlayingAudio ? `${h}px` : '4px' }}
                  className="w-1 bg-gradient-to-t from-emerald-500 to-teal-300 rounded-full transition-all duration-150 animate-pulse"
                />
              ))}
            </div>
          )}

          {callStatus === 'ended' && endCallVoiceUrl && (
            <div className="text-[11px] text-rose-400 font-semibold mt-2 animate-pulse">
              Playing farewell message...
            </div>
          )}
        </div>

        {/* Bottom Call Controls */}
        <div className="relative z-10 w-full flex items-center justify-around pt-2">
          {/* Mute Button */}
          <button
            type="button"
            onClick={() => setIsMuted(!isMuted)}
            className={`w-12 h-12 rounded-full flex items-center justify-center text-white transition-all cursor-pointer ${
              isMuted ? 'bg-rose-500/80 text-white' : 'bg-white/15 hover:bg-white/25'
            }`}
            title={isMuted ? 'Unmute' : 'Mute'}
          >
            {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>

          {/* End Call Button (Big Red Button) */}
          <button
            type="button"
            onClick={handleEndCall}
            disabled={callStatus === 'ended'}
            className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-700 active:scale-95 text-white flex items-center justify-center shadow-lg shadow-rose-600/40 transition-all cursor-pointer disabled:opacity-50"
            title="End Call"
          >
            <PhoneOff className="w-7 h-7" />
          </button>

          {/* Speaker Button */}
          <button
            type="button"
            onClick={() => {
              const next = !isSpeakerOn;
              setIsSpeakerOn(next);
              if (audioRef.current) {
                audioRef.current.volume = next ? 1.0 : 0.4;
              }
              if (endAudioRef.current) {
                endAudioRef.current.volume = next ? 1.0 : 0.4;
              }
            }}
            className={`w-12 h-12 rounded-full flex items-center justify-center text-white transition-all cursor-pointer ${
              !isSpeakerOn ? 'bg-amber-500/80 text-white' : 'bg-white/15 hover:bg-white/25'
            }`}
            title={isSpeakerOn ? 'Speaker On' : 'Speaker Off'}
          >
            {isSpeakerOn ? <Volume2 className="w-5 h-5" /> : <VolumeX className="w-5 h-5" />}
          </button>
        </div>
      </div>
    </div>
  );
};
