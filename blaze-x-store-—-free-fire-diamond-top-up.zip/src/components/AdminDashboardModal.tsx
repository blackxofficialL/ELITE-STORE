import React, { useState, useEffect } from 'react';
import {
  DiamondPackage,
  Order,
  OrderStatus,
  SystemConfigStatus,
} from '../types/index.ts';
import {
  ShieldCheck,
  Lock,
  LogOut,
  TrendingUp,
  PackageCheck,
  AlertCircle,
  CheckCircle2,
  Settings,
  RefreshCw,
  Search,
  DollarSign,
  Activity,
  Layers,
  FileText,
  Save,
  Plus,
} from 'lucide-react';
import { getStatusBadgeInfo } from '../shared/orderStateMachine.ts';

interface AdminDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPackagesUpdated: () => void;
}

export const AdminDashboardModal: React.FC<AdminDashboardModalProps> = ({
  isOpen,
  onClose,
  onPackagesUpdated,
}) => {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem('blaze_admin_token'));
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  const [activeTab, setActiveTab] = useState<'overview' | 'orders' | 'packages' | 'uid_api' | 'diagnostics'>('overview');
  const [stats, setStats] = useState<Record<string, number> | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [packages, setPackages] = useState<DiamondPackage[]>([]);
  const [logs, setLogs] = useState<Array<{ id: string; timestamp: string; category: string; message: string }>>([]);
  const [configStatus, setConfigStatus] = useState<SystemConfigStatus | null>(null);
  const [isLoadingData, setIsLoadingData] = useState(false);

  // Filters for orders
  const [orderFilter, setOrderFilter] = useState<string>('all');
  const [orderSearch, setOrderSearch] = useState('');

  // Package editing state
  const [editingPackages, setEditingPackages] = useState<DiamondPackage[]>([]);
  const [isSavingPackages, setIsSavingPackages] = useState(false);
  const [packageSuccessMsg, setPackageSuccessMsg] = useState<string | null>(null);

  // UID & API Management state
  const [apiUrl, setApiUrl] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [apiEnabled, setApiEnabled] = useState(true);
  const [apiSaveMsg, setApiSaveMsg] = useState<string | null>(null);
  const [isSavingApi, setIsSavingApi] = useState(false);
  const [testUid, setTestUid] = useState('451012596');
  const [testResult, setTestResult] = useState<any>(null);
  const [isTestingApi, setIsTestingApi] = useState(false);

  // Custom Verified Profiles state
  const [profiles, setProfiles] = useState<any[]>([]);
  const [newProfileUid, setNewProfileUid] = useState('');
  const [newProfileName, setNewProfileName] = useState('');
  const [newProfileLevel, setNewProfileLevel] = useState(65);
  const [newProfileRank, setNewProfileRank] = useState('Heroic V');
  const [newProfileGuild, setNewProfileGuild] = useState('');
  const [newProfileVBadge, setNewProfileVBadge] = useState(false);
  const [profileMsg, setProfileMsg] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen && token) {
      loadDashboardData();
    }
  }, [isOpen, token]);

  const loadDashboardData = async () => {
    if (!token) return;
    setIsLoadingData(true);
    try {
      const headers = { Authorization: `Bearer ${token}` };

      // Load stats
      const statsRes = await fetch('/api/admin/stats', { headers });
      if (statsRes.status === 401) {
        handleLogout();
        return;
      }
      const statsData = await statsRes.json();
      setStats(statsData.stats);

      // Load orders
      const ordersRes = await fetch('/api/admin/orders', { headers });
      const ordersData = await ordersRes.json();
      setOrders(ordersData.orders || []);

      // Load packages
      const pkgRes = await fetch('/api/packages');
      const pkgData = await pkgRes.json();
      setPackages(pkgData.packages || []);
      setEditingPackages(pkgData.packages || []);

      // Load system status
      const statusRes = await fetch('/api/config/status');
      const statusData = await statusRes.json();
      setConfigStatus(statusData);

      // Load logs
      const logsRes = await fetch('/api/admin/logs', { headers });
      const logsData = await logsRes.json();
      setLogs(logsData.logs || []);

      // Load API config
      try {
        const apiRes = await fetch('/api/admin/api-config', { headers });
        if (apiRes.ok) {
          const apiData = await apiRes.json();
          if (apiData.config) {
            setApiUrl(apiData.config.url || '');
            setApiKey(apiData.config.apiKey || '');
            setApiEnabled(apiData.config.enabled ?? true);
          }
        }
      } catch {}

      // Load custom profiles
      try {
        const profRes = await fetch('/api/admin/profiles', { headers });
        if (profRes.ok) {
          const profData = await profRes.json();
          setProfiles(profData.profiles || []);
        }
      } catch {}
    } catch (err) {
      console.error('Error loading admin data:', err);
    } finally {
      setIsLoadingData(false);
    }
  };

  const handleSaveApiConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) return;
    setIsSavingApi(true);
    setApiSaveMsg(null);
    try {
      const res = await fetch('/api/admin/api-config', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          url: apiUrl.trim(),
          apiKey: apiKey.trim(),
          enabled: apiEnabled,
        }),
      });
      if (res.ok) {
        setApiSaveMsg('API configuration saved successfully!');
        setTimeout(() => setApiSaveMsg(null), 3000);
      }
    } catch {
      setApiSaveMsg('Failed to save API config');
    } finally {
      setIsSavingApi(false);
    }
  };

  const handleTestApi = async () => {
    if (!token || !apiUrl.trim()) return;
    setIsTestingApi(true);
    setTestResult(null);
    try {
      const res = await fetch('/api/admin/test-api', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          url: apiUrl.trim(),
          apiKey: apiKey.trim(),
          uid: testUid.trim() || '451012596',
        }),
      });
      const data = await res.json();
      setTestResult(data);
    } catch (err: any) {
      setTestResult({ success: false, error: err.message });
    } finally {
      setIsTestingApi(false);
    }
  };

  const handleAddProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token || !newProfileUid.trim() || !newProfileName.trim()) return;
    setProfileMsg(null);
    try {
      const res = await fetch('/api/admin/profiles', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          uid: newProfileUid.trim(),
          nickname: newProfileName.trim(),
          level: Number(newProfileLevel) || 65,
          rank: newProfileRank.trim(),
          guildName: newProfileGuild.trim() || undefined,
          hasVBadge: newProfileVBadge,
        }),
      });
      if (res.ok) {
        setProfileMsg(`Profile registered for UID ${newProfileUid}!`);
        setNewProfileUid('');
        setNewProfileName('');
        const profRes = await fetch('/api/admin/profiles', {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (profRes.ok) {
          const profData = await profRes.json();
          setProfiles(profData.profiles || []);
        }
        setTimeout(() => setProfileMsg(null), 3000);
      }
    } catch {
      setProfileMsg('Failed to register profile');
    }
  };

  const handleDeleteProfile = async (uid: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/admin/profiles/${uid}`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) {
        setProfiles((prev) => prev.filter((p) => p.uid !== uid));
      }
    } catch {}
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setIsLoggingIn(true);

    try {
      const res = await fetch('/api/admin/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ password }),
      });
      const data = await res.json();

      if (!res.ok || !data.success) {
        setLoginError(data.error || 'Authentication failed. Please check password.');
        return;
      }

      setToken(data.token);
      localStorage.setItem('blaze_admin_token', data.token);
    } catch (err) {
      setLoginError('Network error trying to authenticate.');
    } finally {
      setIsLoggingIn(false);
    }
  };

  const handleLogout = () => {
    setToken(null);
    localStorage.removeItem('blaze_admin_token');
    setPassword('');
  };

  const handleUpdateOrderStatus = async (orderId: string, newStatus: OrderStatus) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/admin/orders/${orderId}/status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) {
        await loadDashboardData();
      }
    } catch (err) {
      console.error('Failed to update status:', err);
    }
  };

  const handleTriggerFulfillment = async (orderId: string) => {
    if (!token) return;
    try {
      const res = await fetch(`/api/admin/orders/${orderId}/status`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ triggerFulfillment: true }),
      });
      if (res.ok) {
        await loadDashboardData();
      }
    } catch (err) {
      console.error('Failed to trigger fulfillment:', err);
    }
  };

  const handleSavePackages = async () => {
    if (!token) return;
    setIsSavingPackages(true);
    setPackageSuccessMsg(null);

    try {
      const res = await fetch('/api/admin/packages', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ packages: editingPackages }),
      });

      if (res.ok) {
        setPackageSuccessMsg('Packages and pricing saved successfully!');
        onPackagesUpdated();
        setTimeout(() => setPackageSuccessMsg(null), 3000);
      }
    } catch (err) {
      console.error('Failed to save packages:', err);
    } finally {
      setIsSavingPackages(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md animate-fade-in">
      <div className="bg-white dark:bg-slate-900 rounded-3xl max-w-5xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center justify-between bg-slate-50 dark:bg-slate-950/50">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-rose-600 to-orange-500 flex items-center justify-center text-white shadow-md">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-xl font-extrabold text-slate-900 dark:text-white font-['Rajdhani']">
                  ELITE STORE — ADMIN PORTAL
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-500/10 text-rose-500 border border-rose-500/20">
                  CONFIDENTIAL
                </span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400">
                Server-side protected order operations, pricing control & system diagnostics
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {token && (
              <button
                onClick={handleLogout}
                className="px-3 py-1.5 rounded-xl text-xs font-bold text-rose-600 dark:text-rose-400 hover:bg-rose-50 dark:hover:bg-rose-950/40 flex items-center gap-1.5 transition-colors"
              >
                <LogOut className="w-3.5 h-3.5" />
                <span>Sign Out</span>
              </button>
            )}
            <button
              onClick={onClose}
              className="w-8 h-8 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-500 hover:text-slate-900 dark:hover:text-white flex items-center justify-center text-sm font-bold"
            >
              ✕
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto p-6">
          {!token ? (
            /* Login Form */
            <div className="max-w-md mx-auto py-12 space-y-5">
              <div className="text-center space-y-2">
                <div className="w-14 h-14 rounded-2xl bg-rose-500/10 text-rose-500 flex items-center justify-center mx-auto border border-rose-500/20">
                  <Lock className="w-7 h-7" />
                </div>
                <h4 className="text-2xl font-extrabold text-slate-900 dark:text-white font-['Rajdhani']">
                  AUTHENTICATE AS ADMINISTRATOR
                </h4>
                <p className="text-xs text-slate-500 dark:text-slate-400">
                  Enter master administration secret key configured in server environment.
                </p>
              </div>

              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300 mb-1">
                    Master Password / Secret Key
                  </label>
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter admin password (e.g. blaze_admin_2026)"
                    className="w-full h-12 px-4 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-sm font-medium focus:outline-none focus:ring-2 focus:ring-rose-500 text-slate-900 dark:text-white"
                  />
                  <p className="text-[11px] text-slate-400 mt-1">
                    Default dev credential: <code>blaze_admin_2026</code>
                  </p>
                </div>

                {loginError && (
                  <div className="p-3 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 text-xs font-semibold flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    <span>{loginError}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isLoggingIn || !password}
                  className="w-full h-12 rounded-xl font-bold text-white bg-gradient-to-r from-rose-500 to-orange-500 hover:from-rose-600 hover:to-orange-600 shadow-md text-sm transition-all disabled:opacity-50"
                >
                  {isLoggingIn ? 'Verifying Credentials...' : 'Unlock Admin Portal'}
                </button>
              </form>
            </div>
          ) : (
            /* Admin Tabs & Panel */
            <div className="space-y-6">
              {/* Tab Navigation */}
              <div className="flex items-center gap-2 border-b border-slate-200 dark:border-slate-800 pb-3 flex-wrap">
                <button
                  onClick={() => setActiveTab('overview')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                    activeTab === 'overview'
                      ? 'bg-rose-500 text-white shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  <TrendingUp className="w-4 h-4" />
                  Overview & Sales
                </button>

                <button
                  onClick={() => setActiveTab('orders')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                    activeTab === 'orders'
                      ? 'bg-rose-500 text-white shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  <PackageCheck className="w-4 h-4" />
                  Orders ({orders.length})
                </button>

                <button
                  onClick={() => setActiveTab('packages')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                    activeTab === 'packages'
                      ? 'bg-rose-500 text-white shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  <Layers className="w-4 h-4" />
                  Package & Price Editor
                </button>

                <button
                  onClick={() => setActiveTab('uid_api')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                    activeTab === 'uid_api'
                      ? 'bg-rose-500 text-white shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  <Search className="w-4 h-4" />
                  Free Fire UID & API ({profiles.length})
                </button>

                <button
                  onClick={() => setActiveTab('diagnostics')}
                  className={`px-4 py-2 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${
                    activeTab === 'diagnostics'
                      ? 'bg-rose-500 text-white shadow-sm'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                  }`}
                >
                  <Activity className="w-4 h-4" />
                  API Health & Logs
                </button>

                <button
                  onClick={loadDashboardData}
                  className="ml-auto p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
                  title="Refresh Data"
                >
                  <RefreshCw className="w-4 h-4" />
                </button>
              </div>

              {/* Overview Tab */}
              {activeTab === 'overview' && (
                <div className="space-y-6">
                  {/* KPI Cards */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                    <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                      <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase">
                        Total Revenue
                      </span>
                      <p className="text-2xl font-extrabold text-slate-900 dark:text-white font-['Rajdhani'] mt-1">
                        ₹{stats?.totalRevenueINR || 0}
                      </p>
                      <span className="text-[10px] text-emerald-500 font-bold">From paid orders</span>
                    </div>

                    <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                      <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase">
                        Total Orders
                      </span>
                      <p className="text-2xl font-extrabold text-slate-900 dark:text-white font-['Rajdhani'] mt-1">
                        {stats?.totalOrders || 0}
                      </p>
                      <span className="text-[10px] text-slate-400">All registered checkouts</span>
                    </div>

                    <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                      <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase">
                        Delivered Top-Ups
                      </span>
                      <p className="text-2xl font-extrabold text-emerald-600 dark:text-emerald-400 font-['Rajdhani'] mt-1">
                        {stats?.deliveredOrders || 0}
                      </p>
                      <span className="text-[10px] text-emerald-500 font-bold">100% credited</span>
                    </div>

                    <div className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
                      <span className="text-[11px] font-bold text-slate-500 dark:text-slate-400 uppercase">
                        Success Rate
                      </span>
                      <p className="text-2xl font-extrabold text-rose-600 dark:text-rose-400 font-['Rajdhani'] mt-1">
                        {stats?.fulfillmentSuccessRate || 100}%
                      </p>
                      <span className="text-[10px] text-slate-400">Fulfillment reliability</span>
                    </div>
                  </div>

                  {/* System integration status cards */}
                  <div className="rounded-2xl p-5 bg-gradient-to-r from-slate-50 to-white dark:from-slate-800/40 dark:to-slate-800/10 border border-slate-200 dark:border-slate-700 space-y-3">
                    <h4 className="text-sm font-extrabold text-slate-900 dark:text-white font-['Rajdhani']">
                      LIVE SYSTEM HEALTH MATRIX
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
                      <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                        <span className="text-[11px] text-slate-400 block">UID Lookup Service</span>
                        <span className="font-bold text-slate-900 dark:text-white block mt-0.5">
                          {configStatus?.lookupProvider.name || 'Active'}
                        </span>
                        <span className="inline-flex items-center gap-1 text-[10px] text-emerald-500 font-bold mt-1">
                          <CheckCircle2 className="w-3 h-3" />
                          Operational
                        </span>
                      </div>

                      <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                        <span className="text-[11px] text-slate-400 block">Payment Gateway</span>
                        <span className="font-bold text-slate-900 dark:text-white block mt-0.5 uppercase">
                          {configStatus?.paymentGateway.provider || 'Razorpay / Sandbox'}
                        </span>
                        <span className="inline-flex items-center gap-1 text-[10px] text-emerald-500 font-bold mt-1">
                          <CheckCircle2 className="w-3 h-3" />
                          HMAC-SHA256 Active
                        </span>
                      </div>

                      <div className="p-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800">
                        <span className="text-[11px] text-slate-400 block">Diamond Delivery Queue</span>
                        <span className="font-bold text-slate-900 dark:text-white block mt-0.5">
                          Automated Auto-Queue
                        </span>
                        <span className="inline-flex items-center gap-1 text-[10px] text-emerald-500 font-bold mt-1">
                          <CheckCircle2 className="w-3 h-3" />
                          Dispatch Ready
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Orders Tab */}
              {activeTab === 'orders' && (
                <div className="space-y-4">
                  {/* Filters & Search */}
                  <div className="flex flex-col sm:flex-row gap-2 justify-between items-center">
                    <div className="relative w-full sm:w-64">
                      <input
                        type="text"
                        value={orderSearch}
                        onChange={(e) => setOrderSearch(e.target.value)}
                        placeholder="Search UID, Nickname, or Order ID..."
                        className="w-full h-10 pl-9 pr-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs font-medium focus:outline-none focus:ring-2 focus:ring-rose-500 text-slate-900 dark:text-white"
                      />
                      <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-3.5" />
                    </div>

                    <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto">
                      {['all', 'delivered', 'processing', 'pending_payment', 'failed', 'refunded'].map((status) => (
                        <button
                          key={status}
                          onClick={() => setOrderFilter(status)}
                          className={`px-3 py-1.5 rounded-xl text-[11px] font-bold capitalize whitespace-nowrap ${
                            orderFilter === status
                              ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900'
                              : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
                          }`}
                        >
                          {status.replace('_', ' ')}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Orders Table */}
                  <div className="overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-50 dark:bg-slate-800/80 text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider text-[10px]">
                        <tr>
                          <th className="p-3.5">Order ID</th>
                          <th className="p-3.5">Player (UID)</th>
                          <th className="p-3.5">Diamonds</th>
                          <th className="p-3.5">Amount</th>
                          <th className="p-3.5">Status</th>
                          <th className="p-3.5 text-right">Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {orders
                          .filter((o) => {
                            if (orderFilter !== 'all' && o.status !== orderFilter) return false;
                            if (orderSearch) {
                              const s = orderSearch.toLowerCase();
                              return (
                                o.id.toLowerCase().includes(s) ||
                                o.uid.includes(s) ||
                                o.nickname.toLowerCase().includes(s)
                              );
                            }
                            return true;
                          })
                          .map((o) => {
                            const badge = getStatusBadgeInfo(o.status);
                            return (
                              <tr key={o.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                                <td className="p-3.5 font-mono font-bold text-slate-900 dark:text-white">
                                  {o.id}
                                </td>
                                <td className="p-3.5">
                                  <span className="font-bold text-slate-900 dark:text-white block">
                                    {o.nickname}
                                  </span>
                                  <span className="font-mono text-[11px] text-slate-400">
                                    {o.uid} ({o.region})
                                  </span>
                                </td>
                                <td className="p-3.5 font-bold text-rose-500">
                                  💎 {o.diamonds + o.bonusDiamonds}
                                </td>
                                <td className="p-3.5 font-bold text-slate-900 dark:text-white">
                                  ₹{o.amountINR}
                                </td>
                                <td className="p-3.5">
                                  <span
                                    className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold border ${badge.colorClass}`}
                                  >
                                    {badge.label}
                                  </span>
                                </td>
                                <td className="p-3.5 text-right space-x-1">
                                  {o.status === 'failed' && (
                                    <button
                                      onClick={() => handleTriggerFulfillment(o.id)}
                                      className="px-2 py-1 rounded-lg text-[10px] font-bold bg-purple-500 text-white hover:bg-purple-600"
                                    >
                                      Retry
                                    </button>
                                  )}
                                  {o.status !== 'delivered' && o.status !== 'refunded' && (
                                    <button
                                      onClick={() => handleUpdateOrderStatus(o.id, 'delivered')}
                                      className="px-2 py-1 rounded-lg text-[10px] font-bold bg-emerald-500 text-white hover:bg-emerald-600"
                                    >
                                      Mark Delivered
                                    </button>
                                  )}
                                  {o.status !== 'refunded' && (
                                    <button
                                      onClick={() => handleUpdateOrderStatus(o.id, 'refund_pending')}
                                      className="px-2 py-1 rounded-lg text-[10px] font-bold bg-rose-500/10 text-rose-500 hover:bg-rose-500 hover:text-white"
                                    >
                                      Refund
                                    </button>
                                  )}
                                </td>
                              </tr>
                            );
                          })}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* Package & Price Editor Tab */}
              {activeTab === 'packages' && (
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h4 className="text-base font-extrabold text-slate-900 dark:text-white font-['Rajdhani']">
                        ACTIVE STORE CATALOG & INVENTORY PRICING
                      </h4>
                      <p className="text-xs text-slate-500 dark:text-slate-400">
                        Adjust selling price, bonus diamonds, and active availability.
                      </p>
                    </div>

                    <button
                      onClick={handleSavePackages}
                      disabled={isSavingPackages}
                      className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 flex items-center gap-1.5 shadow-md transition-all"
                    >
                      <Save className="w-3.5 h-3.5" />
                      <span>{isSavingPackages ? 'Saving...' : 'Save Catalog Changes'}</span>
                    </button>
                  </div>

                  {packageSuccessMsg && (
                    <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                      <span>{packageSuccessMsg}</span>
                    </div>
                  )}

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {editingPackages.map((pkg, idx) => (
                      <div
                        key={pkg.id}
                        className="p-4 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-extrabold text-sm text-slate-900 dark:text-white font-['Rajdhani']">
                            {pkg.diamonds} Diamonds ({pkg.type})
                          </span>
                          <label className="flex items-center gap-1 text-xs cursor-pointer font-bold text-slate-600 dark:text-slate-400">
                            <input
                              type="checkbox"
                              checked={pkg.active}
                              onChange={(e) => {
                                const next = [...editingPackages];
                                next[idx].active = e.target.checked;
                                setEditingPackages(next);
                              }}
                              className="rounded text-rose-500 focus:ring-rose-500"
                            />
                            Active
                          </label>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-xs">
                          <div>
                            <label className="text-[10px] font-bold text-slate-400 block mb-1">
                              Selling Price (₹ INR)
                            </label>
                            <input
                              type="number"
                              value={pkg.priceINR}
                              onChange={(e) => {
                                const next = [...editingPackages];
                                next[idx].priceINR = Number(e.target.value) || 0;
                                setEditingPackages(next);
                              }}
                              className="w-full h-9 px-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
                            />
                          </div>

                          <div>
                            <label className="text-[10px] font-bold text-slate-400 block mb-1">
                              Original Price (₹ INR)
                            </label>
                            <input
                              type="number"
                              value={pkg.originalPriceINR}
                              onChange={(e) => {
                                const next = [...editingPackages];
                                next[idx].originalPriceINR = Number(e.target.value) || 0;
                                setEditingPackages(next);
                              }}
                              className="w-full h-9 px-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
                            />
                          </div>

                          <div>
                            <label className="text-[10px] font-bold text-slate-400 block mb-1">
                              Bonus Gems
                            </label>
                            <input
                              type="number"
                              value={pkg.bonus}
                              onChange={(e) => {
                                const next = [...editingPackages];
                                next[idx].bonus = Number(e.target.value) || 0;
                                setEditingPackages(next);
                              }}
                              className="w-full h-9 px-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
                            />
                          </div>

                          <div>
                            <label className="text-[10px] font-bold text-slate-400 block mb-1">
                              Promo Badge
                            </label>
                            <input
                              type="text"
                              value={pkg.badge || ''}
                              onChange={(e) => {
                                const next = [...editingPackages];
                                next[idx].badge = e.target.value;
                                setEditingPackages(next);
                              }}
                              placeholder="e.g. Best Value"
                              className="w-full h-9 px-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-bold"
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Free Fire UID & API Management Tab */}
              {activeTab === 'uid_api' && (
                <div className="space-y-6">
                  {/* External API Configuration */}
                  <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Settings className="w-5 h-5 text-rose-500" />
                        <h4 className="text-base font-extrabold text-slate-900 dark:text-white font-['Rajdhani']">
                          EXTERNAL FREE FIRE LOOKUP API SETTINGS
                        </h4>
                      </div>
                      <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                        Supports GitHub APIs, Vercel edge functions, RapidAPI & REST proxies
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300">
                      Configure your external Free Fire UID lookup API endpoint. When a player enters their UID, this API is queried first. If no external API is configured, the store uses the verified player registry and allows instant manual nickname confirmation with zero mock data.
                    </p>

                    {apiSaveMsg && (
                      <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                        <span>{apiSaveMsg}</span>
                      </div>
                    )}

                    <form onSubmit={handleSaveApiConfig} className="space-y-3">
                      <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 text-xs">
                        <div className="sm:col-span-7">
                          <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                            API Endpoint URL (GET or POST with ?uid=...&region=...)
                          </label>
                          <input
                            type="url"
                            value={apiUrl}
                            onChange={(e) => setApiUrl(e.target.value)}
                            placeholder="https://your-api.com/api/v1/player or https://freefire-api.vercel.app/info"
                            className="w-full h-10 px-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono font-medium text-xs text-slate-900 dark:text-white"
                          />
                        </div>

                        <div className="sm:col-span-3">
                          <label className="font-bold text-slate-700 dark:text-slate-300 block mb-1">
                            API Key / Bearer Token (Optional)
                          </label>
                          <input
                            type="password"
                            value={apiKey}
                            onChange={(e) => setApiKey(e.target.value)}
                            placeholder="Optional Secret Token"
                            className="w-full h-10 px-3 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono text-xs text-slate-900 dark:text-white"
                          />
                        </div>

                        <div className="sm:col-span-2 flex items-end">
                          <button
                            type="submit"
                            disabled={isSavingApi}
                            className="w-full h-10 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all disabled:opacity-50"
                          >
                            <Save className="w-4 h-4" />
                            <span>{isSavingApi ? 'Saving...' : 'Save API'}</span>
                          </button>
                        </div>
                      </div>
                    </form>

                    {/* Live API Tester */}
                    <div className="pt-3 border-t border-slate-200 dark:border-slate-700/60">
                      <span className="text-xs font-bold text-slate-700 dark:text-slate-300 block mb-2">
                        ⚡ Live API Diagnostic Tester
                      </span>
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={testUid}
                          onChange={(e) => setTestUid(e.target.value)}
                          placeholder="Enter UID to test (e.g. 451012596)"
                          className="flex-1 h-9 px-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 font-mono text-xs text-slate-900 dark:text-white"
                        />
                        <button
                          type="button"
                          onClick={handleTestApi}
                          disabled={isTestingApi || !apiUrl.trim()}
                          className="px-4 h-9 rounded-lg bg-slate-900 dark:bg-slate-700 hover:bg-slate-800 text-white font-bold text-xs flex items-center gap-1.5 disabled:opacity-50"
                        >
                          <Activity className="w-3.5 h-3.5" />
                          <span>{isTestingApi ? 'Testing...' : 'Run Live Test'}</span>
                        </button>
                      </div>

                      {testResult && (
                        <div className="mt-3 p-3 rounded-xl bg-slate-950 font-mono text-[11px] text-slate-300 max-h-48 overflow-y-auto">
                          <div className="flex items-center gap-2 mb-1">
                            <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${testResult.success ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'}`}>
                              STATUS {testResult.status || (testResult.success ? '200' : 'ERROR')}
                            </span>
                            <span className="text-slate-400">Response output:</span>
                          </div>
                          <pre className="whitespace-pre-wrap">{JSON.stringify(testResult.response || testResult, null, 2)}</pre>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Registered Custom UID Profiles */}
                  <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <ShieldCheck className="w-5 h-5 text-emerald-500" />
                        <h4 className="text-base font-extrabold text-slate-900 dark:text-white font-['Rajdhani']">
                          REGISTER REAL PLAYER PROFILES (100% ACCURACY)
                        </h4>
                      </div>
                      <span className="text-xs font-bold text-slate-500 dark:text-slate-400">
                        Total Custom Profiles: {profiles.length}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 dark:text-slate-300">
                      You can register any player UID with their exact in-game Nickname, Level, and Guild. When this UID is entered on the website, it instantly verifies with 100% accuracy — preventing any wrong data!
                    </p>

                    {profileMsg && (
                      <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 text-xs font-bold flex items-center gap-2">
                        <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
                        <span>{profileMsg}</span>
                      </div>
                    )}

                    {/* Add Profile Form */}
                    <form onSubmit={handleAddProfile} className="space-y-3 p-3.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                      <span className="text-xs font-bold text-slate-900 dark:text-white block">
                        + Add / Update Free Fire Player Profile
                      </span>
                      <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 text-xs">
                        <div className="sm:col-span-3">
                          <label className="text-[10px] font-bold text-slate-500 block mb-1">Player UID *</label>
                          <input
                            type="text"
                            required
                            value={newProfileUid}
                            onChange={(e) => setNewProfileUid(e.target.value.replace(/\D/g, ''))}
                            placeholder="e.g. 7061821092"
                            className="w-full h-9 px-3 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-mono font-bold"
                          />
                        </div>

                        <div className="sm:col-span-4">
                          <label className="text-[10px] font-bold text-slate-500 block mb-1">Exact In-Game Nickname (IGN) *</label>
                          <input
                            type="text"
                            required
                            value={newProfileName}
                            onChange={(e) => setNewProfileName(e.target.value)}
                            placeholder="e.g. VIVEK_GAMER, 『RAISTAR』"
                            className="w-full h-9 px-3 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                          />
                        </div>

                        <div className="sm:col-span-2">
                          <label className="text-[10px] font-bold text-slate-500 block mb-1">Level (1-100)</label>
                          <input
                            type="number"
                            min={1}
                            max={100}
                            value={newProfileLevel}
                            onChange={(e) => setNewProfileLevel(Number(e.target.value) || 1)}
                            className="w-full h-9 px-3 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                          />
                        </div>

                        <div className="sm:col-span-3">
                          <label className="text-[10px] font-bold text-slate-500 block mb-1">Guild Name</label>
                          <input
                            type="text"
                            value={newProfileGuild}
                            onChange={(e) => setNewProfileGuild(e.target.value)}
                            placeholder="e.g. TOTAL_GAMING"
                            className="w-full h-9 px-3 rounded-lg bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 font-bold"
                          />
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-1">
                        <label className="flex items-center gap-1.5 text-xs font-bold text-slate-600 dark:text-slate-400 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={newProfileVBadge}
                            onChange={(e) => setNewProfileVBadge(e.target.checked)}
                            className="rounded text-rose-500 focus:ring-rose-500"
                          />
                          <span>Verified V-Badge Influencer</span>
                        </label>

                        <button
                          type="submit"
                          className="px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-extrabold text-xs flex items-center gap-1.5 shadow-sm"
                        >
                          <Plus className="w-3.5 h-3.5" />
                          <span>Save & Register UID</span>
                        </button>
                      </div>
                    </form>

                    {/* Profiles Table */}
                    {profiles.length > 0 ? (
                      <div className="rounded-xl border border-slate-200 dark:border-slate-700 overflow-hidden">
                        <table className="w-full text-left text-xs">
                          <thead className="bg-slate-100 dark:bg-slate-800/80 text-[10px] font-bold uppercase text-slate-500 dark:text-slate-400">
                            <tr>
                              <th className="py-2.5 px-3">UID</th>
                              <th className="py-2.5 px-3">In-Game Nickname</th>
                              <th className="py-2.5 px-3">Level</th>
                              <th className="py-2.5 px-3">Rank</th>
                              <th className="py-2.5 px-3">Guild</th>
                              <th className="py-2.5 px-3 text-right">Action</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                            {profiles.map((p) => (
                              <tr key={p.uid} className="hover:bg-slate-100/50 dark:hover:bg-slate-800/40">
                                <td className="py-2 px-3 font-mono font-bold text-slate-900 dark:text-white">{p.uid}</td>
                                <td className="py-2 px-3 font-bold text-rose-500 flex items-center gap-1">
                                  {p.hasVBadge && <span className="px-1 rounded bg-amber-400 text-slate-950 text-[9px] font-black">V</span>}
                                  <span>{p.nickname}</span>
                                </td>
                                <td className="py-2 px-3">{p.level}</td>
                                <td className="py-2 px-3">{p.rank}</td>
                                <td className="py-2 px-3">{p.guild?.name || '—'}</td>
                                <td className="py-2 px-3 text-right">
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteProfile(p.uid)}
                                    className="text-[11px] font-bold text-rose-500 hover:underline"
                                  >
                                    Delete
                                  </button>
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ) : (
                      <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-900 text-center text-xs text-slate-500">
                        No custom profiles registered yet. Use the form above or let players enter their real names in the UI.
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* API Diagnostics & System Logs Tab */}
              {activeTab === 'diagnostics' && (
                <div className="space-y-4">
                  <h4 className="text-base font-extrabold text-slate-900 dark:text-white font-['Rajdhani']">
                    SYSTEM AUDIT TRAIL & FULFILLMENT LOGS
                  </h4>

                  <div className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-slate-950 p-4 font-mono text-xs text-slate-300 max-h-96 overflow-y-auto space-y-2">
                    {logs.map((log) => (
                      <div key={log.id} className="flex items-start gap-2 border-b border-slate-800/80 pb-1.5">
                        <span className="text-slate-500 text-[10px] whitespace-nowrap">
                          {new Date(log.timestamp).toLocaleTimeString()}
                        </span>
                        <span
                          className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase ${
                            log.category === 'security'
                              ? 'bg-rose-500/20 text-rose-400'
                              : log.category === 'fulfillment'
                              ? 'bg-emerald-500/20 text-emerald-400'
                              : 'bg-blue-500/20 text-blue-400'
                          }`}
                        >
                          {log.category}
                        </span>
                        <span className="text-slate-200">{log.message}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
