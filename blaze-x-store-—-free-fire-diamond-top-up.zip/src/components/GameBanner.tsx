import React from 'react';
import { ShieldCheck, CheckCircle2, Zap, Lock, Headphones, RefreshCw } from 'lucide-react';

export const GameBanner: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
      {/* Game Banner Header Card with Glass UI */}
      <div className="relative rounded-3xl overflow-hidden backdrop-blur-xl bg-white/75 dark:bg-slate-900/75 border border-white/80 dark:border-white/10 shadow-[0_8px_32px_0_rgba(31,38,135,0.06)] p-4 sm:p-6 transition-all">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-6">
          {/* Game Title & Badges */}
          <div className="flex items-center gap-4 w-full lg:w-auto">
            {/* Free Fire icon thumbnail */}
            <div className="relative w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden bg-slate-900 flex-shrink-0 shadow-lg border-2 border-white dark:border-slate-800">
              <img
                src="https://play-lh.googleusercontent.com/M_l-dWl4q9FLX3IgYu8lrSPAs6WrMiL2gPxzYwehWAsfFpOVOSG-APyLkUkJn8Og_uHXw_qv5K351Dyy4pmqoQ=s384"
                alt="Garena Free Fire MAX"
                className="w-full h-full object-cover"
                onError={(e) => {
                  (e.currentTarget as HTMLImageElement).src =
                    'https://freefireinfo.in/images/avatars/902045006.png';
                }}
              />
              <div className="absolute top-1 left-1 bg-red-600 text-[8px] font-black text-white px-1.5 py-0.5 rounded shadow uppercase">
                HOT
              </div>
              <div className="absolute bottom-0 right-0 bg-gradient-to-l from-rose-600 to-amber-500 text-[9px] font-black text-white px-1.5 py-0.5 rounded-tl shadow">
                MAX
              </div>
            </div>

            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-xl sm:text-2xl font-extrabold text-slate-900 dark:text-white font-['Rajdhani']">
                  GARENA FREE FIRE & FREE FIRE MAX
                </h2>
                <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-50/80 backdrop-blur-sm dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200/80 dark:border-emerald-800">
                  <CheckCircle2 className="w-3 h-3" />
                  Official Top-Up Partner
                </span>
              </div>
              <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
                Direct in-game diamond delivery via Player UID • Instant top-up within seconds • 100% Ban-Safe guarantee
              </p>
            </div>
          </div>

          {/* Secure Information Badges with Glass UI */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 w-full lg:w-auto">
            <div className="flex items-center gap-2 p-2.5 rounded-xl backdrop-blur-md bg-white/60 dark:bg-slate-800/60 border border-white/80 dark:border-white/10 shadow-sm">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 text-emerald-500 flex items-center justify-center flex-shrink-0">
                <Lock className="w-4 h-4" />
              </div>
              <div className="text-left">
                <p className="text-[11px] font-bold text-slate-800 dark:text-slate-200">UID Only</p>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">No Login Needed</p>
              </div>
            </div>

            <div className="flex items-center gap-2 p-2.5 rounded-xl backdrop-blur-md bg-white/60 dark:bg-slate-800/60 border border-white/80 dark:border-white/10 shadow-sm">
              <div className="w-8 h-8 rounded-lg bg-rose-500/10 text-rose-500 flex items-center justify-center flex-shrink-0">
                <Zap className="w-4 h-4" />
              </div>
              <div className="text-left">
                <p className="text-[11px] font-bold text-slate-800 dark:text-slate-200">Express Delivery</p>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">Direct In-Game</p>
              </div>
            </div>

            <div className="flex items-center gap-2 p-2.5 rounded-xl backdrop-blur-md bg-white/60 dark:bg-slate-800/60 border border-white/80 dark:border-white/10 shadow-sm">
              <div className="w-8 h-8 rounded-lg bg-blue-500/10 text-blue-500 flex items-center justify-center flex-shrink-0">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <div className="text-left">
                <p className="text-[11px] font-bold text-slate-800 dark:text-slate-200">256-Bit SSL</p>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">Encrypted Pay</p>
              </div>
            </div>

            <div className="flex items-center gap-2 p-2.5 rounded-xl backdrop-blur-md bg-white/60 dark:bg-slate-800/60 border border-white/80 dark:border-white/10 shadow-sm">
              <div className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-500 flex items-center justify-center flex-shrink-0">
                <Headphones className="w-4 h-4" />
              </div>
              <div className="text-left">
                <p className="text-[11px] font-bold text-slate-800 dark:text-slate-200">24/7 Support</p>
                <p className="text-[10px] text-slate-500 dark:text-slate-400">Always Online</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
