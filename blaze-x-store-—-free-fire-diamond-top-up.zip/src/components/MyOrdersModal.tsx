import React, { useState, useEffect } from 'react';
import { Order, PlayerProfile } from '../types/index.ts';
import {
  PackageCheck,
  X,
  CheckCircle2,
  Clock,
  Sparkles,
  Copy,
  Check,
  CreditCard,
  Flame,
  ArrowRight,
  ShieldCheck,
  Loader2,
} from 'lucide-react';

interface MyOrdersModalProps {
  isOpen: boolean;
  onClose: () => void;
  profile: PlayerProfile;
  sessionOrders?: Order[];
  onSelectPackage?: () => void;
}

export const MyOrdersModal: React.FC<MyOrdersModalProps> = ({
  isOpen,
  onClose,
  profile,
  sessionOrders = [],
  onSelectPackage,
}) => {
  const [orders, setOrders] = useState<Order[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Automatically fetch orders for this verified player's UID without asking them to search
  useEffect(() => {
    if (!isOpen) return;

    const loadOrders = async () => {
      setIsLoading(true);
      try {
        const res = await fetch(`/api/orders/search/lookup?q=${encodeURIComponent(profile.uid)}`);
        const data = await res.json();

        const serverOrders: Order[] = data.orders || [];

        // Combine server orders with any in-memory / session orders (avoiding duplicates)
        const combined = [...sessionOrders];
        for (const so of serverOrders) {
          if (!combined.some((o) => o.id === so.id)) {
            combined.push(so);
          }
        }

        // Sort latest first
        combined.sort(
          (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );

        setOrders(combined);
      } catch (err) {
        // Fallback to session orders if network drops
        setOrders(sessionOrders);
      } finally {
        setIsLoading(false);
      }
    };

    loadOrders();
  }, [isOpen, profile.uid, sessionOrders]);

  if (!isOpen) return null;

  const handleCopy = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm animate-fade-in select-none"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl max-w-xl w-full max-h-[85vh] overflow-y-auto shadow-2xl border border-slate-100 flex flex-col animate-scale-up"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 bg-white/95 backdrop-blur-md px-6 py-4 border-b border-slate-100 flex items-center justify-between z-10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-rose-500 to-orange-500 flex items-center justify-center text-white shadow-md shadow-rose-500/20">
              <PackageCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xl font-extrabold text-slate-900 font-['Rajdhani'] leading-tight">
                MY ORDERS
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                Purchases for <span className="font-bold text-slate-800">{profile.nickname}</span> (UID: {profile.uid})
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-500 hover:text-slate-800 flex items-center justify-center transition-colors cursor-pointer"
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 space-y-4">
          {isLoading ? (
            <div className="py-12 flex flex-col items-center justify-center text-slate-400 gap-3">
              <Loader2 className="w-8 h-8 animate-spin text-rose-500" />
              <span className="text-xs font-bold text-slate-500">Loading your orders…</span>
            </div>
          ) : orders.length > 0 ? (
            <div className="space-y-4">
              {orders.map((order) => {
                const isDelivered = order.status === 'delivered';
                const isFailed = order.status === 'failed';

                return (
                  <div
                    key={order.id}
                    className="p-5 rounded-2xl bg-white border border-slate-200/90 shadow-sm hover:shadow-md transition-shadow space-y-3"
                  >
                    {/* Top Row: Order ID & Status Badge */}
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-slate-800">
                          {order.id}
                        </span>
                        <button
                          type="button"
                          onClick={() => handleCopy(order.id)}
                          className="p-1 rounded text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                          title="Copy Order ID"
                        >
                          {copiedId === order.id ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>

                      <span
                        className={`inline-flex items-center gap-1 px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider ${
                          isDelivered
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                            : isFailed
                            ? 'bg-rose-50 text-rose-700 border border-rose-200'
                            : 'bg-amber-50 text-amber-700 border border-amber-200'
                        }`}
                      >
                        {isDelivered ? (
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Clock className="w-3.5 h-3.5 text-amber-600" />
                        )}
                        <span>{order.status}</span>
                      </span>
                    </div>

                    {/* Diamond Amount & Price Highlight */}
                    <div className="flex items-center justify-between p-3.5 rounded-xl bg-gradient-to-r from-rose-50/60 to-orange-50/60 border border-rose-100">
                      <div className="flex items-center gap-2.5">
                        <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-rose-500 to-orange-500 flex items-center justify-center text-white text-base font-black shadow-sm">
                          💎
                        </div>
                        <div>
                          <div className="text-lg font-black text-rose-600 font-['Rajdhani'] leading-none">
                            {order.diamonds.toLocaleString()} Diamonds
                          </div>
                          {order.bonusDiamonds ? (
                            <div className="text-[11px] font-bold text-emerald-600">
                              +{order.bonusDiamonds.toLocaleString()} Free Bonus Diamonds
                            </div>
                          ) : null}
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-xl font-black text-slate-900 font-['Rajdhani'] leading-none">
                          ₹{order.amountINR}
                        </div>
                        <div className="text-[10px] font-bold text-slate-400 uppercase mt-0.5">
                          Paid
                        </div>
                      </div>
                    </div>

                    {/* Metadata Details */}
                    <div className="grid grid-cols-2 gap-2 text-xs text-slate-500 pt-1">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-400 block">
                          Player / Account
                        </span>
                        <span className="font-bold text-slate-800">{order.nickname}</span>
                      </div>

                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-400 block">
                          Payment Mode
                        </span>
                        <span className="font-bold text-slate-800">
                          {order.paymentMethod || 'UPI Payment'}
                        </span>
                      </div>

                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-400 block">
                          Date & Time
                        </span>
                        <span className="font-medium text-slate-700">
                          {new Date(order.createdAt).toLocaleString('en-IN', {
                            dateStyle: 'medium',
                            timeStyle: 'short',
                          })}
                        </span>
                      </div>

                      {order.fulfillmentTxId && (
                        <div>
                          <span className="text-[10px] uppercase font-bold text-slate-400 block">
                            Server Txn ID
                          </span>
                          <span className="font-mono text-[11px] font-bold text-slate-700 truncate block">
                            {order.fulfillmentTxId}
                          </span>
                        </div>
                      )}
                    </div>

                    {/* Delivery Status Message */}
                    <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-semibold bg-emerald-50/70 p-2.5 rounded-xl border border-emerald-100">
                      <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                      <span>{order.statusMessage || 'Diamond top-up credited to Free Fire account'}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            /* Empty State */
            <div className="py-12 px-4 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mx-auto">
                <Flame className="w-8 h-8" />
              </div>

              <div>
                <h4 className="text-lg font-black text-slate-900 font-['Rajdhani']">
                  NO ORDERS YET FOR THIS UID
                </h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 leading-relaxed">
                  You haven&apos;t placed any diamond top-up order for UID{' '}
                  <strong className="font-mono font-bold text-slate-800">{profile.uid}</strong> yet.
                  Select a diamond package below to make your instant top-up!
                </p>
              </div>

              <button
                type="button"
                onClick={() => {
                  onClose();
                  onSelectPackage?.();
                }}
                className="px-6 py-3 rounded-full bg-gradient-to-r from-rose-500 via-rose-600 to-orange-500 text-white font-extrabold text-xs shadow-lg shadow-rose-500/25 hover:shadow-rose-500/40 transition-all inline-flex items-center gap-1.5 cursor-pointer"
              >
                <span>Browse Diamond Packages</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
