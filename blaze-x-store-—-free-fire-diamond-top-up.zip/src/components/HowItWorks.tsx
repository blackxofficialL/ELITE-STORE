import React from 'react';
import { UserCheck, Sparkles, ShieldCheck, Zap, ArrowRight } from 'lucide-react';

export const HowItWorks: React.FC = () => {
  const steps = [
    {
      step: '01',
      title: 'Enter & Verify UID',
      description: 'Enter your 8-12 digit numeric Free Fire Player ID and server region to verify your in-game nickname.',
      icon: <UserCheck className="w-6 h-6 text-rose-500" />,
      color: 'from-rose-500/10 to-orange-500/10 border-rose-200 dark:border-rose-900/50',
    },
    {
      step: '02',
      title: 'Pick a Pack',
      description: 'Select your preferred diamond bundle (100 to 5600 diamonds) or weekly/monthly VIP membership passes.',
      icon: <Sparkles className="w-6 h-6 text-amber-500" />,
      color: 'from-amber-500/10 to-rose-500/10 border-amber-200 dark:border-amber-900/50',
    },
    {
      step: '03',
      title: 'Pay Securely',
      description: 'Pay safely with zero extra fees using UPI (GPay, PhonePe, Paytm), Debit/Credit Cards, or NetBanking.',
      icon: <ShieldCheck className="w-6 h-6 text-emerald-500" />,
      color: 'from-emerald-500/10 to-teal-500/10 border-emerald-200 dark:border-emerald-900/50',
    },
    {
      step: '04',
      title: 'Get Your Diamonds',
      description: 'Diamonds are dispatched directly to your Free Fire in-game mailbox in real-time with an official transaction reference.',
      icon: <Zap className="w-6 h-6 text-sky-500" />,
      color: 'from-sky-500/10 to-indigo-500/10 border-sky-200 dark:border-sky-900/50',
    },
  ];

  return (
    <div id="how-it-works" className="w-full py-8">
      <div className="text-center max-w-2xl mx-auto mb-8 space-y-2">
        <span className="text-xs font-extrabold uppercase tracking-widest text-rose-500 bg-rose-50 dark:bg-rose-950/60 px-3 py-1 rounded-full border border-rose-200 dark:border-rose-900/40">
          EFFORTLESS 4-STEP PROCESS
        </span>
        <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 dark:text-white font-['Rajdhani']">
          HOW ELITE STORE WORKS
        </h3>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">
          Fastest, most secure top-up service in the region. Zero passwords, zero wait time.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {steps.map((item, idx) => (
          <div
            key={idx}
            className="relative rounded-3xl p-6 backdrop-blur-xl bg-white/70 dark:bg-slate-900/70 border border-white/80 dark:border-white/10 shadow-[0_8px_32px_0_rgba(31,38,135,0.06)] hover:shadow-[0_12px_40px_0_rgba(255,19,83,0.12)] hover:border-rose-300/60 transition-all duration-300 group hover:-translate-y-1 overflow-hidden"
          >
            {/* Subtle frosted glass color glow corner */}
            <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${item.color} rounded-bl-full opacity-40 group-hover:opacity-70 transition-opacity pointer-events-none`} />

            <div className="flex items-center justify-between mb-4 relative z-10">
              <div className="w-12 h-12 rounded-2xl backdrop-blur-md bg-white/80 dark:bg-slate-800/80 border border-white/90 dark:border-white/15 flex items-center justify-center shadow-sm group-hover:scale-105 transition-transform">
                {item.icon}
              </div>
              <span className="font-['Rajdhani'] font-extrabold text-2xl text-slate-300 dark:text-slate-700">
                {item.step}
              </span>
            </div>

            <h4 className="text-lg font-extrabold text-slate-900 dark:text-white font-['Rajdhani'] mb-1 relative z-10">
              {item.title}
            </h4>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed relative z-10">
              {item.description}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};
