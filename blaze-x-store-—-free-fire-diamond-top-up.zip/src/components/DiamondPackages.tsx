import React from 'react';
import { DiamondPackage, PlayerProfile } from '../types/index.ts';
import { DiamondChestGraphic } from './DiamondChestGraphic.tsx';

interface DiamondPackagesProps {
  packages: DiamondPackage[];
  verifiedProfile: PlayerProfile | null;
  selectedPackage: DiamondPackage | null;
  onSelectPackage: (pkg: DiamondPackage) => void;
  onPromptVerifyUid: () => void;
}

export const DiamondPackages: React.FC<DiamondPackagesProps> = ({
  packages,
  verifiedProfile,
  selectedPackage,
  onSelectPackage,
  onPromptVerifyUid,
}) => {
  const getBadgeStyle = (badge?: string) => {
    switch (badge?.toUpperCase()) {
      case 'BASIC':
      case 'CLASSIC':
      case 'GOLD':
        return 'bg-[#00b894] text-white';
      case 'PLATINUM':
      case 'PRO TIER':
        return 'bg-[#ff2e63] text-white';
      case '👑 KING':
      case 'KING':
      case 'VIP PASS':
        return 'bg-[#ff9f43] text-white';
      default:
        return 'bg-[#00b894] text-white';
    }
  };

  return (
    <div id="top-up-section" className="w-full space-y-6 select-none">
      {/* 3-Column Diamond Packages Grid matching Image 2 */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {packages.map((pkg, index) => {
          const isSelected = selectedPackage?.id === pkg.id;
          const badgeText = pkg.badge || (pkg.diamonds >= 50000 ? '👑 KING' : pkg.diamonds >= 18000 ? 'PLATINUM' : 'BASIC');

          return (
            <div
              key={pkg.id}
              onClick={() => {
                if (!verifiedProfile) {
                  onPromptVerifyUid();
                } else {
                  onSelectPackage(pkg);
                }
              }}
              className={`relative rounded-3xl p-6 bg-white border cursor-pointer transition-all duration-300 flex flex-col justify-between group ${
                isSelected
                  ? 'border-rose-500 ring-2 ring-rose-500 shadow-xl'
                  : 'border-slate-100 shadow-sm hover:shadow-xl hover:-translate-y-1'
              }`}
            >
              {/* Badge in Top-Right */}
              <div className="flex justify-end">
                <span
                  className={`text-[11px] font-black px-3.5 py-1 rounded-full uppercase tracking-wider shadow-sm ${getBadgeStyle(
                    badgeText
                  )}`}
                >
                  {badgeText}
                </span>
              </div>

              {/* 3D Diamond Graphic: Loaded from /public/diamonds/diamond{1..6}.png */}
              <div className="py-2 flex items-center justify-center min-h-[112px] relative">
                <img
                  src={`/diamonds/diamond${index + 1}.png`}
                  alt={`${pkg.diamonds} Diamonds`}
                  className="w-40 h-28 object-contain mx-auto group-hover:scale-105 transition-transform duration-300"
                  onError={(e) => {
                    // Fallback to SVG chest graphic if image fails to load
                    (e.currentTarget as HTMLImageElement).style.display = 'none';
                    const fallback = e.currentTarget.parentElement?.querySelector('.diamond-svg-fallback');
                    if (fallback) (fallback as HTMLElement).style.display = 'block';
                  }}
                />
                <div className="diamond-svg-fallback hidden w-full">
                  <DiamondChestGraphic className="w-40 h-28 mx-auto group-hover:scale-105 transition-transform duration-300" />
                </div>
              </div>

              {/* Package Details */}
              <div className="pt-2">
                {/* Big Bold Red Diamond Amount */}
                <div className="text-3xl font-black text-[#ff2442] font-['Rajdhani'] leading-none">
                  {pkg.diamonds.toLocaleString()}
                </div>

                {/* Subtitle */}
                <div className="font-bold text-slate-900 text-sm mt-1">
                  {pkg.diamonds.toLocaleString()} Diamonds
                </div>

                {/* Delivery Note */}
                <div className="text-xs text-slate-400 mt-0.5">
                  Instant delivery
                </div>
              </div>

              {/* Bottom Row: Price & Buy Link */}
              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <div className="text-2xl font-black text-slate-900 font-['Rajdhani']">
                  ₹{pkg.priceINR}
                </div>

                <button
                  type="button"
                  className="text-[#ff2442] font-bold text-sm group-hover:underline flex items-center gap-1 group-hover:translate-x-1 transition-transform"
                >
                  <span>Buy</span>
                  <span className="text-base font-bold">→</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
