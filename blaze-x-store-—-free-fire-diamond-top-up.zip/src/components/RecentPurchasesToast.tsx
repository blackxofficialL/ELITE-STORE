import React, { useState, useEffect, useRef } from 'react';
import { CheckCircle2, X } from 'lucide-react';

interface RecentPurchasesToastProps {
  enabled: boolean;
  onDisable: () => void;
}

interface ToastNotification {
  id: string;
  maskedUid: string;
  diamonds: number;
  timeAgo: string;
}

// Indian Free Fire server UID prefixes
const FF_INDIAN_UID_PREFIXES = [
  '1106', '1202', '1492', '1829', '2067', '2481', '2849', '3104', '3491', '3914',
  '4205', '4510', '4829', '5129', '5482', '5928', '6048', '6419', '6739', '7039',
  '7581', '7930', '8192', '8642', '8810', '9028', '9481', '9720', '9912', '1038',
  '1357', '2194', '2678', '3482', '4193', '5201', '5814', '6394', '7125', '8302',
  '8914', '9154', '9542', '1683', '2391', '3847', '4952', '6173', '7482', '8591',
];

const STORE_DIAMOND_PACKS = [
  8000,
  12000,
  18000,
  25000,
  35000,
  50000,
];

export const RecentPurchasesToast: React.FC<RecentPurchasesToastProps> = ({ enabled }) => {
  const [currentToast, setCurrentToast] = useState<ToastNotification | null>(null);
  const [visible, setVisible] = useState(false);

  // Set of all UIDs shown in this session so no UID ever repeats
  const usedUids = useRef<Set<string>>(new Set());

  // Function to generate a completely new, unique realistic Indian Free Fire UID
  const generateUniqueOrder = (): ToastNotification => {
    let attempts = 0;
    let masked = '';

    while (attempts < 100) {
      attempts++;
      const p = FF_INDIAN_UID_PREFIXES[Math.floor(Math.random() * FF_INDIAN_UID_PREFIXES.length)];
      // Generate realistic middle and suffix digits
      const mid = Math.floor(1000 + Math.random() * 9000);
      const suf = Math.floor(1000 + Math.random() * 9000);
      const fullUid = `${p}${mid}${suf}`;
      masked = `${fullUid.slice(0, 4)}****${fullUid.slice(-4)}`;

      if (!usedUids.current.has(masked)) {
        usedUids.current.add(masked);
        break;
      }
    }

    const diamonds = STORE_DIAMOND_PACKS[Math.floor(Math.random() * STORE_DIAMOND_PACKS.length)];
    const seconds = Math.floor(4 + Math.random() * 45);

    return {
      id: `toast-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      maskedUid: masked,
      diamonds,
      timeAgo: `${seconds}s ago`,
    };
  };

  useEffect(() => {
    if (!enabled) {
      setVisible(false);
      return;
    }

    // Initial show after 2.5 seconds
    const initialTimer = setTimeout(() => {
      const first = generateUniqueOrder();
      setCurrentToast(first);
      setVisible(true);

      // Hide after 4 seconds
      setTimeout(() => {
        setVisible(false);
      }, 4000);
    }, 2500);

    // Then show a brand-new non-repeating order every 8 seconds
    const cycleTimer = setInterval(() => {
      const nextOrder = generateUniqueOrder();
      setCurrentToast(nextOrder);
      setVisible(true);

      setTimeout(() => {
        setVisible(false);
      }, 4200);
    }, 8000);

    return () => {
      clearTimeout(initialTimer);
      clearInterval(cycleTimer);
    };
  }, [enabled]);

  if (!enabled || !currentToast || !visible) return null;

  return (
    <div className="fixed bottom-5 left-5 z-40 max-w-sm transition-all duration-500 ease-out animate-slide-up select-none">
      {/* Frosted Glass UI Container */}
      <div className="flex items-center gap-3 p-3.5 rounded-2xl backdrop-blur-xl bg-white/80 dark:bg-slate-900/80 border border-white/90 dark:border-white/10 shadow-[0_8px_32px_0_rgba(31,38,135,0.12)]">
        {/* Diamond Icon */}
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-rose-500/15 to-orange-500/15 border border-rose-500/30 flex items-center justify-center text-lg flex-shrink-0 shadow-sm">
          💎
        </div>

        <div className="flex-1 min-w-0 pr-1">
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs font-black text-slate-900 dark:text-white font-mono tracking-wide">
              UID {currentToast.maskedUid}
            </span>
            <span className="text-[10px] text-emerald-600 dark:text-emerald-400 font-extrabold flex items-center gap-0.5 bg-emerald-50 dark:bg-emerald-950/60 px-1.5 py-0.2 rounded-full border border-emerald-200/60 dark:border-emerald-800">
              <CheckCircle2 className="w-3 h-3 text-emerald-600" />
              Delivered
            </span>
          </div>

          <div className="flex items-center justify-between mt-0.5">
            <p className="text-[11px] text-slate-600 dark:text-slate-300 truncate">
              Bought <strong className="text-rose-600 dark:text-rose-400 font-black">{currentToast.diamonds.toLocaleString()} Diamonds</strong>
            </p>
            <span className="text-[10px] text-slate-400 font-medium ml-2 flex-shrink-0">
              {currentToast.timeAgo}
            </span>
          </div>
        </div>

        <button
          onClick={() => setVisible(false)}
          className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 transition-colors cursor-pointer"
          title="Dismiss"
          aria-label="Dismiss notification"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
