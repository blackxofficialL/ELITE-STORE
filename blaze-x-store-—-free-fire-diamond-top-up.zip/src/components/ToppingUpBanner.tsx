import React from 'react';
import { Check, User, Package, ChevronRight, Phone } from 'lucide-react';
import { PlayerProfile } from '../types/index.ts';

interface ToppingUpBannerProps {
  profile: PlayerProfile;
  onChangeAccount: () => void;
  onOpenOrders?: () => void;
  onCallAdmin?: () => void;
  orderCount?: number;
}

export const ToppingUpBanner: React.FC<ToppingUpBannerProps> = ({
  profile,
  onChangeAccount,
  onOpenOrders,
  onCallAdmin,
  orderCount = 1,
}) => {
  return (
    <div className="w-full space-y-3 animate-fade-in select-none">
      {/* Main Topping Up Card */}
      <div className="w-full bg-white rounded-3xl p-4 sm:p-5 border border-slate-100 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        {/* Left: Avatar + Details */}
        <div className="flex items-center gap-3.5">
          {/* Avatar with HOT and Free Fire badge */}
          <div className="relative w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-gradient-to-tr from-slate-950 to-slate-800 p-0.5 flex-shrink-0 shadow-md">
            <div className="w-full h-full rounded-[14px] overflow-hidden flex items-center justify-center bg-slate-900 relative">
              {profile.avatarUrl ? (
                <img
                  src={profile.avatarUrl}
                  alt={profile.nickname}
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src =
                      'https://play-lh.googleusercontent.com/M_l-dWl4q9FLX3IgYu8lrSPAs6WrMiL2gPxzYwehWAsfFpOVOSG-APyLkUkJn8Og_uHXw_qv5K351Dyy4pmqoQ=s384';
                  }}
                />
              ) : (
                <img
                  src="https://play-lh.googleusercontent.com/M_l-dWl4q9FLX3IgYu8lrSPAs6WrMiL2gPxzYwehWAsfFpOVOSG-APyLkUkJn8Og_uHXw_qv5K351Dyy4pmqoQ=s384"
                  alt="Player"
                  className="w-full h-full object-cover"
                />
              )}

              {/* HOT Tag */}
              <div className="absolute top-0.5 left-0.5 bg-red-600 text-white font-black text-[8px] px-1 py-0.2 rounded shadow uppercase">
                HOT
              </div>

              {/* Flame Icon */}
              <div className="absolute bottom-0.5 right-0.5 w-4 h-4 rounded-full bg-white flex items-center justify-center shadow text-[8px]">
                🔥
              </div>
            </div>
          </div>

          {/* Details */}
          <div className="space-y-0.5">
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
              TOPPING UP FOR
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <span className="text-xl sm:text-2xl font-black text-slate-900 font-['Rajdhani'] leading-tight">
                {profile.nickname}
              </span>

              {/* Verified Pill Badge */}
              <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-full text-[11px] font-extrabold bg-[#e6fbf2] text-[#059669] border border-[#a7f3d0]">
                <Check className="w-3 h-3 stroke-[3]" />
                Verified
              </span>
            </div>

            <div className="text-xs text-slate-500 font-medium flex items-center gap-2">
              <span>
                UID <strong className="font-mono text-slate-800 font-bold">{profile.uid}</strong>
              </span>
              <span>•</span>
              <span>Lvl {profile.level || 55}</span>
            </div>
          </div>
        </div>

        {/* Right: Call Admin & Change Account Buttons */}
        <div className="flex items-center gap-2">
          {onCallAdmin && (
            <button
              type="button"
              onClick={onCallAdmin}
              className="px-3.5 py-2 rounded-full bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs transition-all shadow-sm flex items-center gap-1.5 cursor-pointer"
            >
              <Phone className="w-3.5 h-3.5 text-white animate-bounce" />
              <span>Call Admin</span>
            </button>
          )}

          <button
            type="button"
            onClick={onChangeAccount}
            className="px-3.5 py-2 rounded-full border border-rose-200 text-rose-500 hover:bg-rose-50 hover:border-rose-300 font-bold text-xs transition-all shadow-sm cursor-pointer whitespace-nowrap"
          >
            Change account
          </button>
        </div>
      </div>

      {/* My Orders Strip */}
      <div
        onClick={onOpenOrders}
        className="w-full bg-[#fff7f5] hover:bg-[#fff2ee] border border-rose-100/80 rounded-2xl p-3.5 px-5 flex items-center justify-between text-xs font-bold text-slate-800 transition-all cursor-pointer shadow-sm group"
      >
        <div className="flex items-center gap-2">
          <span className="text-sm">📦</span>
          <span className="font-extrabold font-['Rajdhani'] text-sm tracking-wide text-slate-900">
            My Orders ({orderCount})
          </span>
        </div>
        <div className="text-rose-500 group-hover:translate-x-1 transition-transform">
          <ChevronRight className="w-4 h-4" />
        </div>
      </div>
    </div>
  );
};
