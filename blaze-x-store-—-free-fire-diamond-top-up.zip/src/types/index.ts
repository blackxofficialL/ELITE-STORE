export type RegionCode = 'IND' | 'SG' | 'BD' | 'BR' | 'ID' | 'ME' | 'EU' | 'NA';

export interface RegionInfo {
  code: RegionCode;
  name: string;
  flag: string;
  currency: string;
}

export interface PlayerProfile {
  uid: string;
  region: RegionCode;
  nickname: string;
  level: number;
  exp?: number;
  likes?: number;
  rank?: string;
  rankScore?: number;
  csRank?: string;
  guild?: {
    name: string;
    level: number;
  };
  signature?: string;
  hasVBadge?: boolean;
  avatarId?: number;
  headPic?: number;
  bannerId?: number;
  avatarUrl?: string;
  bannerUrl?: string;
  badge?: string;
  verifiedAt?: string;
  provider:
    | 'official'
    | 'coda'
    | 'smile'
    | 'india_server_api'
    | 'info_vercel_api'
    | 'demo_verified'
    | 'registered_profile'
    | 'verified_known_database'
    | 'user_verified_profile'
    | 'freefireinfo_import'
    | 'external_api'
    | 'admin_registered'
    | string;
}

export interface DiamondPackage {
  id: string;
  diamonds: number;
  bonus: number;
  priceINR: number;
  originalPriceINR: number;
  badge?: string;
  popular?: boolean;
  type: 'diamonds' | 'membership';
  period?: string;
  description?: string;
  icon?: string;
  active: boolean;
}

export type OrderStatus =
  | 'pending_payment'
  | 'payment_successful'
  | 'processing'
  | 'delivered'
  | 'failed'
  | 'refund_pending'
  | 'refunded';

export interface Order {
  id: string;
  uid: string;
  nickname: string;
  region: RegionCode;
  packageId: string;
  diamonds: number;
  bonusDiamonds: number;
  amountINR: number;
  paymentMethod?: string;
  paymentId?: string;
  paymentSignature?: string;
  status: OrderStatus;
  statusMessage?: string;
  fulfillmentTxId?: string;
  utrNumber?: string;
  screenshotUrl?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PublicRecentOrder {
  id: string;
  maskedUid: string;
  diamonds: number;
  createdAt: string;
  status: OrderStatus;
}

export interface SystemConfigStatus {
  lookupProvider: {
    name: string;
    configured: boolean;
    demoModeActive: boolean;
    status: 'operational' | 'degraded' | 'unconfigured';
    message: string;
  };
  paymentGateway: {
    provider: string;
    configured: boolean;
    sandboxActive: boolean;
    keyIdPreview?: string;
  };
  fulfillment: {
    provider: string;
    configured: boolean;
    mode: 'auto_queue' | 'supplier_api';
  };
}
