import type { OrderStatus } from '../types/index.ts';

const VALID_TRANSITIONS: Record<OrderStatus, OrderStatus[]> = {
  pending_payment: ['payment_successful', 'failed'],
  payment_successful: ['processing', 'failed', 'refund_pending'],
  processing: ['delivered', 'failed', 'refund_pending'],
  delivered: [],
  failed: ['processing', 'refund_pending'],
  refund_pending: ['refunded', 'failed'],
  refunded: [],
};

export function canTransition(current: OrderStatus, next: OrderStatus): boolean {
  if (current === next) return true;
  const allowed = VALID_TRANSITIONS[current] || [];
  return allowed.includes(next);
}

/**
 * Anonymizes player UID for GDPR / public notifications
 * e.g., "1982736452" -> "198****52"
 */
export function maskPlayerUid(uid: string): string {
  if (!uid || uid.length < 5) return '***';
  const first = uid.slice(0, 3);
  const last = uid.slice(-2);
  return `${first}****${last}`;
}

export function getStatusBadgeInfo(status: OrderStatus): {
  label: string;
  colorClass: string;
  description: string;
} {
  switch (status) {
    case 'pending_payment':
      return {
        label: 'Awaiting Payment',
        colorClass: 'bg-amber-500/10 text-amber-500 border-amber-500/20',
        description: 'Waiting for payment confirmation from bank or UPI',
      };
    case 'payment_successful':
      return {
        label: 'Paid',
        colorClass: 'bg-blue-500/10 text-blue-500 border-blue-500/20',
        description: 'Payment verified and confirmed by payment gateway',
      };
    case 'processing':
      return {
        label: 'Processing Top-up',
        colorClass: 'bg-purple-500/10 text-purple-500 border-purple-500/20',
        description: 'Diamond top-up instruction dispatched to Free Fire game server',
      };
    case 'delivered':
      return {
        label: 'Delivered',
        colorClass: 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
        description: 'Diamonds credited successfully to your in-game Free Fire mailbox',
      };
    case 'failed':
      return {
        label: 'Failed',
        colorClass: 'bg-rose-500/10 text-rose-500 border-rose-500/20',
        description: 'Top-up encountered an issue and has been escalated to support',
      };
    case 'refund_pending':
      return {
        label: 'Refund In Progress',
        colorClass: 'bg-orange-500/10 text-orange-500 border-orange-500/20',
        description: 'Refund initiated back to original payment method',
      };
    case 'refunded':
      return {
        label: 'Refunded',
        colorClass: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
        description: 'Amount successfully refunded to customer source account',
      };
    default:
      return {
        label: status,
        colorClass: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
        description: '',
      };
  }
}
