import type { DiamondPackage } from '../types/index.ts';

export const INITIAL_PACKAGES: DiamondPackage[] = [
  {
    id: 'pack-8000',
    diamonds: 8000,
    bonus: 800,
    priceINR: 999,
    originalPriceINR: 1299,
    badge: 'BASIC',
    popular: false,
    type: 'diamonds',
    description: 'Instant delivery',
    active: true,
  },
  {
    id: 'pack-12000',
    diamonds: 12000,
    bonus: 1200,
    priceINR: 1299,
    originalPriceINR: 1699,
    badge: 'CLASSIC',
    popular: true,
    type: 'diamonds',
    description: 'Instant delivery',
    active: true,
  },
  {
    id: 'pack-18000',
    diamonds: 18000,
    bonus: 1800,
    priceINR: 1599,
    originalPriceINR: 2099,
    badge: 'PLATINUM',
    popular: false,
    type: 'diamonds',
    description: 'Instant delivery',
    active: true,
  },
  {
    id: 'pack-25000',
    diamonds: 25000,
    bonus: 2500,
    priceINR: 1999,
    originalPriceINR: 2599,
    badge: 'GOLD',
    popular: false,
    type: 'diamonds',
    description: 'Instant delivery',
    active: true,
  },
  {
    id: 'pack-35000',
    diamonds: 35000,
    bonus: 3500,
    priceINR: 2599,
    originalPriceINR: 3399,
    badge: 'PLATINUM',
    popular: false,
    type: 'diamonds',
    description: 'Instant delivery',
    active: true,
  },
  {
    id: 'pack-50000',
    diamonds: 50000,
    bonus: 5000,
    priceINR: 3499,
    originalPriceINR: 4999,
    badge: '👑 KING',
    popular: true,
    type: 'diamonds',
    description: 'Instant delivery',
    active: true,
  },
];

export interface OrderPricingResult {
  valid: boolean;
  package?: DiamondPackage;
  subtotal: number;
  discount: number;
  convenienceFee: number;
  totalPayableINR: number;
  error?: string;
}

/**
 * Calculates authoritative pricing on the backend
 */
export function calculateOrderPricing(
  packageId: string,
  availablePackages: DiamondPackage[]
): OrderPricingResult {
  const selected = availablePackages.find((p) => p.id === packageId && p.active);
  if (!selected) {
    return {
      valid: false,
      subtotal: 0,
      discount: 0,
      convenienceFee: 0,
      totalPayableINR: 0,
      error: 'Requested diamond package is invalid or currently inactive',
    };
  }

  const subtotal = selected.originalPriceINR;
  const totalPayableINR = selected.priceINR;
  const discount = Math.max(0, subtotal - totalPayableINR);
  const convenienceFee = 0; // ₹0 gateway surcharge guarantee

  return {
    valid: true,
    package: selected,
    subtotal,
    discount,
    convenienceFee,
    totalPayableINR,
  };
}

/**
 * Generates unique ELITE STORE Order ID
 * Format: ES-YYYYMMDD-XXXX
 */
export function generateOrderId(prefix = 'ES'): string {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');
  const randomChars = Math.random().toString(36).substring(2, 8).toUpperCase();
  return `${prefix}-${year}${month}${day}-${randomChars}`;
}
