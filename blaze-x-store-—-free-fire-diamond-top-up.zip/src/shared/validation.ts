export const SUPPORTED_REGIONS: Record<string, { name: string; flag: string }> = {
  IND: { name: 'India', flag: '🇮🇳' },
  SG: { name: 'Singapore', flag: '🇸🇬' },
  BD: { name: 'Bangladesh', flag: '🇧🇩' },
  BR: { name: 'Brazil', flag: '🇧🇷' },
  ID: { name: 'Indonesia', flag: '🇮🇩' },
  ME: { name: 'Middle East', flag: '🇦🇪' },
  EU: { name: 'Europe', flag: '🇪🇺' },
  NA: { name: 'North America', flag: '🇺🇸' },
};

export interface UidValidationResult {
  isValid: boolean;
  cleanUid?: string;
  error?: string;
}

/**
 * Validates Free Fire Player UID
 * Requirements: Numeric string, 8 to 12 digits, no alphabetic or special characters
 */
export function validateFreeFireUid(rawUid: string | null | undefined): UidValidationResult {
  if (!rawUid) {
    return { isValid: false, error: 'Free Fire UID is required' };
  }

  const clean = rawUid.toString().trim();

  if (clean.length === 0) {
    return { isValid: false, error: 'Free Fire UID cannot be empty' };
  }

  // Check strictly numeric
  if (!/^\d+$/.test(clean)) {
    return { isValid: false, error: 'Free Fire UID must contain numbers only' };
  }

  // Free Fire UIDs are typically 8 to 12 digits
  if (clean.length < 8) {
    return { isValid: false, error: 'UID is too short (minimum 8 digits required)' };
  }

  if (clean.length > 12) {
    return { isValid: false, error: 'UID is too long (maximum 12 digits allowed)' };
  }

  return { isValid: true, cleanUid: clean };
}

/**
 * Validates Region code
 */
export function validateRegion(region: string | null | undefined): boolean {
  if (!region) return false;
  const upper = region.toUpperCase();
  return Boolean(SUPPORTED_REGIONS[upper]);
}
