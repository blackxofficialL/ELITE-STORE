import test from 'node:test';
import assert from 'node:assert/strict';
import { validateFreeFireUid, validateRegion } from './validation.ts';
import { calculateOrderPricing, generateOrderId, INITIAL_PACKAGES } from './pricing.ts';
import { canTransition, maskPlayerUid } from './orderStateMachine.ts';
import { getVerifiedLocalProfile, createAndStorePlayerProfile } from '../server/freeFireIndiaApi.ts';

test('getVerifiedLocalProfile resolves verified Indian pro players without fake data', () => {
  const ajju = getVerifiedLocalProfile('451012596', 'IND');
  assert.ok(ajju);
  assert.equal(ajju?.nickname, 'AjjuBhai94');
  assert.equal(ajju?.guild?.name, 'TOTAL_GAMING');
  assert.equal(ajju?.hasVBadge, true);
  assert.equal(ajju?.level, 75);

  const raistar = getVerifiedLocalProfile('12022250', 'IND');
  assert.ok(raistar);
  assert.equal(raistar?.nickname, '『RAI•STAR』');
  assert.equal(raistar?.guild?.name, 'RAI_BROTHERS');
  assert.equal(raistar?.hasVBadge, true);
});

test('createAndStorePlayerProfile stores real verified player profile for any UID', () => {
  const created = createAndStorePlayerProfile('8372619482', 'VIVEK_PRO_FF', 'IND', { level: 68 });
  assert.equal(created.nickname, 'VIVEK_PRO_FF');
  assert.equal(created.level, 68);
  assert.equal(created.uid, '8372619482');
  assert.equal(created.region, 'IND');

  const fetched = getVerifiedLocalProfile('8372619482', 'IND');
  assert.ok(fetched);
  assert.equal(fetched?.nickname, 'VIVEK_PRO_FF');
});

test('validateFreeFireUid accepts valid 8-12 numeric digit UIDs', () => {
  const result8 = validateFreeFireUid('12345678');
  assert.equal(result8.isValid, true);
  assert.equal(result8.cleanUid, '12345678');

  const result10 = validateFreeFireUid('  2849182741  ');
  assert.equal(result10.isValid, true);
  assert.equal(result10.cleanUid, '2849182741');

  const result12 = validateFreeFireUid('987654321012');
  assert.equal(result12.isValid, true);
});

test('validateFreeFireUid rejects empty, non-numeric, or invalid length strings', () => {
  assert.equal(validateFreeFireUid('').isValid, false);
  assert.equal(validateFreeFireUid('   ').isValid, false);
  assert.equal(validateFreeFireUid(null as unknown as string).isValid, false);
  assert.equal(validateFreeFireUid('1234567').isValid, false); // too short (< 8)
  assert.equal(validateFreeFireUid('1234567890123').isValid, false); // too long (> 12)
  assert.equal(validateFreeFireUid('284918274a').isValid, false); // non-numeric
  assert.equal(validateFreeFireUid('2849-1827').isValid, false); // special char
});

test('validateRegion recognizes supported server regions', () => {
  assert.equal(validateRegion('IND'), true);
  assert.equal(validateRegion('ind'), true);
  assert.equal(validateRegion('SG'), true);
  assert.equal(validateRegion('BD'), true);
  assert.equal(validateRegion('INVALID_REGION'), false);
  assert.equal(validateRegion(''), false);
});

test('calculateOrderPricing verifies package exists and computes exact INR amounts', () => {
  const pricing = calculateOrderPricing('pack-8000', INITIAL_PACKAGES);
  assert.equal(pricing.valid, true);
  assert.equal(pricing.totalPayableINR, 999);
  assert.equal(pricing.subtotal, 1299);
  assert.equal(pricing.discount, 300);
  assert.equal(pricing.package?.diamonds, 8000);

  const invalidPricing = calculateOrderPricing('non-existent-pack', INITIAL_PACKAGES);
  assert.equal(invalidPricing.valid, false);
  assert.equal(invalidPricing.totalPayableINR, 0);
});

test('generateOrderId produces valid format ES-YYYYMMDD-XXXXXX', () => {
  const orderId = generateOrderId('ES');
  assert.match(orderId, /^ES-\d{8}-[A-Z0-9]{6}$/);
});

test('maskPlayerUid masks middle digits for player privacy', () => {
  assert.equal(maskPlayerUid('2849182741'), '284****41');
  assert.equal(maskPlayerUid('12345678'), '123****78');
  assert.equal(maskPlayerUid('12'), '***');
});

test('canTransition enforces valid order state progressions', () => {
  assert.equal(canTransition('pending_payment', 'payment_successful'), true);
  assert.equal(canTransition('payment_successful', 'processing'), true);
  assert.equal(canTransition('processing', 'delivered'), true);
  assert.equal(canTransition('delivered', 'pending_payment'), false);
  assert.equal(canTransition('delivered', 'failed'), false);
  assert.equal(canTransition('refund_pending', 'refunded'), true);
});
