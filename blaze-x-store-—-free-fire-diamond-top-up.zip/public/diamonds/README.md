# Diamond Images Folder

Upload or replace your diamond package images here:
`/public/diamonds/`

### File Names:
- `diamond1.png` → **8,000 Diamonds** Package (₹999)
- `diamond2.png` → **12,000 Diamonds** Package (₹1,299)
- `diamond3.png` → **18,000 Diamonds** Package (₹1,599)
- `diamond4.png` → **25,000 Diamonds** Package (₹1,999)
- `diamond5.png` → **35,000 Diamonds** Package (₹2,599)
- `diamond6.png` → **50,000 Diamonds** Package (₹3,499)

### Supported Formats:
- `.png`, `.jpg`, `.webp`, `.svg`

The store cards automatically display these image files!
