# END CALL VOICE FOLDER
Place your end-call audio/voice recording file here (MP3, WAV, OGG, M4A, AAC).
Example: end_voice.mp3 or call_ended.mp3
When the customer clicks 'End Call', this voice recording will automatically play before hanging up.
