# CALL IMG FOLDER
Place your admin photo/image here (PNG, JPG, WEBP).
Example: admin.png or call_photo.jpg
The Call Admin screen will automatically display any image placed in this folder.
