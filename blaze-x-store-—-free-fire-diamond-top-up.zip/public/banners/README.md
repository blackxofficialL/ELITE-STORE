# Banners Folder

Upload or place your Free Fire MAX banner images in this folder:
`/public/banners/`

### Supported formats:
- `.png`
- `.jpg` / `.jpeg`
- `.webp`
- `.svg`

### How it works:
Any image placed here (e.g. `banner1.png`, `banner2.jpg`) is automatically detected by the website and displayed in the hero banner carousel. You can also rename or upload banners directly using the banner controls on the website.
