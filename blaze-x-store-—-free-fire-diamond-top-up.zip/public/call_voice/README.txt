# CALL VOICE FOLDER
Place your audio/voice recording file here (MP3, WAV, OGG, M4A, AAC).
Example: voice.mp3 or admin_call.mp3
When the customer clicks 'Call Admin', this voice recording will automatically play.
