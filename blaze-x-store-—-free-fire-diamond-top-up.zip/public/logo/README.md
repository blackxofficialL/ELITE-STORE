# Elite Store Logo

Place or rename your store logo file here:
`/public/logo.png`

### Supported formats:
- `/public/logo.png`
- `/public/logo.jpg`
- `/public/logo.webp`
- `/public/logo.svg`

The website's header (Navbar) and footer automatically display this image as the official **ELITE STORE** brand logo.
